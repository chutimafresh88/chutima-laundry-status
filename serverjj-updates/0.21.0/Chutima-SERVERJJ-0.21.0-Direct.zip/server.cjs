"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// migration/pos/server/node_modules/postgres-array/index.js
var require_postgres_array = __commonJS({
  "migration/pos/server/node_modules/postgres-array/index.js"(exports2) {
    "use strict";
    exports2.parse = function(source, transform) {
      return new ArrayParser(source, transform).parse();
    };
    var ArrayParser = class _ArrayParser {
      constructor(source, transform) {
        this.source = source;
        this.transform = transform || identity;
        this.position = 0;
        this.entries = [];
        this.recorded = [];
        this.dimension = 0;
      }
      isEof() {
        return this.position >= this.source.length;
      }
      nextCharacter() {
        var character = this.source[this.position++];
        if (character === "\\") {
          return {
            value: this.source[this.position++],
            escaped: true
          };
        }
        return {
          value: character,
          escaped: false
        };
      }
      record(character) {
        this.recorded.push(character);
      }
      newEntry(includeEmpty) {
        var entry;
        if (this.recorded.length > 0 || includeEmpty) {
          entry = this.recorded.join("");
          if (entry === "NULL" && !includeEmpty) {
            entry = null;
          }
          if (entry !== null) entry = this.transform(entry);
          this.entries.push(entry);
          this.recorded = [];
        }
      }
      consumeDimensions() {
        if (this.source[0] === "[") {
          while (!this.isEof()) {
            var char = this.nextCharacter();
            if (char.value === "=") break;
          }
        }
      }
      parse(nested) {
        var character, parser, quote;
        this.consumeDimensions();
        while (!this.isEof()) {
          character = this.nextCharacter();
          if (character.value === "{" && !quote) {
            this.dimension++;
            if (this.dimension > 1) {
              parser = new _ArrayParser(this.source.substr(this.position - 1), this.transform);
              this.entries.push(parser.parse(true));
              this.position += parser.position - 2;
            }
          } else if (character.value === "}" && !quote) {
            this.dimension--;
            if (!this.dimension) {
              this.newEntry();
              if (nested) return this.entries;
            }
          } else if (character.value === '"' && !character.escaped) {
            if (quote) this.newEntry(true);
            quote = !quote;
          } else if (character.value === "," && !quote) {
            this.newEntry();
          } else {
            this.record(character.value);
          }
        }
        if (this.dimension !== 0) {
          throw new Error("array dimension not balanced");
        }
        return this.entries;
      }
    };
    function identity(value) {
      return value;
    }
  }
});

// migration/pos/server/node_modules/pg-types/lib/arrayParser.js
var require_arrayParser = __commonJS({
  "migration/pos/server/node_modules/pg-types/lib/arrayParser.js"(exports2, module2) {
    var array = require_postgres_array();
    module2.exports = {
      create: function(source, transform) {
        return {
          parse: function() {
            return array.parse(source, transform);
          }
        };
      }
    };
  }
});

// migration/pos/server/node_modules/postgres-date/index.js
var require_postgres_date = __commonJS({
  "migration/pos/server/node_modules/postgres-date/index.js"(exports2, module2) {
    "use strict";
    var DATE_TIME = /(\d{1,})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})(\.\d{1,})?.*?( BC)?$/;
    var DATE = /^(\d{1,})-(\d{2})-(\d{2})( BC)?$/;
    var TIME_ZONE = /([Z+-])(\d{2})?:?(\d{2})?:?(\d{2})?/;
    var INFINITY = /^-?infinity$/;
    module2.exports = function parseDate(isoDate) {
      if (INFINITY.test(isoDate)) {
        return Number(isoDate.replace("i", "I"));
      }
      var matches = DATE_TIME.exec(isoDate);
      if (!matches) {
        return getDate(isoDate) || null;
      }
      var isBC = !!matches[8];
      var year = parseInt(matches[1], 10);
      if (isBC) {
        year = bcYearToNegativeYear(year);
      }
      var month = parseInt(matches[2], 10) - 1;
      var day = matches[3];
      var hour = parseInt(matches[4], 10);
      var minute = parseInt(matches[5], 10);
      var second = parseInt(matches[6], 10);
      var ms = matches[7];
      ms = ms ? 1e3 * parseFloat(ms) : 0;
      var date;
      var offset = timeZoneOffset(isoDate);
      if (offset != null) {
        date = new Date(Date.UTC(year, month, day, hour, minute, second, ms));
        if (is0To99(year)) {
          date.setUTCFullYear(year);
        }
        if (offset !== 0) {
          date.setTime(date.getTime() - offset);
        }
      } else {
        date = new Date(year, month, day, hour, minute, second, ms);
        if (is0To99(year)) {
          date.setFullYear(year);
        }
      }
      return date;
    };
    function getDate(isoDate) {
      var matches = DATE.exec(isoDate);
      if (!matches) {
        return;
      }
      var year = parseInt(matches[1], 10);
      var isBC = !!matches[4];
      if (isBC) {
        year = bcYearToNegativeYear(year);
      }
      var month = parseInt(matches[2], 10) - 1;
      var day = matches[3];
      var date = new Date(year, month, day);
      if (is0To99(year)) {
        date.setFullYear(year);
      }
      return date;
    }
    function timeZoneOffset(isoDate) {
      if (isoDate.endsWith("+00")) {
        return 0;
      }
      var zone = TIME_ZONE.exec(isoDate.split(" ")[1]);
      if (!zone) return;
      var type = zone[1];
      if (type === "Z") {
        return 0;
      }
      var sign = type === "-" ? -1 : 1;
      var offset = parseInt(zone[2], 10) * 3600 + parseInt(zone[3] || 0, 10) * 60 + parseInt(zone[4] || 0, 10);
      return offset * sign * 1e3;
    }
    function bcYearToNegativeYear(year) {
      return -(year - 1);
    }
    function is0To99(num) {
      return num >= 0 && num < 100;
    }
  }
});

// migration/pos/server/node_modules/xtend/mutable.js
var require_mutable = __commonJS({
  "migration/pos/server/node_modules/xtend/mutable.js"(exports2, module2) {
    module2.exports = extend;
    var hasOwnProperty = Object.prototype.hasOwnProperty;
    function extend(target) {
      for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) {
          if (hasOwnProperty.call(source, key)) {
            target[key] = source[key];
          }
        }
      }
      return target;
    }
  }
});

// migration/pos/server/node_modules/postgres-interval/index.js
var require_postgres_interval = __commonJS({
  "migration/pos/server/node_modules/postgres-interval/index.js"(exports2, module2) {
    "use strict";
    var extend = require_mutable();
    module2.exports = PostgresInterval;
    function PostgresInterval(raw) {
      if (!(this instanceof PostgresInterval)) {
        return new PostgresInterval(raw);
      }
      extend(this, parse(raw));
    }
    var properties = ["seconds", "minutes", "hours", "days", "months", "years"];
    PostgresInterval.prototype.toPostgres = function() {
      var filtered = properties.filter(this.hasOwnProperty, this);
      if (this.milliseconds && filtered.indexOf("seconds") < 0) {
        filtered.push("seconds");
      }
      if (filtered.length === 0) return "0";
      return filtered.map(function(property) {
        var value = this[property] || 0;
        if (property === "seconds" && this.milliseconds) {
          value = (value + this.milliseconds / 1e3).toFixed(6).replace(/\.?0+$/, "");
        }
        return value + " " + property;
      }, this).join(" ");
    };
    var propertiesISOEquivalent = {
      years: "Y",
      months: "M",
      days: "D",
      hours: "H",
      minutes: "M",
      seconds: "S"
    };
    var dateProperties = ["years", "months", "days"];
    var timeProperties = ["hours", "minutes", "seconds"];
    PostgresInterval.prototype.toISOString = PostgresInterval.prototype.toISO = function() {
      var datePart = dateProperties.map(buildProperty, this).join("");
      var timePart = timeProperties.map(buildProperty, this).join("");
      return "P" + datePart + "T" + timePart;
      function buildProperty(property) {
        var value = this[property] || 0;
        if (property === "seconds" && this.milliseconds) {
          value = (value + this.milliseconds / 1e3).toFixed(6).replace(/0+$/, "");
        }
        return value + propertiesISOEquivalent[property];
      }
    };
    var NUMBER = "([+-]?\\d+)";
    var YEAR = NUMBER + "\\s+years?";
    var MONTH = NUMBER + "\\s+mons?";
    var DAY = NUMBER + "\\s+days?";
    var TIME = "([+-])?([\\d]*):(\\d\\d):(\\d\\d)\\.?(\\d{1,6})?";
    var INTERVAL = new RegExp([YEAR, MONTH, DAY, TIME].map(function(regexString) {
      return "(" + regexString + ")?";
    }).join("\\s*"));
    var positions = {
      years: 2,
      months: 4,
      days: 6,
      hours: 9,
      minutes: 10,
      seconds: 11,
      milliseconds: 12
    };
    var negatives = ["hours", "minutes", "seconds", "milliseconds"];
    function parseMilliseconds(fraction) {
      var microseconds = fraction + "000000".slice(fraction.length);
      return parseInt(microseconds, 10) / 1e3;
    }
    function parse(interval) {
      if (!interval) return {};
      var matches = INTERVAL.exec(interval);
      var isNegative = matches[8] === "-";
      return Object.keys(positions).reduce(function(parsed, property) {
        var position = positions[property];
        var value = matches[position];
        if (!value) return parsed;
        value = property === "milliseconds" ? parseMilliseconds(value) : parseInt(value, 10);
        if (!value) return parsed;
        if (isNegative && ~negatives.indexOf(property)) {
          value *= -1;
        }
        parsed[property] = value;
        return parsed;
      }, {});
    }
  }
});

// migration/pos/server/node_modules/postgres-bytea/index.js
var require_postgres_bytea = __commonJS({
  "migration/pos/server/node_modules/postgres-bytea/index.js"(exports2, module2) {
    "use strict";
    var bufferFrom = Buffer.from || Buffer;
    module2.exports = function parseBytea(input) {
      if (/^\\x/.test(input)) {
        return bufferFrom(input.substr(2), "hex");
      }
      var output = "";
      var i = 0;
      while (i < input.length) {
        if (input[i] !== "\\") {
          output += input[i];
          ++i;
        } else {
          if (/[0-7]{3}/.test(input.substr(i + 1, 3))) {
            output += String.fromCharCode(parseInt(input.substr(i + 1, 3), 8));
            i += 4;
          } else {
            var backslashes = 1;
            while (i + backslashes < input.length && input[i + backslashes] === "\\") {
              backslashes++;
            }
            for (var k = 0; k < Math.floor(backslashes / 2); ++k) {
              output += "\\";
            }
            i += Math.floor(backslashes / 2) * 2;
          }
        }
      }
      return bufferFrom(output, "binary");
    };
  }
});

// migration/pos/server/node_modules/pg-types/lib/textParsers.js
var require_textParsers = __commonJS({
  "migration/pos/server/node_modules/pg-types/lib/textParsers.js"(exports2, module2) {
    var array = require_postgres_array();
    var arrayParser = require_arrayParser();
    var parseDate = require_postgres_date();
    var parseInterval = require_postgres_interval();
    var parseByteA = require_postgres_bytea();
    function allowNull(fn) {
      return function nullAllowed(value) {
        if (value === null) return value;
        return fn(value);
      };
    }
    function parseBool(value) {
      if (value === null) return value;
      return value === "TRUE" || value === "t" || value === "true" || value === "y" || value === "yes" || value === "on" || value === "1";
    }
    function parseBoolArray(value) {
      if (!value) return null;
      return array.parse(value, parseBool);
    }
    function parseBaseTenInt(string) {
      return parseInt(string, 10);
    }
    function parseIntegerArray(value) {
      if (!value) return null;
      return array.parse(value, allowNull(parseBaseTenInt));
    }
    function parseBigIntegerArray(value) {
      if (!value) return null;
      return array.parse(value, allowNull(function(entry) {
        return parseBigInteger(entry).trim();
      }));
    }
    var parsePointArray = function(value) {
      if (!value) {
        return null;
      }
      var p = arrayParser.create(value, function(entry) {
        if (entry !== null) {
          entry = parsePoint(entry);
        }
        return entry;
      });
      return p.parse();
    };
    var parseFloatArray = function(value) {
      if (!value) {
        return null;
      }
      var p = arrayParser.create(value, function(entry) {
        if (entry !== null) {
          entry = parseFloat(entry);
        }
        return entry;
      });
      return p.parse();
    };
    var parseStringArray = function(value) {
      if (!value) {
        return null;
      }
      var p = arrayParser.create(value);
      return p.parse();
    };
    var parseDateArray = function(value) {
      if (!value) {
        return null;
      }
      var p = arrayParser.create(value, function(entry) {
        if (entry !== null) {
          entry = parseDate(entry);
        }
        return entry;
      });
      return p.parse();
    };
    var parseIntervalArray = function(value) {
      if (!value) {
        return null;
      }
      var p = arrayParser.create(value, function(entry) {
        if (entry !== null) {
          entry = parseInterval(entry);
        }
        return entry;
      });
      return p.parse();
    };
    var parseByteAArray = function(value) {
      if (!value) {
        return null;
      }
      return array.parse(value, allowNull(parseByteA));
    };
    var parseInteger = function(value) {
      return parseInt(value, 10);
    };
    var parseBigInteger = function(value) {
      var valStr = String(value);
      if (/^\d+$/.test(valStr)) {
        return valStr;
      }
      return value;
    };
    var parseJsonArray = function(value) {
      if (!value) {
        return null;
      }
      return array.parse(value, allowNull(JSON.parse));
    };
    var parsePoint = function(value) {
      if (value[0] !== "(") {
        return null;
      }
      value = value.substring(1, value.length - 1).split(",");
      return {
        x: parseFloat(value[0]),
        y: parseFloat(value[1])
      };
    };
    var parseCircle = function(value) {
      if (value[0] !== "<" && value[1] !== "(") {
        return null;
      }
      var point = "(";
      var radius = "";
      var pointParsed = false;
      for (var i = 2; i < value.length - 1; i++) {
        if (!pointParsed) {
          point += value[i];
        }
        if (value[i] === ")") {
          pointParsed = true;
          continue;
        } else if (!pointParsed) {
          continue;
        }
        if (value[i] === ",") {
          continue;
        }
        radius += value[i];
      }
      var result = parsePoint(point);
      result.radius = parseFloat(radius);
      return result;
    };
    var init = function(register) {
      register(20, parseBigInteger);
      register(21, parseInteger);
      register(23, parseInteger);
      register(26, parseInteger);
      register(700, parseFloat);
      register(701, parseFloat);
      register(16, parseBool);
      register(1082, parseDate);
      register(1114, parseDate);
      register(1184, parseDate);
      register(600, parsePoint);
      register(651, parseStringArray);
      register(718, parseCircle);
      register(1e3, parseBoolArray);
      register(1001, parseByteAArray);
      register(1005, parseIntegerArray);
      register(1007, parseIntegerArray);
      register(1028, parseIntegerArray);
      register(1016, parseBigIntegerArray);
      register(1017, parsePointArray);
      register(1021, parseFloatArray);
      register(1022, parseFloatArray);
      register(1231, parseFloatArray);
      register(1014, parseStringArray);
      register(1015, parseStringArray);
      register(1008, parseStringArray);
      register(1009, parseStringArray);
      register(1040, parseStringArray);
      register(1041, parseStringArray);
      register(1115, parseDateArray);
      register(1182, parseDateArray);
      register(1185, parseDateArray);
      register(1186, parseInterval);
      register(1187, parseIntervalArray);
      register(17, parseByteA);
      register(114, JSON.parse.bind(JSON));
      register(3802, JSON.parse.bind(JSON));
      register(199, parseJsonArray);
      register(3807, parseJsonArray);
      register(3907, parseStringArray);
      register(2951, parseStringArray);
      register(791, parseStringArray);
      register(1183, parseStringArray);
      register(1270, parseStringArray);
    };
    module2.exports = {
      init
    };
  }
});

// migration/pos/server/node_modules/pg-int8/index.js
var require_pg_int8 = __commonJS({
  "migration/pos/server/node_modules/pg-int8/index.js"(exports2, module2) {
    "use strict";
    var BASE = 1e6;
    function readInt8(buffer) {
      var high = buffer.readInt32BE(0);
      var low = buffer.readUInt32BE(4);
      var sign = "";
      if (high < 0) {
        high = ~high + (low === 0);
        low = ~low + 1 >>> 0;
        sign = "-";
      }
      var result = "";
      var carry;
      var t;
      var digits;
      var pad;
      var l;
      var i;
      {
        carry = high % BASE;
        high = high / BASE >>> 0;
        t = 4294967296 * carry + low;
        low = t / BASE >>> 0;
        digits = "" + (t - BASE * low);
        if (low === 0 && high === 0) {
          return sign + digits + result;
        }
        pad = "";
        l = 6 - digits.length;
        for (i = 0; i < l; i++) {
          pad += "0";
        }
        result = pad + digits + result;
      }
      {
        carry = high % BASE;
        high = high / BASE >>> 0;
        t = 4294967296 * carry + low;
        low = t / BASE >>> 0;
        digits = "" + (t - BASE * low);
        if (low === 0 && high === 0) {
          return sign + digits + result;
        }
        pad = "";
        l = 6 - digits.length;
        for (i = 0; i < l; i++) {
          pad += "0";
        }
        result = pad + digits + result;
      }
      {
        carry = high % BASE;
        high = high / BASE >>> 0;
        t = 4294967296 * carry + low;
        low = t / BASE >>> 0;
        digits = "" + (t - BASE * low);
        if (low === 0 && high === 0) {
          return sign + digits + result;
        }
        pad = "";
        l = 6 - digits.length;
        for (i = 0; i < l; i++) {
          pad += "0";
        }
        result = pad + digits + result;
      }
      {
        carry = high % BASE;
        t = 4294967296 * carry + low;
        digits = "" + t % BASE;
        return sign + digits + result;
      }
    }
    module2.exports = readInt8;
  }
});

// migration/pos/server/node_modules/pg-types/lib/binaryParsers.js
var require_binaryParsers = __commonJS({
  "migration/pos/server/node_modules/pg-types/lib/binaryParsers.js"(exports2, module2) {
    var parseInt64 = require_pg_int8();
    var parseBits = function(data, bits, offset, invert, callback) {
      offset = offset || 0;
      invert = invert || false;
      callback = callback || function(lastValue, newValue, bits2) {
        return lastValue * Math.pow(2, bits2) + newValue;
      };
      var offsetBytes = offset >> 3;
      var inv = function(value) {
        if (invert) {
          return ~value & 255;
        }
        return value;
      };
      var mask = 255;
      var firstBits = 8 - offset % 8;
      if (bits < firstBits) {
        mask = 255 << 8 - bits & 255;
        firstBits = bits;
      }
      if (offset) {
        mask = mask >> offset % 8;
      }
      var result = 0;
      if (offset % 8 + bits >= 8) {
        result = callback(0, inv(data[offsetBytes]) & mask, firstBits);
      }
      var bytes = bits + offset >> 3;
      for (var i = offsetBytes + 1; i < bytes; i++) {
        result = callback(result, inv(data[i]), 8);
      }
      var lastBits = (bits + offset) % 8;
      if (lastBits > 0) {
        result = callback(result, inv(data[bytes]) >> 8 - lastBits, lastBits);
      }
      return result;
    };
    var parseFloatFromBits = function(data, precisionBits, exponentBits) {
      var bias = Math.pow(2, exponentBits - 1) - 1;
      var sign = parseBits(data, 1);
      var exponent = parseBits(data, exponentBits, 1);
      if (exponent === 0) {
        return 0;
      }
      var precisionBitsCounter = 1;
      var parsePrecisionBits = function(lastValue, newValue, bits) {
        if (lastValue === 0) {
          lastValue = 1;
        }
        for (var i = 1; i <= bits; i++) {
          precisionBitsCounter /= 2;
          if ((newValue & 1 << bits - i) > 0) {
            lastValue += precisionBitsCounter;
          }
        }
        return lastValue;
      };
      var mantissa = parseBits(data, precisionBits, exponentBits + 1, false, parsePrecisionBits);
      if (exponent == Math.pow(2, exponentBits + 1) - 1) {
        if (mantissa === 0) {
          return sign === 0 ? Infinity : -Infinity;
        }
        return NaN;
      }
      return (sign === 0 ? 1 : -1) * Math.pow(2, exponent - bias) * mantissa;
    };
    var parseInt16 = function(value) {
      if (parseBits(value, 1) == 1) {
        return -1 * (parseBits(value, 15, 1, true) + 1);
      }
      return parseBits(value, 15, 1);
    };
    var parseInt32 = function(value) {
      if (parseBits(value, 1) == 1) {
        return -1 * (parseBits(value, 31, 1, true) + 1);
      }
      return parseBits(value, 31, 1);
    };
    var parseFloat32 = function(value) {
      return parseFloatFromBits(value, 23, 8);
    };
    var parseFloat64 = function(value) {
      return parseFloatFromBits(value, 52, 11);
    };
    var parseNumeric = function(value) {
      var sign = parseBits(value, 16, 32);
      if (sign == 49152) {
        return NaN;
      }
      var weight = Math.pow(1e4, parseBits(value, 16, 16));
      var result = 0;
      var digits = [];
      var ndigits = parseBits(value, 16);
      for (var i = 0; i < ndigits; i++) {
        result += parseBits(value, 16, 64 + 16 * i) * weight;
        weight /= 1e4;
      }
      var scale = Math.pow(10, parseBits(value, 16, 48));
      return (sign === 0 ? 1 : -1) * Math.round(result * scale) / scale;
    };
    var parseDate = function(isUTC, value) {
      var sign = parseBits(value, 1);
      var rawValue = parseBits(value, 63, 1);
      var result = new Date((sign === 0 ? 1 : -1) * rawValue / 1e3 + 9466848e5);
      if (!isUTC) {
        result.setTime(result.getTime() + result.getTimezoneOffset() * 6e4);
      }
      result.usec = rawValue % 1e3;
      result.getMicroSeconds = function() {
        return this.usec;
      };
      result.setMicroSeconds = function(value2) {
        this.usec = value2;
      };
      result.getUTCMicroSeconds = function() {
        return this.usec;
      };
      return result;
    };
    var parseArray = function(value) {
      var dim = parseBits(value, 32);
      var flags = parseBits(value, 32, 32);
      var elementType = parseBits(value, 32, 64);
      var offset = 96;
      var dims = [];
      for (var i = 0; i < dim; i++) {
        dims[i] = parseBits(value, 32, offset);
        offset += 32;
        offset += 32;
      }
      var parseElement = function(elementType2) {
        var length = parseBits(value, 32, offset);
        offset += 32;
        if (length == 4294967295) {
          return null;
        }
        var result;
        if (elementType2 == 23 || elementType2 == 20) {
          result = parseBits(value, length * 8, offset);
          offset += length * 8;
          return result;
        } else if (elementType2 == 25) {
          result = value.toString(this.encoding, offset >> 3, (offset += length << 3) >> 3);
          return result;
        } else {
          console.log("ERROR: ElementType not implemented: " + elementType2);
        }
      };
      var parse = function(dimension, elementType2) {
        var array = [];
        var i2;
        if (dimension.length > 1) {
          var count = dimension.shift();
          for (i2 = 0; i2 < count; i2++) {
            array[i2] = parse(dimension, elementType2);
          }
          dimension.unshift(count);
        } else {
          for (i2 = 0; i2 < dimension[0]; i2++) {
            array[i2] = parseElement(elementType2);
          }
        }
        return array;
      };
      return parse(dims, elementType);
    };
    var parseText = function(value) {
      return value.toString("utf8");
    };
    var parseBool = function(value) {
      if (value === null) return null;
      return parseBits(value, 8) > 0;
    };
    var init = function(register) {
      register(20, parseInt64);
      register(21, parseInt16);
      register(23, parseInt32);
      register(26, parseInt32);
      register(1700, parseNumeric);
      register(700, parseFloat32);
      register(701, parseFloat64);
      register(16, parseBool);
      register(1114, parseDate.bind(null, false));
      register(1184, parseDate.bind(null, true));
      register(1e3, parseArray);
      register(1007, parseArray);
      register(1016, parseArray);
      register(1008, parseArray);
      register(1009, parseArray);
      register(25, parseText);
    };
    module2.exports = {
      init
    };
  }
});

// migration/pos/server/node_modules/pg-types/lib/builtins.js
var require_builtins = __commonJS({
  "migration/pos/server/node_modules/pg-types/lib/builtins.js"(exports2, module2) {
    module2.exports = {
      BOOL: 16,
      BYTEA: 17,
      CHAR: 18,
      INT8: 20,
      INT2: 21,
      INT4: 23,
      REGPROC: 24,
      TEXT: 25,
      OID: 26,
      TID: 27,
      XID: 28,
      CID: 29,
      JSON: 114,
      XML: 142,
      PG_NODE_TREE: 194,
      SMGR: 210,
      PATH: 602,
      POLYGON: 604,
      CIDR: 650,
      FLOAT4: 700,
      FLOAT8: 701,
      ABSTIME: 702,
      RELTIME: 703,
      TINTERVAL: 704,
      CIRCLE: 718,
      MACADDR8: 774,
      MONEY: 790,
      MACADDR: 829,
      INET: 869,
      ACLITEM: 1033,
      BPCHAR: 1042,
      VARCHAR: 1043,
      DATE: 1082,
      TIME: 1083,
      TIMESTAMP: 1114,
      TIMESTAMPTZ: 1184,
      INTERVAL: 1186,
      TIMETZ: 1266,
      BIT: 1560,
      VARBIT: 1562,
      NUMERIC: 1700,
      REFCURSOR: 1790,
      REGPROCEDURE: 2202,
      REGOPER: 2203,
      REGOPERATOR: 2204,
      REGCLASS: 2205,
      REGTYPE: 2206,
      UUID: 2950,
      TXID_SNAPSHOT: 2970,
      PG_LSN: 3220,
      PG_NDISTINCT: 3361,
      PG_DEPENDENCIES: 3402,
      TSVECTOR: 3614,
      TSQUERY: 3615,
      GTSVECTOR: 3642,
      REGCONFIG: 3734,
      REGDICTIONARY: 3769,
      JSONB: 3802,
      REGNAMESPACE: 4089,
      REGROLE: 4096
    };
  }
});

// migration/pos/server/node_modules/pg-types/index.js
var require_pg_types = __commonJS({
  "migration/pos/server/node_modules/pg-types/index.js"(exports2) {
    var textParsers = require_textParsers();
    var binaryParsers = require_binaryParsers();
    var arrayParser = require_arrayParser();
    var builtinTypes = require_builtins();
    exports2.getTypeParser = getTypeParser;
    exports2.setTypeParser = setTypeParser;
    exports2.arrayParser = arrayParser;
    exports2.builtins = builtinTypes;
    var typeParsers = {
      text: {},
      binary: {}
    };
    function noParse(val) {
      return String(val);
    }
    function getTypeParser(oid, format) {
      format = format || "text";
      if (!typeParsers[format]) {
        return noParse;
      }
      return typeParsers[format][oid] || noParse;
    }
    function setTypeParser(oid, format, parseFn) {
      if (typeof format == "function") {
        parseFn = format;
        format = "text";
      }
      typeParsers[format][oid] = parseFn;
    }
    textParsers.init(function(oid, converter) {
      typeParsers.text[oid] = converter;
    });
    binaryParsers.init(function(oid, converter) {
      typeParsers.binary[oid] = converter;
    });
  }
});

// migration/pos/server/node_modules/pg/lib/defaults.js
var require_defaults = __commonJS({
  "migration/pos/server/node_modules/pg/lib/defaults.js"(exports2, module2) {
    "use strict";
    var user;
    try {
      user = process.platform === "win32" ? process.env.USERNAME : process.env.USER;
    } catch {
    }
    module2.exports = {
      // database host. defaults to localhost
      host: "localhost",
      // database user's name
      user,
      // name of database to connect
      database: void 0,
      // database user's password
      password: null,
      // a Postgres connection string to be used instead of setting individual connection items
      // NOTE:  Setting this value will cause it to override any other value (such as database or user) defined
      // in the defaults object.
      connectionString: void 0,
      // database port
      port: 5432,
      // number of rows to return at a time from a prepared statement's
      // portal. 0 will return all rows at once
      rows: 0,
      // binary result mode
      binary: false,
      // Connection pool options - see https://github.com/brianc/node-pg-pool
      // number of connections to use in connection pool
      // 0 will disable connection pooling
      max: 10,
      // max milliseconds a client can go unused before it is removed
      // from the pool and destroyed
      idleTimeoutMillis: 3e4,
      client_encoding: "",
      ssl: false,
      // SSL negotiation style: 'postgres' (traditional SSLRequest) or 'direct'
      sslnegotiation: void 0,
      application_name: void 0,
      fallback_application_name: void 0,
      options: void 0,
      parseInputDatesAsUTC: false,
      // max milliseconds any query using this connection will execute for before timing out in error.
      // false=unlimited
      statement_timeout: false,
      // Abort any statement that waits longer than the specified duration in milliseconds while attempting to acquire a lock.
      // false=unlimited
      lock_timeout: false,
      // Terminate any session with an open transaction that has been idle for longer than the specified duration in milliseconds
      // false=unlimited
      idle_in_transaction_session_timeout: false,
      // max milliseconds to wait for query to complete (client side)
      query_timeout: false,
      connect_timeout: 0,
      keepalives: 1,
      keepalives_idle: 0
    };
    var pgTypes = require_pg_types();
    var parseBigInteger = pgTypes.getTypeParser(20, "text");
    var parseBigIntegerArray = pgTypes.getTypeParser(1016, "text");
    module2.exports.__defineSetter__("parseInt8", function(val) {
      pgTypes.setTypeParser(20, "text", val ? pgTypes.getTypeParser(23, "text") : parseBigInteger);
      pgTypes.setTypeParser(1016, "text", val ? pgTypes.getTypeParser(1007, "text") : parseBigIntegerArray);
    });
  }
});

// migration/pos/server/node_modules/pg/lib/utils.js
var require_utils = __commonJS({
  "migration/pos/server/node_modules/pg/lib/utils.js"(exports2, module2) {
    "use strict";
    var defaults = require_defaults();
    var { isDate } = require("util/types");
    function escapeElement(elementRepresentation) {
      const escaped = elementRepresentation.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
      return '"' + escaped + '"';
    }
    function arrayString(val) {
      let result = "{";
      for (let i = 0; i < val.length; i++) {
        if (i > 0) {
          result += ",";
        }
        let item = val[i];
        if (item == null) {
          result += "NULL";
        } else if (Array.isArray(item)) {
          result += arrayString(item);
        } else if (ArrayBuffer.isView(item)) {
          if (!(item instanceof Buffer)) {
            item = Buffer.from(item.buffer, item.byteOffset, item.byteLength);
          }
          result += "\\\\x" + item.toString("hex");
        } else {
          result += escapeElement(prepareValue(item));
        }
      }
      result += "}";
      return result;
    }
    var prepareValue = function(val, seen) {
      if (val == null) {
        return null;
      }
      if (typeof val === "object") {
        if (val instanceof Buffer) {
          return val;
        }
        if (ArrayBuffer.isView(val)) {
          return Buffer.from(val.buffer, val.byteOffset, val.byteLength);
        }
        if (isDate(val)) {
          if (defaults.parseInputDatesAsUTC) {
            return dateToStringUTC(val);
          } else {
            return dateToString(val);
          }
        }
        if (Array.isArray(val)) {
          return arrayString(val);
        }
        return prepareObject(val, seen);
      }
      return val.toString();
    };
    function prepareObject(val, seen) {
      if (val && typeof val.toPostgres === "function") {
        seen = seen || [];
        if (seen.indexOf(val) !== -1) {
          throw new Error('circular reference detected while preparing "' + val + '" for query');
        }
        seen.push(val);
        return prepareValue(val.toPostgres(prepareValue), seen);
      }
      return JSON.stringify(val);
    }
    function dateToString(date) {
      let offset = -date.getTimezoneOffset();
      let year = date.getFullYear();
      const isBCYear = year < 1;
      if (isBCYear) year = Math.abs(year) + 1;
      let ret = String(year).padStart(4, "0") + "-" + String(date.getMonth() + 1).padStart(2, "0") + "-" + String(date.getDate()).padStart(2, "0") + "T" + String(date.getHours()).padStart(2, "0") + ":" + String(date.getMinutes()).padStart(2, "0") + ":" + String(date.getSeconds()).padStart(2, "0") + "." + String(date.getMilliseconds()).padStart(3, "0");
      if (offset < 0) {
        ret += "-";
        offset *= -1;
      } else {
        ret += "+";
      }
      ret += String(Math.floor(offset / 60)).padStart(2, "0") + ":" + String(offset % 60).padStart(2, "0");
      if (isBCYear) ret += " BC";
      return ret;
    }
    function dateToStringUTC(date) {
      let year = date.getUTCFullYear();
      const isBCYear = year < 1;
      if (isBCYear) year = Math.abs(year) + 1;
      let ret = String(year).padStart(4, "0") + "-" + String(date.getUTCMonth() + 1).padStart(2, "0") + "-" + String(date.getUTCDate()).padStart(2, "0") + "T" + String(date.getUTCHours()).padStart(2, "0") + ":" + String(date.getUTCMinutes()).padStart(2, "0") + ":" + String(date.getUTCSeconds()).padStart(2, "0") + "." + String(date.getUTCMilliseconds()).padStart(3, "0");
      ret += "+00:00";
      if (isBCYear) ret += " BC";
      return ret;
    }
    function normalizeQueryConfig(config, values, callback) {
      config = typeof config === "string" ? { text: config } : config;
      if (values) {
        if (typeof values === "function") {
          config.callback = values;
        } else {
          config.values = values;
        }
      }
      if (callback) {
        config.callback = callback;
      }
      return config;
    }
    var escapeIdentifier = function(str) {
      return '"' + str.replace(/"/g, '""') + '"';
    };
    var escapeLiteral = function(str) {
      let hasBackslash = false;
      let escaped = "'";
      if (str == null) {
        return "''";
      }
      if (typeof str !== "string") {
        return "''";
      }
      for (let i = 0; i < str.length; i++) {
        const c = str[i];
        if (c === "'") {
          escaped += c + c;
        } else if (c === "\\") {
          escaped += c + c;
          hasBackslash = true;
        } else {
          escaped += c;
        }
      }
      escaped += "'";
      if (hasBackslash === true) {
        escaped = " E" + escaped;
      }
      return escaped;
    };
    module2.exports = {
      prepareValue: function prepareValueWrapper(value) {
        return prepareValue(value);
      },
      normalizeQueryConfig,
      escapeIdentifier,
      escapeLiteral
    };
  }
});

// migration/pos/server/node_modules/pg/lib/crypto/utils.js
var require_utils2 = __commonJS({
  "migration/pos/server/node_modules/pg/lib/crypto/utils.js"(exports2, module2) {
    var nodeCrypto = require("crypto");
    module2.exports = {
      postgresMd5PasswordHash,
      randomBytes,
      deriveKey,
      sha256,
      hashByName,
      hmacSha256,
      md5
    };
    var webCrypto = nodeCrypto.webcrypto || globalThis.crypto;
    var subtleCrypto = webCrypto.subtle;
    var textEncoder = new TextEncoder();
    function randomBytes(length) {
      return webCrypto.getRandomValues(Buffer.alloc(length));
    }
    async function md5(string) {
      try {
        return nodeCrypto.createHash("md5").update(string, "utf-8").digest("hex");
      } catch (e) {
        const data = typeof string === "string" ? textEncoder.encode(string) : string;
        const hash = await subtleCrypto.digest("MD5", data);
        return Array.from(new Uint8Array(hash)).map((b) => b.toString(16).padStart(2, "0")).join("");
      }
    }
    async function postgresMd5PasswordHash(user, password, salt) {
      const inner = await md5(password + user);
      const outer = await md5(Buffer.concat([Buffer.from(inner), salt]));
      return "md5" + outer;
    }
    async function sha256(text) {
      return await subtleCrypto.digest("SHA-256", text);
    }
    async function hashByName(hashName, text) {
      return await subtleCrypto.digest(hashName, text);
    }
    async function hmacSha256(keyBuffer, msg) {
      const key = await subtleCrypto.importKey("raw", keyBuffer, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
      return await subtleCrypto.sign("HMAC", key, textEncoder.encode(msg));
    }
    async function deriveKey(password, salt, iterations) {
      const key = await subtleCrypto.importKey("raw", textEncoder.encode(password), "PBKDF2", false, ["deriveBits"]);
      const params = { name: "PBKDF2", hash: "SHA-256", salt, iterations };
      return await subtleCrypto.deriveBits(params, key, 32 * 8, ["deriveBits"]);
    }
  }
});

// migration/pos/server/node_modules/pg/lib/crypto/cert-signatures.js
var require_cert_signatures = __commonJS({
  "migration/pos/server/node_modules/pg/lib/crypto/cert-signatures.js"(exports2, module2) {
    function x509Error(msg, cert) {
      return new Error("SASL channel binding: " + msg + " when parsing public certificate " + cert.toString("base64"));
    }
    function readASN1Length(data, index) {
      let length = data[index++];
      if (length < 128) return { length, index };
      const lengthBytes = length & 127;
      if (lengthBytes > 4) throw x509Error("bad length", data);
      length = 0;
      for (let i = 0; i < lengthBytes; i++) {
        length = length << 8 | data[index++];
      }
      return { length, index };
    }
    function readASN1OID(data, index) {
      if (data[index++] !== 6) throw x509Error("non-OID data", data);
      const { length: OIDLength, index: indexAfterOIDLength } = readASN1Length(data, index);
      index = indexAfterOIDLength;
      const lastIndex = index + OIDLength;
      const byte1 = data[index++];
      let oid = (byte1 / 40 >> 0) + "." + byte1 % 40;
      while (index < lastIndex) {
        let value = 0;
        while (index < lastIndex) {
          const nextByte = data[index++];
          value = value << 7 | nextByte & 127;
          if (nextByte < 128) break;
        }
        oid += "." + value;
      }
      return { oid, index };
    }
    function expectASN1Seq(data, index) {
      if (data[index++] !== 48) throw x509Error("non-sequence data", data);
      return readASN1Length(data, index);
    }
    function signatureAlgorithmHashFromCertificate(data, index) {
      if (index === void 0) index = 0;
      index = expectASN1Seq(data, index).index;
      const { length: certInfoLength, index: indexAfterCertInfoLength } = expectASN1Seq(data, index);
      index = indexAfterCertInfoLength + certInfoLength;
      index = expectASN1Seq(data, index).index;
      const { oid, index: indexAfterOID } = readASN1OID(data, index);
      switch (oid) {
        // RSA
        case "1.2.840.113549.1.1.4":
          return "MD5";
        case "1.2.840.113549.1.1.5":
          return "SHA-1";
        case "1.2.840.113549.1.1.11":
          return "SHA-256";
        case "1.2.840.113549.1.1.12":
          return "SHA-384";
        case "1.2.840.113549.1.1.13":
          return "SHA-512";
        case "1.2.840.113549.1.1.14":
          return "SHA-224";
        case "1.2.840.113549.1.1.15":
          return "SHA512-224";
        case "1.2.840.113549.1.1.16":
          return "SHA512-256";
        // ECDSA
        case "1.2.840.10045.4.1":
          return "SHA-1";
        case "1.2.840.10045.4.3.1":
          return "SHA-224";
        case "1.2.840.10045.4.3.2":
          return "SHA-256";
        case "1.2.840.10045.4.3.3":
          return "SHA-384";
        case "1.2.840.10045.4.3.4":
          return "SHA-512";
        // RSASSA-PSS: hash is indicated separately
        case "1.2.840.113549.1.1.10": {
          index = indexAfterOID;
          index = expectASN1Seq(data, index).index;
          if (data[index++] !== 160) throw x509Error("non-tag data", data);
          index = readASN1Length(data, index).index;
          index = expectASN1Seq(data, index).index;
          const { oid: hashOID } = readASN1OID(data, index);
          switch (hashOID) {
            // standalone hash OIDs
            case "1.2.840.113549.2.5":
              return "MD5";
            case "1.3.14.3.2.26":
              return "SHA-1";
            case "2.16.840.1.101.3.4.2.1":
              return "SHA-256";
            case "2.16.840.1.101.3.4.2.2":
              return "SHA-384";
            case "2.16.840.1.101.3.4.2.3":
              return "SHA-512";
          }
          throw x509Error("unknown hash OID " + hashOID, data);
        }
        // Ed25519 -- see https: return//github.com/openssl/openssl/issues/15477
        case "1.3.101.110":
        case "1.3.101.112":
          return "SHA-512";
        // Ed448 -- still not in pg 17.2 (if supported, digest would be SHAKE256 x 64 bytes)
        case "1.3.101.111":
        case "1.3.101.113":
          throw x509Error("Ed448 certificate channel binding is not currently supported by Postgres");
      }
      throw x509Error("unknown OID " + oid, data);
    }
    module2.exports = { signatureAlgorithmHashFromCertificate };
  }
});

// migration/pos/server/node_modules/pg/lib/crypto/sasl.js
var require_sasl = __commonJS({
  "migration/pos/server/node_modules/pg/lib/crypto/sasl.js"(exports2, module2) {
    "use strict";
    var crypto = require_utils2();
    var { signatureAlgorithmHashFromCertificate } = require_cert_signatures();
    function saslprep(password) {
      const nonAsciiSpace = /[\u00A0\u1680\u2000-\u200B\u202F\u205F\u3000]/g;
      const mappedToNothing = /[\u00AD\u034F\u1806\u180B\u180C\u180D\u200C\u200D\u2060\uFE00-\uFE0F\uFEFF]/g;
      return password.replace(nonAsciiSpace, " ").replace(mappedToNothing, "").normalize("NFKC");
    }
    var DEFAULT_MAX_SCRAM_ITERATIONS = 1e5;
    function startSession(mechanisms, stream, scramMaxIterations = DEFAULT_MAX_SCRAM_ITERATIONS) {
      const candidates = ["SCRAM-SHA-256"];
      if (stream) candidates.unshift("SCRAM-SHA-256-PLUS");
      const mechanism = candidates.find((candidate) => mechanisms.includes(candidate));
      if (!mechanism) {
        throw new Error("SASL: Only mechanism(s) " + candidates.join(" and ") + " are supported");
      }
      if (mechanism === "SCRAM-SHA-256-PLUS" && typeof stream.getPeerCertificate !== "function") {
        throw new Error("SASL: Mechanism SCRAM-SHA-256-PLUS requires a certificate");
      }
      const clientNonce = crypto.randomBytes(18).toString("base64");
      const gs2Header = mechanism === "SCRAM-SHA-256-PLUS" ? "p=tls-server-end-point" : stream ? "y" : "n";
      return {
        mechanism,
        clientNonce,
        response: gs2Header + ",,n=*,r=" + clientNonce,
        message: "SASLInitialResponse",
        scramMaxIterations
      };
    }
    async function continueSession(session, password, serverData, stream) {
      if (session.message !== "SASLInitialResponse") {
        throw new Error("SASL: Last message was not SASLInitialResponse");
      }
      if (typeof password !== "string") {
        throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: client password must be a string");
      }
      if (password === "") {
        throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: client password must be a non-empty string");
      }
      if (typeof serverData !== "string") {
        throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: serverData must be a string");
      }
      const sv = parseServerFirstMessage(serverData);
      if (!sv.nonce.startsWith(session.clientNonce)) {
        throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: server nonce does not start with client nonce");
      } else if (sv.nonce.length === session.clientNonce.length) {
        throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: server nonce is too short");
      }
      const scramMaxIterations = typeof session.scramMaxIterations === "number" ? session.scramMaxIterations : DEFAULT_MAX_SCRAM_ITERATIONS;
      if (scramMaxIterations !== 0 && sv.iteration > scramMaxIterations) {
        throw new Error(
          "SASL: SCRAM-SERVER-FIRST-MESSAGE: iteration count " + sv.iteration + " exceeds scramMaxIterations of " + scramMaxIterations
        );
      }
      const clientFirstMessageBare = "n=*,r=" + session.clientNonce;
      const serverFirstMessage = "r=" + sv.nonce + ",s=" + sv.salt + ",i=" + sv.iteration;
      let channelBinding = stream ? "eSws" : "biws";
      if (session.mechanism === "SCRAM-SHA-256-PLUS") {
        const peerCert = stream.getPeerCertificate().raw;
        let hashName = signatureAlgorithmHashFromCertificate(peerCert);
        if (hashName === "MD5" || hashName === "SHA-1") hashName = "SHA-256";
        const certHash = await crypto.hashByName(hashName, peerCert);
        const bindingData = Buffer.concat([Buffer.from("p=tls-server-end-point,,"), Buffer.from(certHash)]);
        channelBinding = bindingData.toString("base64");
      }
      const clientFinalMessageWithoutProof = "c=" + channelBinding + ",r=" + sv.nonce;
      const authMessage = clientFirstMessageBare + "," + serverFirstMessage + "," + clientFinalMessageWithoutProof;
      const saltBytes = Buffer.from(sv.salt, "base64");
      const saltedPassword = await crypto.deriveKey(saslprep(password), saltBytes, sv.iteration);
      const clientKey = await crypto.hmacSha256(saltedPassword, "Client Key");
      const storedKey = await crypto.sha256(clientKey);
      const clientSignature = await crypto.hmacSha256(storedKey, authMessage);
      const clientProof = xorBuffers(Buffer.from(clientKey), Buffer.from(clientSignature)).toString("base64");
      const serverKey = await crypto.hmacSha256(saltedPassword, "Server Key");
      const serverSignatureBytes = await crypto.hmacSha256(serverKey, authMessage);
      session.message = "SASLResponse";
      session.serverSignature = Buffer.from(serverSignatureBytes).toString("base64");
      session.response = clientFinalMessageWithoutProof + ",p=" + clientProof;
    }
    function finalizeSession(session, serverData) {
      if (session.message !== "SASLResponse") {
        throw new Error("SASL: Last message was not SASLResponse");
      }
      if (typeof serverData !== "string") {
        throw new Error("SASL: SCRAM-SERVER-FINAL-MESSAGE: serverData must be a string");
      }
      const { serverSignature } = parseServerFinalMessage(serverData);
      if (serverSignature !== session.serverSignature) {
        throw new Error("SASL: SCRAM-SERVER-FINAL-MESSAGE: server signature does not match");
      }
    }
    function isPrintableChars(text) {
      if (typeof text !== "string") {
        throw new TypeError("SASL: text must be a string");
      }
      return text.split("").map((_, i) => text.charCodeAt(i)).every((c) => c >= 33 && c <= 43 || c >= 45 && c <= 126);
    }
    function isBase64(text) {
      return /^(?:[a-zA-Z0-9+/]{4})*(?:[a-zA-Z0-9+/]{2}==|[a-zA-Z0-9+/]{3}=)?$/.test(text);
    }
    function parseAttributePairs(text) {
      if (typeof text !== "string") {
        throw new TypeError("SASL: attribute pairs text must be a string");
      }
      return new Map(
        text.split(",").map((attrValue) => {
          if (!/^.=/.test(attrValue)) {
            throw new Error("SASL: Invalid attribute pair entry");
          }
          const name = attrValue[0];
          const value = attrValue.substring(2);
          return [name, value];
        })
      );
    }
    function parseServerFirstMessage(data) {
      const attrPairs = parseAttributePairs(data);
      const nonce = attrPairs.get("r");
      if (!nonce) {
        throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: nonce missing");
      } else if (!isPrintableChars(nonce)) {
        throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: nonce must only contain printable characters");
      }
      const salt = attrPairs.get("s");
      if (!salt) {
        throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: salt missing");
      } else if (!isBase64(salt)) {
        throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: salt must be base64");
      }
      const iterationText = attrPairs.get("i");
      if (!iterationText) {
        throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: iteration missing");
      } else if (!/^[1-9][0-9]*$/.test(iterationText)) {
        throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: invalid iteration count");
      }
      const iteration = parseInt(iterationText, 10);
      return {
        nonce,
        salt,
        iteration
      };
    }
    function parseServerFinalMessage(serverData) {
      const attrPairs = parseAttributePairs(serverData);
      const error = attrPairs.get("e");
      const serverSignature = attrPairs.get("v");
      if (error) {
        throw new Error(`SASL: SCRAM-SERVER-FINAL-MESSAGE: server returned error: "${error}"`);
      }
      if (!serverSignature) {
        throw new Error("SASL: SCRAM-SERVER-FINAL-MESSAGE: server signature is missing");
      } else if (!isBase64(serverSignature)) {
        throw new Error("SASL: SCRAM-SERVER-FINAL-MESSAGE: server signature must be base64");
      }
      return {
        serverSignature
      };
    }
    function xorBuffers(a, b) {
      if (!Buffer.isBuffer(a)) {
        throw new TypeError("first argument must be a Buffer");
      }
      if (!Buffer.isBuffer(b)) {
        throw new TypeError("second argument must be a Buffer");
      }
      if (a.length !== b.length) {
        throw new Error("Buffer lengths must match");
      }
      if (a.length === 0) {
        throw new Error("Buffers cannot be empty");
      }
      return Buffer.from(a.map((_, i) => a[i] ^ b[i]));
    }
    module2.exports = {
      startSession,
      continueSession,
      finalizeSession,
      DEFAULT_MAX_SCRAM_ITERATIONS
    };
  }
});

// migration/pos/server/node_modules/pg/lib/type-overrides.js
var require_type_overrides = __commonJS({
  "migration/pos/server/node_modules/pg/lib/type-overrides.js"(exports2, module2) {
    "use strict";
    var types = require_pg_types();
    function TypeOverrides(userTypes) {
      this._types = userTypes || types;
      this.text = {};
      this.binary = {};
    }
    TypeOverrides.prototype.getOverrides = function(format) {
      switch (format) {
        case "text":
          return this.text;
        case "binary":
          return this.binary;
        default:
          return {};
      }
    };
    TypeOverrides.prototype.setTypeParser = function(oid, format, parseFn) {
      if (typeof format === "function") {
        parseFn = format;
        format = "text";
      }
      this.getOverrides(format)[oid] = parseFn;
    };
    TypeOverrides.prototype.getTypeParser = function(oid, format) {
      format = format || "text";
      return this.getOverrides(format)[oid] || this._types.getTypeParser(oid, format);
    };
    module2.exports = TypeOverrides;
  }
});

// migration/pos/server/node_modules/pg-connection-string/index.js
var require_pg_connection_string = __commonJS({
  "migration/pos/server/node_modules/pg-connection-string/index.js"(exports2, module2) {
    "use strict";
    function parse(str, options = {}) {
      if (str.charAt(0) === "/") {
        const config2 = str.split(" ");
        return { host: config2[0], database: config2[1] };
      }
      const config = /* @__PURE__ */ Object.create(null);
      let result;
      let dummyHost = false;
      if (/ |%[^a-f0-9]|%[a-f0-9][^a-f0-9]/i.test(str)) {
        str = encodeURI(str).replace(/%25(\d\d)/g, "%$1");
      }
      try {
        try {
          result = new URL(str, "postgres://base");
        } catch (e) {
          result = new URL(str.replace("@/", "@___DUMMY___/"), "postgres://base");
          dummyHost = true;
        }
      } catch (err) {
        err.input && (err.input = "*****REDACTED*****");
        throw err;
      }
      for (const entry of result.searchParams.entries()) {
        config[entry[0]] = entry[1];
      }
      config.user = config.user || decodeURIComponent(result.username);
      config.password = config.password || decodeURIComponent(result.password);
      if (result.protocol == "socket:") {
        config.host = decodeURI(result.pathname);
        config.database = result.searchParams.get("db");
        config.client_encoding = result.searchParams.get("encoding");
        return config;
      }
      const hostname = dummyHost ? "" : result.hostname;
      if (!config.host) {
        config.host = decodeURIComponent(hostname);
      } else if (hostname && /^%2f/i.test(hostname)) {
        result.pathname = hostname + result.pathname;
      }
      if (!config.port) {
        config.port = result.port;
      }
      const pathname = result.pathname.slice(1) || null;
      config.database = pathname ? decodeURI(pathname) : null;
      if (config.ssl === "true" || config.ssl === "1") {
        config.ssl = true;
      }
      if (config.ssl === "0") {
        config.ssl = false;
      }
      if (config.sslcert || config.sslkey || config.sslrootcert || config.sslmode) {
        config.ssl = {};
      }
      if (config.sslnegotiation === "direct" && config.ssl === void 0) {
        config.ssl = true;
      }
      const fs2 = config.sslcert || config.sslkey || config.sslrootcert ? require("fs") : null;
      if (config.sslcert) {
        config.ssl.cert = fs2.readFileSync(config.sslcert).toString();
      }
      if (config.sslkey) {
        config.ssl.key = fs2.readFileSync(config.sslkey).toString();
      }
      if (config.sslrootcert) {
        config.ssl.ca = fs2.readFileSync(config.sslrootcert).toString();
      }
      if (options.useLibpqCompat && config.uselibpqcompat) {
        throw new Error("Both useLibpqCompat and uselibpqcompat are set. Please use only one of them.");
      }
      if (config.uselibpqcompat === "true" || options.useLibpqCompat) {
        switch (config.sslmode) {
          case "disable": {
            config.ssl = false;
            break;
          }
          case "prefer": {
            config.ssl.rejectUnauthorized = false;
            break;
          }
          case "require": {
            if (config.sslrootcert) {
              config.ssl.checkServerIdentity = function() {
              };
            } else {
              config.ssl.rejectUnauthorized = false;
            }
            break;
          }
          case "verify-ca": {
            if (!config.ssl.ca) {
              throw new Error(
                "SECURITY WARNING: Using sslmode=verify-ca requires specifying a CA with sslrootcert. If a public CA is used, verify-ca allows connections to a server that somebody else may have registered with the CA, making you vulnerable to Man-in-the-Middle attacks. Either specify a custom CA certificate with sslrootcert parameter or use sslmode=verify-full for proper security."
              );
            }
            config.ssl.checkServerIdentity = function() {
            };
            break;
          }
          case "verify-full": {
            break;
          }
        }
      } else {
        switch (config.sslmode) {
          case "disable": {
            config.ssl = false;
            break;
          }
          case "prefer":
          case "require":
          case "verify-ca":
          case "verify-full": {
            if (config.sslmode !== "verify-full") {
              deprecatedSslModeWarning(config.sslmode);
            }
            break;
          }
          case "no-verify": {
            config.ssl.rejectUnauthorized = false;
            break;
          }
        }
      }
      return config;
    }
    function toConnectionOptions(sslConfig) {
      const connectionOptions = Object.entries(sslConfig).reduce((c, [key, value]) => {
        if (value !== void 0 && value !== null) {
          c[key] = value;
        }
        return c;
      }, /* @__PURE__ */ Object.create(null));
      return connectionOptions;
    }
    function toClientConfig(config) {
      const poolConfig = Object.entries(config).reduce((c, [key, value]) => {
        if (key === "ssl") {
          const sslConfig = value;
          if (typeof sslConfig === "boolean") {
            c[key] = sslConfig;
          }
          if (typeof sslConfig === "object") {
            c[key] = toConnectionOptions(sslConfig);
          }
        } else if (value !== void 0 && value !== null) {
          if (key === "port") {
            if (value !== "") {
              const v = parseInt(value, 10);
              if (isNaN(v)) {
                throw new Error(`Invalid ${key}: ${value}`);
              }
              c[key] = v;
            }
          } else {
            c[key] = value;
          }
        }
        return c;
      }, /* @__PURE__ */ Object.create(null));
      return poolConfig;
    }
    function parseIntoClientConfig(str) {
      return toClientConfig(parse(str));
    }
    function deprecatedSslModeWarning(sslmode) {
      if (!deprecatedSslModeWarning.warned && typeof process !== "undefined" && process.emitWarning) {
        deprecatedSslModeWarning.warned = true;
        process.emitWarning(`SECURITY WARNING: The SSL modes 'prefer', 'require', and 'verify-ca' are treated as aliases for 'verify-full'.
In the next major version (pg-connection-string v3.0.0 and pg v9.0.0), these modes will adopt standard libpq semantics, which have weaker security guarantees.

To prepare for this change:
- If you want the current behavior, explicitly use 'sslmode=verify-full'
- If you want libpq compatibility now, use 'uselibpqcompat=true&sslmode=${sslmode}'

See https://www.postgresql.org/docs/current/libpq-ssl.html for libpq SSL mode definitions.`);
      }
    }
    module2.exports = parse;
    parse.parse = parse;
    parse.toClientConfig = toClientConfig;
    parse.parseIntoClientConfig = parseIntoClientConfig;
  }
});

// migration/pos/server/node_modules/pg/lib/connection-parameters.js
var require_connection_parameters = __commonJS({
  "migration/pos/server/node_modules/pg/lib/connection-parameters.js"(exports2, module2) {
    "use strict";
    var dns = require("dns");
    var defaults = require_defaults();
    var parse = require_pg_connection_string().parse;
    var val = function(key, config, envVar) {
      if (config[key]) {
        return config[key];
      }
      if (envVar === void 0) {
        envVar = process.env["PG" + key.toUpperCase()];
      } else if (envVar === false) {
      } else {
        envVar = process.env[envVar];
      }
      return envVar || defaults[key];
    };
    var readSSLConfigFromEnvironment = function() {
      switch (process.env.PGSSLMODE) {
        case "disable":
          return false;
        case "prefer":
        case "require":
        case "verify-ca":
        case "verify-full":
          return true;
        case "no-verify":
          return { rejectUnauthorized: false };
      }
      return defaults.ssl;
    };
    var quoteParamValue = function(value) {
      return "'" + ("" + value).replace(/\\/g, "\\\\").replace(/'/g, "\\'") + "'";
    };
    var add = function(params, config, paramName) {
      const value = config[paramName];
      if (value !== void 0 && value !== null) {
        params.push(paramName + "=" + quoteParamValue(value));
      }
    };
    var ConnectionParameters = class {
      constructor(config) {
        config = typeof config === "string" ? parse(config) : config || {};
        if (config.connectionString) {
          config = Object.assign({}, config, parse(config.connectionString));
        }
        this.user = val("user", config);
        this.database = val("database", config);
        if (this.database === void 0) {
          this.database = this.user;
        }
        this.port = parseInt(val("port", config), 10);
        this.host = val("host", config);
        Object.defineProperty(this, "password", {
          configurable: true,
          enumerable: false,
          writable: true,
          value: val("password", config)
        });
        this.binary = val("binary", config);
        this.options = val("options", config);
        this.ssl = typeof config.ssl === "undefined" ? readSSLConfigFromEnvironment() : config.ssl;
        if (typeof this.ssl === "string") {
          if (this.ssl === "true") {
            this.ssl = true;
          }
        }
        if (this.ssl === "no-verify") {
          this.ssl = { rejectUnauthorized: false };
        }
        if (this.ssl && this.ssl.key) {
          Object.defineProperty(this.ssl, "key", {
            enumerable: false
          });
        }
        this.sslnegotiation = val("sslnegotiation", config, "PGSSLNEGOTIATION");
        if (this.sslnegotiation !== void 0 && this.sslnegotiation !== "postgres" && this.sslnegotiation !== "direct") {
          throw new Error(
            `Invalid sslnegotiation value: "${this.sslnegotiation}". Valid values are "postgres" and "direct".`
          );
        }
        if (this.sslnegotiation === "direct" && !this.ssl) {
          throw new Error("sslnegotiation=direct requires SSL to be enabled");
        }
        this.client_encoding = val("client_encoding", config);
        this.replication = val("replication", config);
        this.isDomainSocket = !(this.host || "").indexOf("/");
        this.application_name = val("application_name", config, "PGAPPNAME");
        this.fallback_application_name = val("fallback_application_name", config, false);
        this.statement_timeout = val("statement_timeout", config, false);
        this.lock_timeout = val("lock_timeout", config, false);
        this.idle_in_transaction_session_timeout = val("idle_in_transaction_session_timeout", config, false);
        this.query_timeout = val("query_timeout", config, false);
        if (config.connectionTimeoutMillis === void 0) {
          this.connect_timeout = process.env.PGCONNECT_TIMEOUT || 0;
        } else {
          this.connect_timeout = Math.floor(config.connectionTimeoutMillis / 1e3);
        }
        if (config.keepAlive === false) {
          this.keepalives = 0;
        } else if (config.keepAlive === true) {
          this.keepalives = 1;
        }
        if (typeof config.keepAliveInitialDelayMillis === "number") {
          this.keepalives_idle = Math.floor(config.keepAliveInitialDelayMillis / 1e3);
        }
      }
      getLibpqConnectionString(cb) {
        const params = [];
        add(params, this, "user");
        add(params, this, "password");
        add(params, this, "port");
        add(params, this, "application_name");
        add(params, this, "fallback_application_name");
        add(params, this, "connect_timeout");
        add(params, this, "options");
        const ssl = typeof this.ssl === "object" ? this.ssl : this.ssl ? { sslmode: this.ssl } : {};
        add(params, ssl, "sslmode");
        add(params, ssl, "sslca");
        add(params, ssl, "sslkey");
        add(params, ssl, "sslcert");
        add(params, ssl, "sslrootcert");
        add(params, this, "sslnegotiation");
        if (this.database) {
          params.push("dbname=" + quoteParamValue(this.database));
        }
        if (this.replication) {
          params.push("replication=" + quoteParamValue(this.replication));
        }
        if (this.host) {
          params.push("host=" + quoteParamValue(this.host));
        }
        if (this.isDomainSocket) {
          return cb(null, params.join(" "));
        }
        if (this.client_encoding) {
          params.push("client_encoding=" + quoteParamValue(this.client_encoding));
        }
        dns.lookup(this.host, function(err, address) {
          if (err) return cb(err, null);
          params.push("hostaddr=" + quoteParamValue(address));
          return cb(null, params.join(" "));
        });
      }
    };
    module2.exports = ConnectionParameters;
  }
});

// migration/pos/server/node_modules/pg/lib/result.js
var require_result = __commonJS({
  "migration/pos/server/node_modules/pg/lib/result.js"(exports2, module2) {
    "use strict";
    var types = require_pg_types();
    var matchRegexp = /^([A-Za-z]+)(?: (\d+))?(?: (\d+))?/;
    var Result = class {
      constructor(rowMode, types2) {
        this.command = null;
        this.rowCount = null;
        this.oid = null;
        this.rows = [];
        this.fields = [];
        this._parsers = void 0;
        this._types = types2;
        this.RowCtor = null;
        this.rowAsArray = rowMode === "array";
        if (this.rowAsArray) {
          this.parseRow = this._parseRowAsArray;
        }
        this._prebuiltEmptyResultObject = null;
      }
      // adds a command complete message
      addCommandComplete(msg) {
        let match;
        if (msg.text) {
          match = matchRegexp.exec(msg.text);
        } else {
          match = matchRegexp.exec(msg.command);
        }
        if (match) {
          this.command = match[1];
          if (match[3]) {
            this.oid = parseInt(match[2], 10);
            this.rowCount = parseInt(match[3], 10);
          } else if (match[2]) {
            this.rowCount = parseInt(match[2], 10);
          }
        }
      }
      _parseRowAsArray(rowData) {
        const row = new Array(rowData.length);
        for (let i = 0, len = rowData.length; i < len; i++) {
          const rawValue = rowData[i];
          if (rawValue !== null) {
            row[i] = this._parsers[i](rawValue);
          } else {
            row[i] = null;
          }
        }
        return row;
      }
      parseRow(rowData) {
        const row = { ...this._prebuiltEmptyResultObject };
        for (let i = 0, len = rowData.length; i < len; i++) {
          const rawValue = rowData[i];
          const field = this.fields[i].name;
          if (rawValue !== null) {
            const v = this.fields[i].format === "binary" ? Buffer.from(rawValue) : rawValue;
            row[field] = this._parsers[i](v);
          } else {
            row[field] = null;
          }
        }
        return row;
      }
      addRow(row) {
        this.rows.push(row);
      }
      addFields(fieldDescriptions) {
        this.fields = fieldDescriptions;
        if (this.fields.length) {
          this._parsers = new Array(fieldDescriptions.length);
        }
        const row = /* @__PURE__ */ Object.create(null);
        for (let i = 0; i < fieldDescriptions.length; i++) {
          const desc = fieldDescriptions[i];
          row[desc.name] = null;
          if (this._types) {
            this._parsers[i] = this._types.getTypeParser(desc.dataTypeID, desc.format || "text");
          } else {
            this._parsers[i] = types.getTypeParser(desc.dataTypeID, desc.format || "text");
          }
        }
        this._prebuiltEmptyResultObject = { ...row };
      }
    };
    module2.exports = Result;
  }
});

// migration/pos/server/node_modules/pg/lib/query.js
var require_query = __commonJS({
  "migration/pos/server/node_modules/pg/lib/query.js"(exports2, module2) {
    "use strict";
    var { EventEmitter } = require("events");
    var Result = require_result();
    var utils = require_utils();
    var Query = class extends EventEmitter {
      constructor(config, values, callback) {
        super();
        config = utils.normalizeQueryConfig(config, values, callback);
        this.text = config.text;
        this.values = config.values;
        this.rows = config.rows;
        this.types = config.types;
        this.name = config.name;
        this.queryMode = config.queryMode;
        this.binary = config.binary;
        this.portal = config.portal || "";
        this.callback = config.callback;
        this._rowMode = config.rowMode;
        if (process.domain && config.callback) {
          this.callback = process.domain.bind(config.callback);
        }
        this._result = new Result(this._rowMode, this.types);
        this._results = this._result;
        this._canceledDueToError = false;
      }
      requiresPreparation() {
        if (this.queryMode === "extended") {
          return true;
        }
        if (this.name) {
          return true;
        }
        if (this.rows) {
          return true;
        }
        if (!this.text) {
          return false;
        }
        if (!this.values) {
          return false;
        }
        return this.values.length > 0;
      }
      _checkForMultirow() {
        if (this._result.command) {
          if (!Array.isArray(this._results)) {
            this._results = [this._result];
          }
          this._result = new Result(this._rowMode, this._result._types);
          this._results.push(this._result);
        }
      }
      // associates row metadata from the supplied
      // message with this query object
      // metadata used when parsing row results
      handleRowDescription(msg) {
        this._checkForMultirow();
        this._result.addFields(msg.fields);
        this._accumulateRows = this.callback || !this.listeners("row").length;
      }
      handleDataRow(msg) {
        let row;
        if (this._canceledDueToError) {
          return;
        }
        try {
          row = this._result.parseRow(msg.fields);
        } catch (err) {
          this._canceledDueToError = err;
          return;
        }
        this.emit("row", row, this._result);
        if (this._accumulateRows) {
          this._result.addRow(row);
        }
      }
      handleCommandComplete(msg, connection) {
        this._checkForMultirow();
        this._result.addCommandComplete(msg);
        if (this.rows) {
          connection.sync();
        }
      }
      // if a named prepared statement is created with empty query text
      // the backend will send an emptyQuery message but *not* a command complete message
      // since we pipeline sync immediately after execute we don't need to do anything here
      // unless we have rows specified, in which case we did not pipeline the initial sync call
      handleEmptyQuery(connection) {
        if (this.rows) {
          connection.sync();
        }
      }
      handleError(err, connection) {
        if (this._canceledDueToError) {
          err = this._canceledDueToError;
          this._canceledDueToError = false;
        }
        if (this.callback) {
          return this.callback(err);
        }
        this.emit("error", err);
      }
      handleReadyForQuery(con) {
        if (this._canceledDueToError) {
          return this.handleError(this._canceledDueToError, con);
        }
        if (this.callback) {
          try {
            this.callback(null, this._results);
          } catch (err) {
            process.nextTick(() => {
              throw err;
            });
          }
        }
        this.emit("end", this._results);
      }
      submit(connection) {
        if (typeof this.text !== "string" && typeof this.name !== "string") {
          return new Error("A query must have either text or a name. Supplying neither is unsupported.");
        }
        const previous = connection.parsedStatements[this.name] || connection.submittedNamedStatements[this.name];
        if (this.text && previous && this.text !== previous) {
          return new Error(`Prepared statements must be unique - '${this.name}' was used for a different statement`);
        }
        if (this.values && !Array.isArray(this.values)) {
          return new Error("Query values must be an array");
        }
        if (this.requiresPreparation()) {
          connection.stream.cork && connection.stream.cork();
          try {
            this.prepare(connection);
          } finally {
            connection.stream.uncork && connection.stream.uncork();
          }
        } else {
          connection.query(this.text);
        }
        return null;
      }
      hasBeenParsed(connection) {
        return this.name && (connection.parsedStatements[this.name] || connection.submittedNamedStatements[this.name]);
      }
      handlePortalSuspended(connection) {
        this._getRows(connection, this.rows);
      }
      _getRows(connection, rows) {
        connection.execute({
          portal: this.portal,
          rows
        });
        if (!rows) {
          connection.sync();
        } else {
          connection.flush();
        }
      }
      // http://developer.postgresql.org/pgdocs/postgres/protocol-flow.html#PROTOCOL-FLOW-EXT-QUERY
      prepare(connection) {
        if (!this.hasBeenParsed(connection)) {
          connection.parse({
            text: this.text,
            name: this.name,
            types: this.types
          });
          if (this.name) {
            connection.submittedNamedStatements[this.name] = this.text;
          }
        }
        try {
          connection.bind({
            portal: this.portal,
            statement: this.name,
            values: this.values,
            binary: this.binary,
            valueMapper: utils.prepareValue
          });
        } catch (err) {
          connection.close({ type: "S", name: this.name });
          connection.sync();
          this.handleError(err, connection);
          return;
        }
        connection.describe({
          type: "P",
          name: this.portal || ""
        });
        this._getRows(connection, this.rows);
      }
      handleCopyInResponse(connection) {
        connection.sendCopyFail("No source stream defined");
      }
      handleCopyData(msg, connection) {
      }
    };
    module2.exports = Query;
  }
});

// migration/pos/server/node_modules/pg-protocol/dist/messages.js
var require_messages = __commonJS({
  "migration/pos/server/node_modules/pg-protocol/dist/messages.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.NoticeMessage = exports2.DataRowMessage = exports2.CommandCompleteMessage = exports2.ReadyForQueryMessage = exports2.NotificationResponseMessage = exports2.BackendKeyDataMessage = exports2.AuthenticationMD5Password = exports2.ParameterStatusMessage = exports2.ParameterDescriptionMessage = exports2.RowDescriptionMessage = exports2.Field = exports2.CopyResponse = exports2.CopyDataMessage = exports2.DatabaseError = exports2.copyDone = exports2.emptyQuery = exports2.replicationStart = exports2.portalSuspended = exports2.noData = exports2.closeComplete = exports2.bindComplete = exports2.parseComplete = void 0;
    exports2.parseComplete = {
      name: "parseComplete",
      length: 5
    };
    exports2.bindComplete = {
      name: "bindComplete",
      length: 5
    };
    exports2.closeComplete = {
      name: "closeComplete",
      length: 5
    };
    exports2.noData = {
      name: "noData",
      length: 5
    };
    exports2.portalSuspended = {
      name: "portalSuspended",
      length: 5
    };
    exports2.replicationStart = {
      name: "replicationStart",
      length: 4
    };
    exports2.emptyQuery = {
      name: "emptyQuery",
      length: 4
    };
    exports2.copyDone = {
      name: "copyDone",
      length: 4
    };
    var DatabaseError = class extends Error {
      constructor(message, length, name) {
        super(message);
        this.length = length;
        this.name = name;
      }
    };
    exports2.DatabaseError = DatabaseError;
    var CopyDataMessage = class {
      constructor(length, chunk) {
        this.length = length;
        this.chunk = chunk;
        this.name = "copyData";
      }
    };
    exports2.CopyDataMessage = CopyDataMessage;
    var CopyResponse = class {
      constructor(length, name, binary, columnCount) {
        this.length = length;
        this.name = name;
        this.binary = binary;
        this.columnTypes = new Array(columnCount);
      }
    };
    exports2.CopyResponse = CopyResponse;
    var Field = class {
      constructor(name, tableID, columnID, dataTypeID, dataTypeSize, dataTypeModifier, format) {
        this.name = name;
        this.tableID = tableID;
        this.columnID = columnID;
        this.dataTypeID = dataTypeID;
        this.dataTypeSize = dataTypeSize;
        this.dataTypeModifier = dataTypeModifier;
        this.format = format;
      }
    };
    exports2.Field = Field;
    var RowDescriptionMessage = class {
      constructor(length, fieldCount) {
        this.length = length;
        this.fieldCount = fieldCount;
        this.name = "rowDescription";
        this.fields = new Array(this.fieldCount);
      }
    };
    exports2.RowDescriptionMessage = RowDescriptionMessage;
    var ParameterDescriptionMessage = class {
      constructor(length, parameterCount) {
        this.length = length;
        this.parameterCount = parameterCount;
        this.name = "parameterDescription";
        this.dataTypeIDs = new Array(this.parameterCount);
      }
    };
    exports2.ParameterDescriptionMessage = ParameterDescriptionMessage;
    var ParameterStatusMessage = class {
      constructor(length, parameterName, parameterValue) {
        this.length = length;
        this.parameterName = parameterName;
        this.parameterValue = parameterValue;
        this.name = "parameterStatus";
      }
    };
    exports2.ParameterStatusMessage = ParameterStatusMessage;
    var AuthenticationMD5Password = class {
      constructor(length, salt) {
        this.length = length;
        this.salt = salt;
        this.name = "authenticationMD5Password";
      }
    };
    exports2.AuthenticationMD5Password = AuthenticationMD5Password;
    var BackendKeyDataMessage = class {
      constructor(length, processID, secretKey) {
        this.length = length;
        this.processID = processID;
        this.secretKey = secretKey;
        this.name = "backendKeyData";
      }
    };
    exports2.BackendKeyDataMessage = BackendKeyDataMessage;
    var NotificationResponseMessage = class {
      constructor(length, processId, channel, payload) {
        this.length = length;
        this.processId = processId;
        this.channel = channel;
        this.payload = payload;
        this.name = "notification";
      }
    };
    exports2.NotificationResponseMessage = NotificationResponseMessage;
    var ReadyForQueryMessage = class {
      constructor(length, status) {
        this.length = length;
        this.status = status;
        this.name = "readyForQuery";
      }
    };
    exports2.ReadyForQueryMessage = ReadyForQueryMessage;
    var CommandCompleteMessage = class {
      constructor(length, text) {
        this.length = length;
        this.text = text;
        this.name = "commandComplete";
      }
    };
    exports2.CommandCompleteMessage = CommandCompleteMessage;
    var DataRowMessage = class {
      constructor(length, fields) {
        this.length = length;
        this.fields = fields;
        this.name = "dataRow";
        this.fieldCount = fields.length;
      }
    };
    exports2.DataRowMessage = DataRowMessage;
    var NoticeMessage = class {
      constructor(length, message) {
        this.length = length;
        this.message = message;
        this.name = "notice";
      }
    };
    exports2.NoticeMessage = NoticeMessage;
  }
});

// migration/pos/server/node_modules/pg-protocol/dist/buffer-writer.js
var require_buffer_writer = __commonJS({
  "migration/pos/server/node_modules/pg-protocol/dist/buffer-writer.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Writer = void 0;
    var Writer = class {
      constructor(size = 256) {
        this.size = size;
        this.offset = 5;
        this.headerPosition = 0;
        this.buffer = Buffer.allocUnsafe(size);
      }
      ensure(size) {
        const remaining = this.buffer.length - this.offset;
        if (remaining < size) {
          const oldBuffer = this.buffer;
          const newSize = oldBuffer.length + (oldBuffer.length >> 1) + size;
          this.buffer = Buffer.allocUnsafe(newSize);
          oldBuffer.copy(this.buffer);
        }
      }
      addInt32(num) {
        this.ensure(4);
        this.buffer[this.offset++] = num >>> 24 & 255;
        this.buffer[this.offset++] = num >>> 16 & 255;
        this.buffer[this.offset++] = num >>> 8 & 255;
        this.buffer[this.offset++] = num >>> 0 & 255;
        return this;
      }
      addInt16(num) {
        this.ensure(2);
        this.buffer[this.offset++] = num >>> 8 & 255;
        this.buffer[this.offset++] = num >>> 0 & 255;
        return this;
      }
      addCString(string) {
        if (!string) {
          this.ensure(1);
        } else {
          const len = Buffer.byteLength(string);
          this.ensure(len + 1);
          this.buffer.write(string, this.offset, "utf-8");
          this.offset += len;
        }
        this.buffer[this.offset++] = 0;
        return this;
      }
      addString(string = "") {
        const len = Buffer.byteLength(string);
        this.ensure(len);
        this.buffer.write(string, this.offset);
        this.offset += len;
        return this;
      }
      // Write an Int32 byte-length prefix immediately followed by the string's UTF-8
      // bytes. Postgres' Bind wire format prefixes every parameter with its length,
      // and doing it in one method computes Buffer.byteLength ONCE — the previous
      // `addInt32(Buffer.byteLength(s)).addString(s)` pairing scanned the string
      // three times (byteLength for the prefix, byteLength again inside addString,
      // then the encode), which is costly for large text parameters.
      addInt32PrefixedString(string) {
        const len = Buffer.byteLength(string);
        this.ensure(4 + len);
        const buffer = this.buffer;
        let offset = this.offset;
        buffer[offset++] = len >>> 24 & 255;
        buffer[offset++] = len >>> 16 & 255;
        buffer[offset++] = len >>> 8 & 255;
        buffer[offset++] = len >>> 0 & 255;
        buffer.write(string, offset, "utf-8");
        this.offset = offset + len;
        return this;
      }
      add(otherBuffer) {
        this.ensure(otherBuffer.length);
        otherBuffer.copy(this.buffer, this.offset);
        this.offset += otherBuffer.length;
        return this;
      }
      join(code) {
        if (code) {
          this.buffer[this.headerPosition] = code;
          const length = this.offset - (this.headerPosition + 1);
          this.buffer.writeInt32BE(length, this.headerPosition + 1);
        }
        return this.buffer.slice(code ? 0 : 5, this.offset);
      }
      flush(code) {
        const result = this.join(code);
        this.offset = 5;
        this.headerPosition = 0;
        this.buffer = Buffer.allocUnsafe(this.size);
        return result;
      }
      clear() {
        this.offset = 5;
        this.headerPosition = 0;
      }
    };
    exports2.Writer = Writer;
  }
});

// migration/pos/server/node_modules/pg-protocol/dist/serializer.js
var require_serializer = __commonJS({
  "migration/pos/server/node_modules/pg-protocol/dist/serializer.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.serialize = void 0;
    var buffer_writer_1 = require_buffer_writer();
    var writer = new buffer_writer_1.Writer();
    var startup = (opts) => {
      writer.addInt16(3).addInt16(0);
      for (const key of Object.keys(opts)) {
        writer.addCString(key).addCString(opts[key]);
      }
      writer.addCString("client_encoding").addCString("UTF8");
      const bodyBuffer = writer.addCString("").flush();
      const length = bodyBuffer.length + 4;
      return new buffer_writer_1.Writer().addInt32(length).add(bodyBuffer).flush();
    };
    var requestSsl = () => {
      const response = Buffer.allocUnsafe(8);
      response.writeInt32BE(8, 0);
      response.writeInt32BE(80877103, 4);
      return response;
    };
    var password = (password2) => {
      return writer.addCString(password2).flush(
        112
        /* code.startup */
      );
    };
    var sendSASLInitialResponseMessage = function(mechanism, initialResponse) {
      writer.addCString(mechanism).addInt32PrefixedString(initialResponse);
      return writer.flush(
        112
        /* code.startup */
      );
    };
    var sendSCRAMClientFinalMessage = function(additionalData) {
      return writer.addString(additionalData).flush(
        112
        /* code.startup */
      );
    };
    var query = (text) => {
      return writer.addCString(text).flush(
        81
        /* code.query */
      );
    };
    var emptyArray = [];
    var parse = (query2) => {
      const name = query2.name || "";
      if (name.length > 63) {
        console.error("Warning! Postgres only supports 63 characters for query names.");
        console.error("You supplied %s (%s)", name, name.length);
        console.error("This can cause conflicts and silent errors executing queries");
      }
      const types = query2.types || emptyArray;
      const len = types.length;
      const buffer = writer.addCString(name).addCString(query2.text).addInt16(len);
      for (let i = 0; i < len; i++) {
        buffer.addInt32(types[i]);
      }
      return writer.flush(
        80
        /* code.parse */
      );
    };
    var paramWriter = new buffer_writer_1.Writer();
    var writeValues = function(values, valueMapper) {
      for (let i = 0; i < values.length; i++) {
        const mappedVal = valueMapper ? valueMapper(values[i], i) : values[i];
        if (mappedVal == null) {
          writer.addInt16(
            0
            /* ParamType.STRING */
          );
          paramWriter.addInt32(-1);
        } else if (mappedVal instanceof Buffer) {
          writer.addInt16(
            1
            /* ParamType.BINARY */
          );
          paramWriter.addInt32(mappedVal.length);
          paramWriter.add(mappedVal);
        } else {
          writer.addInt16(
            0
            /* ParamType.STRING */
          );
          paramWriter.addInt32PrefixedString(mappedVal);
        }
      }
    };
    var bind = (config = {}) => {
      const portal = config.portal || "";
      const statement = config.statement || "";
      const binary = config.binary || false;
      const values = config.values || emptyArray;
      const len = values.length;
      writer.addCString(portal).addCString(statement);
      writer.addInt16(len);
      try {
        writeValues(values, config.valueMapper);
      } catch (err) {
        writer.clear();
        paramWriter.clear();
        throw err;
      }
      writer.addInt16(len);
      writer.add(paramWriter.flush());
      writer.addInt16(1);
      writer.addInt16(
        binary ? 1 : 0
        /* ParamType.STRING */
      );
      return writer.flush(
        66
        /* code.bind */
      );
    };
    var emptyExecute = Buffer.from([69, 0, 0, 0, 9, 0, 0, 0, 0, 0]);
    var execute = (config) => {
      if (!config || !config.portal && !config.rows) {
        return emptyExecute;
      }
      const portal = config.portal || "";
      const rows = config.rows || 0;
      const portalLength = Buffer.byteLength(portal);
      const len = 4 + portalLength + 1 + 4;
      const buff = Buffer.allocUnsafe(1 + len);
      buff[0] = 69;
      buff.writeInt32BE(len, 1);
      buff.write(portal, 5, "utf-8");
      buff[portalLength + 5] = 0;
      buff.writeUInt32BE(rows, buff.length - 4);
      return buff;
    };
    var cancel = (processID, secretKey) => {
      const buffer = Buffer.allocUnsafe(16);
      buffer.writeInt32BE(16, 0);
      buffer.writeInt16BE(1234, 4);
      buffer.writeInt16BE(5678, 6);
      buffer.writeInt32BE(processID, 8);
      buffer.writeInt32BE(secretKey, 12);
      return buffer;
    };
    var cstringMessage = (code, string) => {
      const stringLen = Buffer.byteLength(string);
      const len = 4 + stringLen + 1;
      const buffer = Buffer.allocUnsafe(1 + len);
      buffer[0] = code;
      buffer.writeInt32BE(len, 1);
      buffer.write(string, 5, "utf-8");
      buffer[len] = 0;
      return buffer;
    };
    var emptyDescribePortal = writer.addCString("P").flush(
      68
      /* code.describe */
    );
    var emptyDescribeStatement = writer.addCString("S").flush(
      68
      /* code.describe */
    );
    var describe = (msg) => {
      return msg.name ? cstringMessage(68, `${msg.type}${msg.name || ""}`) : msg.type === "P" ? emptyDescribePortal : emptyDescribeStatement;
    };
    var close = (msg) => {
      const text = `${msg.type}${msg.name || ""}`;
      return cstringMessage(67, text);
    };
    var copyData = (chunk) => {
      return writer.add(chunk).flush(
        100
        /* code.copyFromChunk */
      );
    };
    var copyFail = (message) => {
      return cstringMessage(102, message);
    };
    var codeOnlyBuffer = (code) => Buffer.from([code, 0, 0, 0, 4]);
    var flushBuffer = codeOnlyBuffer(
      72
      /* code.flush */
    );
    var syncBuffer = codeOnlyBuffer(
      83
      /* code.sync */
    );
    var endBuffer = codeOnlyBuffer(
      88
      /* code.end */
    );
    var copyDoneBuffer = codeOnlyBuffer(
      99
      /* code.copyDone */
    );
    var serialize = {
      startup,
      password,
      requestSsl,
      sendSASLInitialResponseMessage,
      sendSCRAMClientFinalMessage,
      query,
      parse,
      bind,
      execute,
      describe,
      close,
      flush: () => flushBuffer,
      sync: () => syncBuffer,
      end: () => endBuffer,
      copyData,
      copyDone: () => copyDoneBuffer,
      copyFail,
      cancel
    };
    exports2.serialize = serialize;
  }
});

// migration/pos/server/node_modules/pg-protocol/dist/buffer-reader.js
var require_buffer_reader = __commonJS({
  "migration/pos/server/node_modules/pg-protocol/dist/buffer-reader.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.BufferReader = void 0;
    var BufferReader = class {
      constructor(offset = 0) {
        this.offset = offset;
        this.buffer = Buffer.allocUnsafe(0);
        this.encoding = "utf-8";
      }
      setBuffer(offset, buffer) {
        this.offset = offset;
        this.buffer = buffer;
      }
      int16() {
        const result = this.buffer.readInt16BE(this.offset);
        this.offset += 2;
        return result;
      }
      byte() {
        const result = this.buffer[this.offset];
        this.offset++;
        return result;
      }
      int32() {
        const result = this.buffer.readInt32BE(this.offset);
        this.offset += 4;
        return result;
      }
      uint32() {
        const result = this.buffer.readUInt32BE(this.offset);
        this.offset += 4;
        return result;
      }
      string(length) {
        const result = this.buffer.toString(this.encoding, this.offset, this.offset + length);
        this.offset += length;
        return result;
      }
      cstring() {
        const start2 = this.offset;
        let end = start2;
        while (this.buffer[end++]) {
        }
        this.offset = end;
        return this.buffer.toString(this.encoding, start2, end - 1);
      }
      bytes(length) {
        const result = this.buffer.slice(this.offset, this.offset + length);
        this.offset += length;
        return result;
      }
    };
    exports2.BufferReader = BufferReader;
  }
});

// migration/pos/server/node_modules/pg-protocol/dist/parser.js
var require_parser = __commonJS({
  "migration/pos/server/node_modules/pg-protocol/dist/parser.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Parser = void 0;
    var messages_1 = require_messages();
    var buffer_reader_1 = require_buffer_reader();
    var CODE_LENGTH = 1;
    var LEN_LENGTH = 4;
    var HEADER_LENGTH = CODE_LENGTH + LEN_LENGTH;
    var LATEINIT_LENGTH = -1;
    var emptyBuffer = Buffer.allocUnsafe(0);
    var Parser = class {
      constructor(opts) {
        this.buffer = emptyBuffer;
        this.bufferLength = 0;
        this.bufferOffset = 0;
        this.reader = new buffer_reader_1.BufferReader();
        if ((opts === null || opts === void 0 ? void 0 : opts.mode) === "binary") {
          throw new Error("Binary mode not supported yet");
        }
        this.mode = (opts === null || opts === void 0 ? void 0 : opts.mode) || "text";
      }
      parse(buffer, callback) {
        this.mergeBuffer(buffer);
        const bufferFullLength = this.bufferOffset + this.bufferLength;
        let offset = this.bufferOffset;
        while (offset + HEADER_LENGTH <= bufferFullLength) {
          const code = this.buffer[offset];
          const length = this.buffer.readUInt32BE(offset + CODE_LENGTH);
          const fullMessageLength = CODE_LENGTH + length;
          if (fullMessageLength + offset <= bufferFullLength) {
            const message = this.handlePacket(offset + HEADER_LENGTH, code, length, this.buffer);
            callback(message);
            offset += fullMessageLength;
          } else {
            break;
          }
        }
        if (offset === bufferFullLength) {
          this.buffer = emptyBuffer;
          this.bufferLength = 0;
          this.bufferOffset = 0;
        } else {
          this.bufferLength = bufferFullLength - offset;
          this.bufferOffset = offset;
        }
      }
      mergeBuffer(buffer) {
        if (this.bufferLength > 0) {
          const newLength = this.bufferLength + buffer.byteLength;
          const newFullLength = newLength + this.bufferOffset;
          if (newFullLength > this.buffer.byteLength) {
            let newBuffer;
            if (newLength <= this.buffer.byteLength && this.bufferOffset >= this.bufferLength) {
              newBuffer = this.buffer;
            } else {
              let newBufferLength = this.buffer.byteLength * 2;
              while (newLength >= newBufferLength) {
                newBufferLength *= 2;
              }
              newBuffer = Buffer.allocUnsafe(newBufferLength);
            }
            this.buffer.copy(newBuffer, 0, this.bufferOffset, this.bufferOffset + this.bufferLength);
            this.buffer = newBuffer;
            this.bufferOffset = 0;
          }
          buffer.copy(this.buffer, this.bufferOffset + this.bufferLength);
          this.bufferLength = newLength;
        } else {
          this.buffer = buffer;
          this.bufferOffset = 0;
          this.bufferLength = buffer.byteLength;
        }
      }
      handlePacket(offset, code, length, bytes) {
        const { reader } = this;
        reader.setBuffer(offset, bytes);
        let message;
        switch (code) {
          case 50:
            message = messages_1.bindComplete;
            break;
          case 49:
            message = messages_1.parseComplete;
            break;
          case 51:
            message = messages_1.closeComplete;
            break;
          case 110:
            message = messages_1.noData;
            break;
          case 115:
            message = messages_1.portalSuspended;
            break;
          case 99:
            message = messages_1.copyDone;
            break;
          case 87:
            message = messages_1.replicationStart;
            break;
          case 73:
            message = messages_1.emptyQuery;
            break;
          case 68:
            message = parseDataRowMessage(reader);
            break;
          case 67:
            message = parseCommandCompleteMessage(reader);
            break;
          case 90:
            message = parseReadyForQueryMessage(reader);
            break;
          case 65:
            message = parseNotificationMessage(reader);
            break;
          case 82:
            message = parseAuthenticationResponse(reader, length);
            break;
          case 83:
            message = parseParameterStatusMessage(reader);
            break;
          case 75:
            message = parseBackendKeyData(reader);
            break;
          case 69:
            message = parseErrorMessage(reader, "error");
            break;
          case 78:
            message = parseErrorMessage(reader, "notice");
            break;
          case 84:
            message = parseRowDescriptionMessage(reader);
            break;
          case 116:
            message = parseParameterDescriptionMessage(reader);
            break;
          case 71:
            message = parseCopyInMessage(reader);
            break;
          case 72:
            message = parseCopyOutMessage(reader);
            break;
          case 100:
            message = parseCopyData(reader, length);
            break;
          default:
            return new messages_1.DatabaseError("received invalid response: " + code.toString(16), length, "error");
        }
        reader.setBuffer(0, emptyBuffer);
        message.length = length;
        return message;
      }
    };
    exports2.Parser = Parser;
    var parseReadyForQueryMessage = (reader) => {
      const status = reader.string(1);
      return new messages_1.ReadyForQueryMessage(LATEINIT_LENGTH, status);
    };
    var parseCommandCompleteMessage = (reader) => {
      const text = reader.cstring();
      return new messages_1.CommandCompleteMessage(LATEINIT_LENGTH, text);
    };
    var parseCopyData = (reader, length) => {
      const chunk = reader.bytes(length - 4);
      return new messages_1.CopyDataMessage(LATEINIT_LENGTH, chunk);
    };
    var parseCopyInMessage = (reader) => parseCopyMessage(reader, "copyInResponse");
    var parseCopyOutMessage = (reader) => parseCopyMessage(reader, "copyOutResponse");
    var parseCopyMessage = (reader, messageName) => {
      const isBinary = reader.byte() !== 0;
      const columnCount = reader.int16();
      const message = new messages_1.CopyResponse(LATEINIT_LENGTH, messageName, isBinary, columnCount);
      for (let i = 0; i < columnCount; i++) {
        message.columnTypes[i] = reader.int16();
      }
      return message;
    };
    var parseNotificationMessage = (reader) => {
      const processId = reader.int32();
      const channel = reader.cstring();
      const payload = reader.cstring();
      return new messages_1.NotificationResponseMessage(LATEINIT_LENGTH, processId, channel, payload);
    };
    var parseRowDescriptionMessage = (reader) => {
      const fieldCount = reader.int16();
      const message = new messages_1.RowDescriptionMessage(LATEINIT_LENGTH, fieldCount);
      for (let i = 0; i < fieldCount; i++) {
        message.fields[i] = parseField(reader);
      }
      return message;
    };
    var parseField = (reader) => {
      const name = reader.cstring();
      const tableID = reader.uint32();
      const columnID = reader.int16();
      const dataTypeID = reader.uint32();
      const dataTypeSize = reader.int16();
      const dataTypeModifier = reader.int32();
      const mode = reader.int16() === 0 ? "text" : "binary";
      return new messages_1.Field(name, tableID, columnID, dataTypeID, dataTypeSize, dataTypeModifier, mode);
    };
    var parseParameterDescriptionMessage = (reader) => {
      const parameterCount = reader.int16();
      const message = new messages_1.ParameterDescriptionMessage(LATEINIT_LENGTH, parameterCount);
      for (let i = 0; i < parameterCount; i++) {
        message.dataTypeIDs[i] = reader.uint32();
      }
      return message;
    };
    var parseDataRowMessage = (reader) => {
      const fieldCount = reader.int16();
      const fields = new Array(fieldCount);
      for (let i = 0; i < fieldCount; i++) {
        const len = reader.int32();
        fields[i] = len === -1 ? null : reader.string(len);
      }
      return new messages_1.DataRowMessage(LATEINIT_LENGTH, fields);
    };
    var parseParameterStatusMessage = (reader) => {
      const name = reader.cstring();
      const value = reader.cstring();
      return new messages_1.ParameterStatusMessage(LATEINIT_LENGTH, name, value);
    };
    var parseBackendKeyData = (reader) => {
      const processID = reader.int32();
      const secretKey = reader.int32();
      return new messages_1.BackendKeyDataMessage(LATEINIT_LENGTH, processID, secretKey);
    };
    var parseAuthenticationResponse = (reader, length) => {
      const code = reader.int32();
      const message = {
        name: "authenticationOk",
        length
      };
      switch (code) {
        case 0:
          break;
        case 3:
          if (message.length === 8) {
            message.name = "authenticationCleartextPassword";
          }
          break;
        case 5:
          if (message.length === 12) {
            message.name = "authenticationMD5Password";
            const salt = reader.bytes(4);
            return new messages_1.AuthenticationMD5Password(LATEINIT_LENGTH, salt);
          }
          break;
        case 10:
          {
            message.name = "authenticationSASL";
            message.mechanisms = [];
            let mechanism;
            do {
              mechanism = reader.cstring();
              if (mechanism) {
                message.mechanisms.push(mechanism);
              }
            } while (mechanism);
          }
          break;
        case 11:
          message.name = "authenticationSASLContinue";
          message.data = reader.string(length - 8);
          break;
        case 12:
          message.name = "authenticationSASLFinal";
          message.data = reader.string(length - 8);
          break;
        default:
          throw new Error("Unknown authenticationOk message type " + code);
      }
      return message;
    };
    var parseErrorMessage = (reader, name) => {
      const fields = {};
      let fieldType = reader.string(1);
      while (fieldType !== "\0") {
        fields[fieldType] = reader.cstring();
        fieldType = reader.string(1);
      }
      const messageValue = fields.M;
      const message = name === "notice" ? new messages_1.NoticeMessage(LATEINIT_LENGTH, messageValue) : new messages_1.DatabaseError(messageValue, LATEINIT_LENGTH, name);
      message.severity = fields.S;
      message.code = fields.C;
      message.detail = fields.D;
      message.hint = fields.H;
      message.position = fields.P;
      message.internalPosition = fields.p;
      message.internalQuery = fields.q;
      message.where = fields.W;
      message.schema = fields.s;
      message.table = fields.t;
      message.column = fields.c;
      message.dataType = fields.d;
      message.constraint = fields.n;
      message.file = fields.F;
      message.line = fields.L;
      message.routine = fields.R;
      return message;
    };
  }
});

// migration/pos/server/node_modules/pg-protocol/dist/index.js
var require_dist = __commonJS({
  "migration/pos/server/node_modules/pg-protocol/dist/index.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.DatabaseError = exports2.serialize = void 0;
    exports2.parse = parse;
    var messages_1 = require_messages();
    Object.defineProperty(exports2, "DatabaseError", { enumerable: true, get: function() {
      return messages_1.DatabaseError;
    } });
    var serializer_1 = require_serializer();
    Object.defineProperty(exports2, "serialize", { enumerable: true, get: function() {
      return serializer_1.serialize;
    } });
    var parser_1 = require_parser();
    function parse(stream, callback) {
      const parser = new parser_1.Parser();
      stream.on("data", (buffer) => parser.parse(buffer, callback));
      return new Promise((resolve) => stream.on("end", () => resolve()));
    }
  }
});

// migration/pos/server/node_modules/pg-cloudflare/dist/empty.js
var require_empty = __commonJS({
  "migration/pos/server/node_modules/pg-cloudflare/dist/empty.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.default = {};
  }
});

// migration/pos/server/node_modules/pg/lib/stream.js
var require_stream = __commonJS({
  "migration/pos/server/node_modules/pg/lib/stream.js"(exports2, module2) {
    var { getStream, getSecureStream } = getStreamFuncs();
    module2.exports = {
      /**
       * Get a socket stream compatible with the current runtime environment.
       * @returns {Duplex}
       */
      getStream,
      /**
       * Get a TLS secured socket, compatible with the current environment,
       * using the socket and other settings given in `options`.
       * @returns {Duplex}
       */
      getSecureStream
    };
    function getNodejsStreamFuncs() {
      function getStream2(ssl) {
        const net = require("net");
        return new net.Socket();
      }
      function getSecureStream2(options) {
        const tls = require("tls");
        return tls.connect(options);
      }
      return {
        getStream: getStream2,
        getSecureStream: getSecureStream2
      };
    }
    function getCloudflareStreamFuncs() {
      function getStream2(ssl) {
        const { CloudflareSocket } = require_empty();
        return new CloudflareSocket(ssl);
      }
      function getSecureStream2(options) {
        options.socket.startTls(options);
        return options.socket;
      }
      return {
        getStream: getStream2,
        getSecureStream: getSecureStream2
      };
    }
    function isCloudflareRuntime() {
      if (typeof navigator === "object" && navigator !== null && typeof navigator.userAgent === "string") {
        return navigator.userAgent === "Cloudflare-Workers";
      }
      if (typeof Response === "function") {
        const resp = new Response(null, { cf: { thing: true } });
        if (typeof resp.cf === "object" && resp.cf !== null && resp.cf.thing) {
          return true;
        }
      }
      return false;
    }
    function getStreamFuncs() {
      if (isCloudflareRuntime()) {
        return getCloudflareStreamFuncs();
      }
      return getNodejsStreamFuncs();
    }
  }
});

// migration/pos/server/node_modules/pg/lib/connection.js
var require_connection = __commonJS({
  "migration/pos/server/node_modules/pg/lib/connection.js"(exports2, module2) {
    "use strict";
    var EventEmitter = require("events").EventEmitter;
    var { parse, serialize } = require_dist();
    var stream = require_stream();
    var { getStream } = stream;
    var flushBuffer = serialize.flush();
    var syncBuffer = serialize.sync();
    var endBuffer = serialize.end();
    var Connection = class extends EventEmitter {
      constructor(config) {
        super();
        config = config || {};
        this.stream = config.stream || getStream(config.ssl);
        if (typeof this.stream === "function") {
          this.stream = this.stream(config);
        }
        this._keepAlive = config.keepAlive;
        this._keepAliveInitialDelayMillis = config.keepAliveInitialDelayMillis;
        this.parsedStatements = {};
        this.submittedNamedStatements = {};
        this.ssl = config.ssl || false;
        this.sslNegotiation = config.sslNegotiation || "postgres";
        this._ending = false;
        this._emitMessage = false;
        const self = this;
        this.on("newListener", function(eventName) {
          if (eventName === "message") {
            self._emitMessage = true;
          }
        });
      }
      connect(port, host) {
        const self = this;
        this._connecting = true;
        this.stream.setNoDelay(true);
        this.stream.connect(port, host);
        this.stream.once("connect", function() {
          if (self._keepAlive) {
            self.stream.setKeepAlive(true, self._keepAliveInitialDelayMillis);
          }
          self.emit("connect");
        });
        const reportStreamError = function(error) {
          if (self._ending && (error.code === "ECONNRESET" || error.code === "EPIPE")) {
            return;
          }
          self.emit("error", error);
        };
        this.stream.on("error", reportStreamError);
        this.stream.on("close", function() {
          self.emit("end");
        });
        if (!this.ssl) {
          return this.attachListeners(this.stream);
        }
        if (this.sslNegotiation === "direct") {
          return this.stream.once("connect", function() {
            self.upgradeToSSL(host, reportStreamError);
          });
        }
        this.stream.once("data", function(buffer) {
          const responseCode = buffer.toString("utf8");
          switch (responseCode) {
            case "S":
              break;
            case "N":
              self.stream.end();
              return self.emit("error", new Error("The server does not support SSL connections"));
            default:
              self.stream.end();
              return self.emit("error", new Error("There was an error establishing an SSL connection"));
          }
          self.upgradeToSSL(host, reportStreamError);
        });
      }
      upgradeToSSL(host, reportStreamError) {
        const self = this;
        const options = {
          socket: self.stream
        };
        if (self.ssl !== true) {
          Object.assign(options, self.ssl);
          if ("key" in self.ssl) {
            options.key = self.ssl.key;
          }
        }
        if (self.sslNegotiation === "direct") {
          options.ALPNProtocols = ["postgresql"];
        }
        const net = require("net");
        if (net.isIP && net.isIP(host) === 0) {
          options.servername = host;
        }
        try {
          self.stream = stream.getSecureStream(options);
        } catch (err) {
          return self.emit("error", err);
        }
        self.attachListeners(self.stream);
        self.stream.on("error", reportStreamError);
        self.emit("sslconnect");
      }
      attachListeners(stream2) {
        parse(stream2, (msg) => {
          const eventName = msg.name === "error" ? "errorMessage" : msg.name;
          if (this._emitMessage) {
            this.emit("message", msg);
          }
          this.emit(eventName, msg);
        });
      }
      requestSsl() {
        this.stream.write(serialize.requestSsl());
      }
      startup(config) {
        this.stream.write(serialize.startup(config));
      }
      cancel(processID, secretKey) {
        this._send(serialize.cancel(processID, secretKey));
      }
      password(password) {
        this._send(serialize.password(password));
      }
      sendSASLInitialResponseMessage(mechanism, initialResponse) {
        this._send(serialize.sendSASLInitialResponseMessage(mechanism, initialResponse));
      }
      sendSCRAMClientFinalMessage(additionalData) {
        this._send(serialize.sendSCRAMClientFinalMessage(additionalData));
      }
      _send(buffer) {
        if (!this.stream.writable) {
          return false;
        }
        return this.stream.write(buffer);
      }
      query(text) {
        this._send(serialize.query(text));
      }
      // send parse message
      parse(query) {
        this._send(serialize.parse(query));
      }
      // send bind message
      bind(config) {
        this._send(serialize.bind(config));
      }
      // send execute message
      execute(config) {
        this._send(serialize.execute(config));
      }
      flush() {
        if (this.stream.writable) {
          this.stream.write(flushBuffer);
        }
      }
      sync() {
        this._ending = true;
        this._send(syncBuffer);
      }
      ref() {
        this.stream.ref();
      }
      unref() {
        this.stream.unref();
      }
      end() {
        this._ending = true;
        if (!this._connecting || !this.stream.writable) {
          this.stream.end();
          return;
        }
        return this.stream.write(endBuffer, () => {
          this.stream.end();
        });
      }
      close(msg) {
        this._send(serialize.close(msg));
      }
      describe(msg) {
        this._send(serialize.describe(msg));
      }
      sendCopyFromChunk(chunk) {
        this._send(serialize.copyData(chunk));
      }
      endCopyFrom() {
        this._send(serialize.copyDone());
      }
      sendCopyFail(msg) {
        this._send(serialize.copyFail(msg));
      }
    };
    module2.exports = Connection;
  }
});

// migration/pos/server/node_modules/split2/index.js
var require_split2 = __commonJS({
  "migration/pos/server/node_modules/split2/index.js"(exports2, module2) {
    "use strict";
    var { Transform } = require("stream");
    var { StringDecoder } = require("string_decoder");
    var kLast = /* @__PURE__ */ Symbol("last");
    var kDecoder = /* @__PURE__ */ Symbol("decoder");
    function transform(chunk, enc, cb) {
      let list;
      if (this.overflow) {
        const buf = this[kDecoder].write(chunk);
        list = buf.split(this.matcher);
        if (list.length === 1) return cb();
        list.shift();
        this.overflow = false;
      } else {
        this[kLast] += this[kDecoder].write(chunk);
        list = this[kLast].split(this.matcher);
      }
      this[kLast] = list.pop();
      for (let i = 0; i < list.length; i++) {
        try {
          push(this, this.mapper(list[i]));
        } catch (error) {
          return cb(error);
        }
      }
      this.overflow = this[kLast].length > this.maxLength;
      if (this.overflow && !this.skipOverflow) {
        cb(new Error("maximum buffer reached"));
        return;
      }
      cb();
    }
    function flush(cb) {
      this[kLast] += this[kDecoder].end();
      if (this[kLast]) {
        try {
          push(this, this.mapper(this[kLast]));
        } catch (error) {
          return cb(error);
        }
      }
      cb();
    }
    function push(self, val) {
      if (val !== void 0) {
        self.push(val);
      }
    }
    function noop(incoming) {
      return incoming;
    }
    function split(matcher, mapper, options) {
      matcher = matcher || /\r?\n/;
      mapper = mapper || noop;
      options = options || {};
      switch (arguments.length) {
        case 1:
          if (typeof matcher === "function") {
            mapper = matcher;
            matcher = /\r?\n/;
          } else if (typeof matcher === "object" && !(matcher instanceof RegExp) && !matcher[Symbol.split]) {
            options = matcher;
            matcher = /\r?\n/;
          }
          break;
        case 2:
          if (typeof matcher === "function") {
            options = mapper;
            mapper = matcher;
            matcher = /\r?\n/;
          } else if (typeof mapper === "object") {
            options = mapper;
            mapper = noop;
          }
      }
      options = Object.assign({}, options);
      options.autoDestroy = true;
      options.transform = transform;
      options.flush = flush;
      options.readableObjectMode = true;
      const stream = new Transform(options);
      stream[kLast] = "";
      stream[kDecoder] = new StringDecoder("utf8");
      stream.matcher = matcher;
      stream.mapper = mapper;
      stream.maxLength = options.maxLength;
      stream.skipOverflow = options.skipOverflow || false;
      stream.overflow = false;
      stream._destroy = function(err, cb) {
        this._writableState.errorEmitted = false;
        cb(err);
      };
      return stream;
    }
    module2.exports = split;
  }
});

// migration/pos/server/node_modules/pgpass/lib/helper.js
var require_helper = __commonJS({
  "migration/pos/server/node_modules/pgpass/lib/helper.js"(exports2, module2) {
    "use strict";
    var path2 = require("path");
    var Stream = require("stream").Stream;
    var split = require_split2();
    var util = require("util");
    var defaultPort = 5432;
    var isWin = process.platform === "win32";
    var warnStream = process.stderr;
    var S_IRWXG = 56;
    var S_IRWXO = 7;
    var S_IFMT = 61440;
    var S_IFREG = 32768;
    function isRegFile(mode) {
      return (mode & S_IFMT) == S_IFREG;
    }
    var fieldNames = ["host", "port", "database", "user", "password"];
    var nrOfFields = fieldNames.length;
    var passKey = fieldNames[nrOfFields - 1];
    function warn() {
      var isWritable = warnStream instanceof Stream && true === warnStream.writable;
      if (isWritable) {
        var args = Array.prototype.slice.call(arguments).concat("\n");
        warnStream.write(util.format.apply(util, args));
      }
    }
    Object.defineProperty(module2.exports, "isWin", {
      get: function() {
        return isWin;
      },
      set: function(val) {
        isWin = val;
      }
    });
    module2.exports.warnTo = function(stream) {
      var old = warnStream;
      warnStream = stream;
      return old;
    };
    module2.exports.getFileName = function(rawEnv) {
      var env = rawEnv || process.env;
      var file = env.PGPASSFILE || (isWin ? path2.join(env.APPDATA || "./", "postgresql", "pgpass.conf") : path2.join(env.HOME || "./", ".pgpass"));
      return file;
    };
    module2.exports.usePgPass = function(stats, fname) {
      if (Object.prototype.hasOwnProperty.call(process.env, "PGPASSWORD")) {
        return false;
      }
      if (isWin) {
        return true;
      }
      fname = fname || "<unkn>";
      if (!isRegFile(stats.mode)) {
        warn('WARNING: password file "%s" is not a plain file', fname);
        return false;
      }
      if (stats.mode & (S_IRWXG | S_IRWXO)) {
        warn('WARNING: password file "%s" has group or world access; permissions should be u=rw (0600) or less', fname);
        return false;
      }
      return true;
    };
    var matcher = module2.exports.match = function(connInfo, entry) {
      return fieldNames.slice(0, -1).reduce(function(prev, field, idx) {
        if (idx == 1) {
          if (Number(connInfo[field] || defaultPort) === Number(entry[field])) {
            return prev && true;
          }
        }
        return prev && (entry[field] === "*" || entry[field] === connInfo[field]);
      }, true);
    };
    module2.exports.getPassword = function(connInfo, stream, cb) {
      var pass;
      var lineStream = stream.pipe(split());
      function onLine(line) {
        var entry = parseLine(line);
        if (entry && isValidEntry(entry) && matcher(connInfo, entry)) {
          pass = entry[passKey];
          lineStream.end();
        }
      }
      var onEnd = function() {
        stream.destroy();
        cb(pass);
      };
      var onErr = function(err) {
        stream.destroy();
        warn("WARNING: error on reading file: %s", err);
        cb(void 0);
      };
      stream.on("error", onErr);
      lineStream.on("data", onLine).on("end", onEnd).on("error", onErr);
    };
    var parseLine = module2.exports.parseLine = function(line) {
      if (line.length < 11 || line.match(/^\s+#/)) {
        return null;
      }
      var curChar = "";
      var prevChar = "";
      var fieldIdx = 0;
      var startIdx = 0;
      var endIdx = 0;
      var obj = {};
      var isLastField = false;
      var addToObj = function(idx, i0, i1) {
        var field = line.substring(i0, i1);
        if (!Object.hasOwnProperty.call(process.env, "PGPASS_NO_DEESCAPE")) {
          field = field.replace(/\\([:\\])/g, "$1");
        }
        obj[fieldNames[idx]] = field;
      };
      for (var i = 0; i < line.length - 1; i += 1) {
        curChar = line.charAt(i + 1);
        prevChar = line.charAt(i);
        isLastField = fieldIdx == nrOfFields - 1;
        if (isLastField) {
          addToObj(fieldIdx, startIdx);
          break;
        }
        if (i >= 0 && curChar == ":" && prevChar !== "\\") {
          addToObj(fieldIdx, startIdx, i + 1);
          startIdx = i + 2;
          fieldIdx += 1;
        }
      }
      obj = Object.keys(obj).length === nrOfFields ? obj : null;
      return obj;
    };
    var isValidEntry = module2.exports.isValidEntry = function(entry) {
      var rules = {
        // host
        0: function(x) {
          return x.length > 0;
        },
        // port
        1: function(x) {
          if (x === "*") {
            return true;
          }
          x = Number(x);
          return isFinite(x) && x > 0 && x < 9007199254740992 && Math.floor(x) === x;
        },
        // database
        2: function(x) {
          return x.length > 0;
        },
        // username
        3: function(x) {
          return x.length > 0;
        },
        // password
        4: function(x) {
          return x.length > 0;
        }
      };
      for (var idx = 0; idx < fieldNames.length; idx += 1) {
        var rule = rules[idx];
        var value = entry[fieldNames[idx]] || "";
        var res = rule(value);
        if (!res) {
          return false;
        }
      }
      return true;
    };
  }
});

// migration/pos/server/node_modules/pgpass/lib/index.js
var require_lib = __commonJS({
  "migration/pos/server/node_modules/pgpass/lib/index.js"(exports2, module2) {
    "use strict";
    var path2 = require("path");
    var fs2 = require("fs");
    var helper = require_helper();
    module2.exports = function(connInfo, cb) {
      var file = helper.getFileName();
      fs2.stat(file, function(err, stat) {
        if (err || !helper.usePgPass(stat, file)) {
          return cb(void 0);
        }
        var st = fs2.createReadStream(file);
        helper.getPassword(connInfo, st, cb);
      });
    };
    module2.exports.warnTo = helper.warnTo;
  }
});

// migration/pos/server/node_modules/pg/lib/client.js
var require_client = __commonJS({
  "migration/pos/server/node_modules/pg/lib/client.js"(exports2, module2) {
    var EventEmitter = require("events").EventEmitter;
    var utils = require_utils();
    var nodeUtils = require("util");
    var sasl = require_sasl();
    var TypeOverrides = require_type_overrides();
    var ConnectionParameters = require_connection_parameters();
    var Query = require_query();
    var defaults = require_defaults();
    var Connection = require_connection();
    var crypto = require_utils2();
    var activeQueryDeprecationNotice = nodeUtils.deprecate(
      () => {
      },
      "Client.activeQuery is deprecated and will be removed in pg@9.0"
    );
    var queryQueueDeprecationNotice = nodeUtils.deprecate(
      () => {
      },
      "Client.queryQueue is deprecated and will be removed in pg@9.0."
    );
    var pgPassDeprecationNotice = nodeUtils.deprecate(
      () => {
      },
      "pgpass support is deprecated and will be removed in pg@9.0. You can provide an async function as the password property to the Client/Pool constructor that returns a password instead. Within this function you can call the pgpass module in your own code."
    );
    var byoPromiseDeprecationNotice = nodeUtils.deprecate(
      () => {
      },
      "Passing a custom Promise implementation to the Client/Pool constructor is deprecated and will be removed in pg@9.0."
    );
    var queryQueueLengthDeprecationNotice = nodeUtils.deprecate(
      () => {
      },
      "Calling client.query() when the client is already executing a query is deprecated and will be removed in pg@9.0. Use async/await or an external async flow control mechanism instead."
    );
    function coerceNumberOrDefault(value, defaultValue) {
      if (typeof value === "number") {
        return Number.isFinite(value) ? value : defaultValue;
      }
      if (typeof value === "string" && value.trim() !== "") {
        const n = Number(value);
        return Number.isFinite(n) ? n : defaultValue;
      }
      return defaultValue;
    }
    var Client = class extends EventEmitter {
      constructor(config) {
        super();
        this.connectionParameters = new ConnectionParameters(config);
        this.user = this.connectionParameters.user;
        this.database = this.connectionParameters.database;
        this.port = this.connectionParameters.port;
        this.host = this.connectionParameters.host;
        Object.defineProperty(this, "password", {
          configurable: true,
          enumerable: false,
          writable: true,
          value: this.connectionParameters.password
        });
        this.replication = this.connectionParameters.replication;
        const c = config || {};
        if (c.Promise) {
          byoPromiseDeprecationNotice();
        }
        this._Promise = c.Promise || global.Promise;
        this._types = new TypeOverrides(c.types);
        this._ending = false;
        this._ended = false;
        this._connecting = false;
        this._connected = false;
        this._connectionError = false;
        this._queryable = true;
        this._activeQuery = null;
        this._txStatus = null;
        this.enableChannelBinding = Boolean(c.enableChannelBinding);
        this.scramMaxIterations = coerceNumberOrDefault(c.scramMaxIterations, sasl.DEFAULT_MAX_SCRAM_ITERATIONS);
        this.connection = c.connection || new Connection({
          stream: c.stream,
          ssl: this.connectionParameters.ssl,
          sslNegotiation: this.connectionParameters.sslnegotiation,
          keepAlive: c.keepAlive || false,
          keepAliveInitialDelayMillis: c.keepAliveInitialDelayMillis || 0,
          encoding: this.connectionParameters.client_encoding || "utf8"
        });
        this._queryQueue = [];
        this._sentQueryQueue = [];
        this.pipeline = Boolean(c.pipeline);
        this.binary = c.binary || defaults.binary;
        this.processID = null;
        this.secretKey = null;
        this.ssl = this.connectionParameters.ssl || false;
        this.sslNegotiation = this.connectionParameters.sslnegotiation || "postgres";
        if (this.ssl && this.ssl.key) {
          Object.defineProperty(this.ssl, "key", {
            enumerable: false
          });
        }
        this._connectionTimeoutMillis = c.connectionTimeoutMillis || 0;
      }
      get activeQuery() {
        activeQueryDeprecationNotice();
        return this._activeQuery;
      }
      set activeQuery(val) {
        activeQueryDeprecationNotice();
        this._activeQuery = val;
      }
      _getActiveQuery() {
        return this._activeQuery;
      }
      _errorAllQueries(err) {
        const enqueueError = (query) => {
          process.nextTick(() => {
            query.handleError(err, this.connection);
          });
        };
        const activeQuery = this._getActiveQuery();
        if (activeQuery) {
          enqueueError(activeQuery);
          this._activeQuery = null;
        }
        this._sentQueryQueue.forEach(enqueueError);
        this._sentQueryQueue.length = 0;
        this._queryQueue.forEach(enqueueError);
        this._queryQueue.length = 0;
      }
      _connect(callback) {
        const self = this;
        const con = this.connection;
        this._connectionCallback = callback;
        if (this._connecting || this._connected) {
          const err = new Error("Client has already been connected. You cannot reuse a client.");
          process.nextTick(() => {
            callback(err);
          });
          return;
        }
        this._connecting = true;
        if (this._connectionTimeoutMillis > 0) {
          this.connectionTimeoutHandle = setTimeout(() => {
            con._ending = true;
            con.stream.destroy(new Error("timeout expired"));
          }, this._connectionTimeoutMillis);
          if (this.connectionTimeoutHandle.unref) {
            this.connectionTimeoutHandle.unref();
          }
        }
        if (this.host && this.host.indexOf("/") === 0) {
          con.connect(this.host + "/.s.PGSQL." + this.port);
        } else {
          con.connect(this.port, this.host);
        }
        con.on("connect", function() {
          if (self.ssl) {
            if (self.sslNegotiation !== "direct") {
              con.requestSsl();
            }
          } else {
            con.startup(self.getStartupConf());
          }
        });
        con.on("sslconnect", function() {
          con.startup(self.getStartupConf());
        });
        this._attachListeners(con);
        con.once("end", () => {
          const error = this._ending ? new Error("Connection terminated") : new Error("Connection terminated unexpectedly");
          clearTimeout(this.connectionTimeoutHandle);
          this._errorAllQueries(error);
          this._ended = true;
          if (!this._ending) {
            if (this._connecting && !this._connectionError) {
              if (this._connectionCallback) {
                this._connectionCallback(error);
              } else {
                this._handleErrorEvent(error);
              }
            } else if (!this._connectionError) {
              this._handleErrorEvent(error);
            }
          }
          process.nextTick(() => {
            this.emit("end");
          });
        });
      }
      connect(callback) {
        if (callback) {
          this._connect(callback);
          return;
        }
        return new this._Promise((resolve, reject) => {
          this._connect((error) => {
            if (error) {
              reject(error);
            } else {
              resolve(this);
            }
          });
        });
      }
      _attachListeners(con) {
        con.on("authenticationCleartextPassword", this._handleAuthCleartextPassword.bind(this));
        con.on("authenticationMD5Password", this._handleAuthMD5Password.bind(this));
        con.on("authenticationSASL", this._handleAuthSASL.bind(this));
        con.on("authenticationSASLContinue", this._handleAuthSASLContinue.bind(this));
        con.on("authenticationSASLFinal", this._handleAuthSASLFinal.bind(this));
        con.on("backendKeyData", this._handleBackendKeyData.bind(this));
        con.on("error", this._handleErrorEvent.bind(this));
        con.on("errorMessage", this._handleErrorMessage.bind(this));
        con.on("readyForQuery", this._handleReadyForQuery.bind(this));
        con.on("notice", this._handleNotice.bind(this));
        con.on("rowDescription", this._handleRowDescription.bind(this));
        con.on("dataRow", this._handleDataRow.bind(this));
        con.on("portalSuspended", this._handlePortalSuspended.bind(this));
        con.on("emptyQuery", this._handleEmptyQuery.bind(this));
        con.on("commandComplete", this._handleCommandComplete.bind(this));
        con.on("parseComplete", this._handleParseComplete.bind(this));
        con.on("copyInResponse", this._handleCopyInResponse.bind(this));
        con.on("copyData", this._handleCopyData.bind(this));
        con.on("notification", this._handleNotification.bind(this));
      }
      _getPassword(cb) {
        const con = this.connection;
        if (typeof this.password === "function") {
          this._Promise.resolve().then(() => this.password(this.connectionParameters)).then((pass) => {
            if (pass !== void 0) {
              if (typeof pass !== "string") {
                con.emit("error", new TypeError("Password must be a string"));
                return;
              }
              this.connectionParameters.password = this.password = pass;
            } else {
              this.connectionParameters.password = this.password = null;
            }
            cb();
          }).catch((err) => {
            con.emit("error", err);
          });
        } else if (this.password !== null) {
          cb();
        } else {
          try {
            const pgPass = require_lib();
            pgPass(this.connectionParameters, (pass) => {
              if (void 0 !== pass) {
                pgPassDeprecationNotice();
                this.connectionParameters.password = this.password = pass;
              }
              cb();
            });
          } catch (e) {
            this.emit("error", e);
          }
        }
      }
      _handleAuthCleartextPassword(msg) {
        this._getPassword(() => {
          this.connection.password(this.password);
        });
      }
      _handleAuthMD5Password(msg) {
        this._getPassword(async () => {
          try {
            const hashedPassword = await crypto.postgresMd5PasswordHash(this.user, this.password, msg.salt);
            this.connection.password(hashedPassword);
          } catch (e) {
            this.emit("error", e);
          }
        });
      }
      _handleAuthSASL(msg) {
        this._getPassword(() => {
          try {
            this.saslSession = sasl.startSession(
              msg.mechanisms,
              this.enableChannelBinding && this.connection.stream,
              this.scramMaxIterations
            );
            this.connection.sendSASLInitialResponseMessage(this.saslSession.mechanism, this.saslSession.response);
          } catch (err) {
            this.connection.emit("error", err);
          }
        });
      }
      async _handleAuthSASLContinue(msg) {
        try {
          await sasl.continueSession(
            this.saslSession,
            this.password,
            msg.data,
            this.enableChannelBinding && this.connection.stream
          );
          this.connection.sendSCRAMClientFinalMessage(this.saslSession.response);
        } catch (err) {
          this.connection.emit("error", err);
        }
      }
      _handleAuthSASLFinal(msg) {
        try {
          sasl.finalizeSession(this.saslSession, msg.data);
          this.saslSession = null;
        } catch (err) {
          this.connection.emit("error", err);
        }
      }
      _handleBackendKeyData(msg) {
        this.processID = msg.processID;
        this.secretKey = msg.secretKey;
      }
      _handleReadyForQuery(msg) {
        if (this._connecting) {
          this._connecting = false;
          this._connected = true;
          clearTimeout(this.connectionTimeoutHandle);
          if (this._connectionCallback) {
            this._connectionCallback(null, this);
            this._connectionCallback = null;
          }
          this.emit("connect");
        }
        const activeQuery = this._getActiveQuery();
        this._activeQuery = null;
        this._txStatus = msg?.status ?? null;
        this.readyForQuery = true;
        if (activeQuery) {
          activeQuery.handleReadyForQuery(this.connection);
        }
        this._pulseQueryQueue();
      }
      // if we receive an error event or error message
      // during the connection process we handle it here
      _handleErrorWhileConnecting(err) {
        if (this._connectionError) {
          return;
        }
        this._connectionError = true;
        clearTimeout(this.connectionTimeoutHandle);
        if (this._connectionCallback) {
          return this._connectionCallback(err);
        }
        this.emit("error", err);
      }
      // if we're connected and we receive an error event from the connection
      // this means the socket is dead - do a hard abort of all queries and emit
      // the socket error on the client as well
      _handleErrorEvent(err) {
        if (this._connecting) {
          return this._handleErrorWhileConnecting(err);
        }
        this._queryable = false;
        this._errorAllQueries(err);
        this.emit("error", err);
      }
      // handle error messages from the postgres backend
      _handleErrorMessage(msg) {
        if (this._connecting) {
          return this._handleErrorWhileConnecting(msg);
        }
        const activeQuery = this._getActiveQuery();
        if (!activeQuery) {
          this._handleErrorEvent(msg);
          return;
        }
        this._activeQuery = null;
        if (activeQuery.name) {
          delete this.connection.submittedNamedStatements[activeQuery.name];
        }
        activeQuery.handleError(msg, this.connection);
      }
      _handleRowDescription(msg) {
        const activeQuery = this._getActiveQuery();
        if (activeQuery == null) {
          const error = new Error("Received unexpected rowDescription message from backend.");
          this._handleErrorEvent(error);
          return;
        }
        activeQuery.handleRowDescription(msg);
      }
      _handleDataRow(msg) {
        const activeQuery = this._getActiveQuery();
        if (activeQuery == null) {
          const error = new Error("Received unexpected dataRow message from backend.");
          this._handleErrorEvent(error);
          return;
        }
        activeQuery.handleDataRow(msg);
      }
      _handlePortalSuspended(msg) {
        const activeQuery = this._getActiveQuery();
        if (activeQuery == null) {
          const error = new Error("Received unexpected portalSuspended message from backend.");
          this._handleErrorEvent(error);
          return;
        }
        activeQuery.handlePortalSuspended(this.connection);
      }
      _handleEmptyQuery(msg) {
        const activeQuery = this._getActiveQuery();
        if (activeQuery == null) {
          const error = new Error("Received unexpected emptyQuery message from backend.");
          this._handleErrorEvent(error);
          return;
        }
        activeQuery.handleEmptyQuery(this.connection);
      }
      _handleCommandComplete(msg) {
        const activeQuery = this._getActiveQuery();
        if (activeQuery == null) {
          const error = new Error("Received unexpected commandComplete message from backend.");
          this._handleErrorEvent(error);
          return;
        }
        activeQuery.handleCommandComplete(msg, this.connection);
      }
      _handleParseComplete() {
        const activeQuery = this._getActiveQuery();
        if (activeQuery == null) {
          const error = new Error("Received unexpected parseComplete message from backend.");
          this._handleErrorEvent(error);
          return;
        }
        if (activeQuery.name) {
          this.connection.parsedStatements[activeQuery.name] = activeQuery.text;
          delete this.connection.submittedNamedStatements[activeQuery.name];
        }
      }
      _handleCopyInResponse(msg) {
        const activeQuery = this._getActiveQuery();
        if (activeQuery == null) {
          const error = new Error("Received unexpected copyInResponse message from backend.");
          this._handleErrorEvent(error);
          return;
        }
        activeQuery.handleCopyInResponse(this.connection);
      }
      _handleCopyData(msg) {
        const activeQuery = this._getActiveQuery();
        if (activeQuery == null) {
          const error = new Error("Received unexpected copyData message from backend.");
          this._handleErrorEvent(error);
          return;
        }
        activeQuery.handleCopyData(msg, this.connection);
      }
      _handleNotification(msg) {
        this.emit("notification", msg);
      }
      _handleNotice(msg) {
        this.emit("notice", msg);
      }
      getStartupConf() {
        const params = this.connectionParameters;
        const data = {
          user: params.user,
          database: params.database
        };
        const appName = params.application_name || params.fallback_application_name;
        if (appName) {
          data.application_name = appName;
        }
        if (params.replication) {
          data.replication = "" + params.replication;
        }
        if (params.statement_timeout) {
          data.statement_timeout = String(parseInt(params.statement_timeout, 10));
        }
        if (params.lock_timeout) {
          data.lock_timeout = String(parseInt(params.lock_timeout, 10));
        }
        if (params.idle_in_transaction_session_timeout) {
          data.idle_in_transaction_session_timeout = String(parseInt(params.idle_in_transaction_session_timeout, 10));
        }
        if (params.options) {
          data.options = params.options;
        }
        return data;
      }
      cancel(client, query) {
        if (client.activeQuery === query) {
          const con = this.connection;
          if (this.host && this.host.indexOf("/") === 0) {
            con.connect(this.host + "/.s.PGSQL." + this.port);
          } else {
            con.connect(this.port, this.host);
          }
          con.on("connect", function() {
            con.cancel(client.processID, client.secretKey);
          });
        } else if (client._queryQueue.indexOf(query) !== -1) {
          client._queryQueue.splice(client._queryQueue.indexOf(query), 1);
        } else if (client._sentQueryQueue.indexOf(query) !== -1) {
          query.callback = () => {
          };
        }
      }
      setTypeParser(oid, format, parseFn) {
        return this._types.setTypeParser(oid, format, parseFn);
      }
      getTypeParser(oid, format) {
        return this._types.getTypeParser(oid, format);
      }
      // escapeIdentifier and escapeLiteral moved to utility functions & exported
      // on PG
      // re-exported here for backwards compatibility
      escapeIdentifier(str) {
        return utils.escapeIdentifier(str);
      }
      escapeLiteral(str) {
        return utils.escapeLiteral(str);
      }
      _pulseQueryQueue() {
        if (this.pipeline) {
          this._pulsePipelinedQueryQueue();
          return;
        }
        if (this.readyForQuery === true) {
          this._activeQuery = this._queryQueue.shift();
          const activeQuery = this._getActiveQuery();
          if (activeQuery) {
            this.readyForQuery = false;
            this.hasExecuted = true;
            const queryError = activeQuery.submit(this.connection);
            if (queryError) {
              process.nextTick(() => {
                activeQuery.handleError(queryError, this.connection);
                this.readyForQuery = true;
                this._pulseQueryQueue();
              });
            }
          } else if (this.hasExecuted) {
            this._activeQuery = null;
            this.emit("drain");
          }
        }
      }
      _pulsePipelinedQueryQueue() {
        if (!this._connected || !this._queryable) {
          return;
        }
        while (this._queryQueue.length > 0) {
          const query = this._queryQueue.shift();
          this.hasExecuted = true;
          const queryError = query.submit(this.connection);
          if (queryError) {
            process.nextTick(() => {
              query.handleError(queryError, this.connection);
            });
            continue;
          }
          this._sentQueryQueue.push(query);
        }
        if (this.readyForQuery && !this._activeQuery && this._sentQueryQueue.length > 0) {
          this._activeQuery = this._sentQueryQueue.shift();
          this.readyForQuery = false;
        }
        if (!this._activeQuery && this._sentQueryQueue.length === 0 && this._queryQueue.length === 0 && this.hasExecuted) {
          this.emit("drain");
        }
      }
      query(config, values, callback) {
        let query;
        let result;
        if (config == null) {
          throw new TypeError("Client was passed a null or undefined query");
        }
        if (typeof config.submit === "function") {
          result = query = config;
          if (!query.callback) {
            if (typeof values === "function") {
              query.callback = values;
            } else if (callback) {
              query.callback = callback;
            }
          }
        } else {
          query = new Query(config, values, callback);
          if (!query.callback) {
            result = new this._Promise((resolve, reject) => {
              query.callback = (err, res) => err ? reject(err) : resolve(res);
            }).catch((err) => {
              Error.captureStackTrace(err);
              throw err;
            });
          } else if (typeof query.callback !== "function") {
            throw new TypeError("callback is not a function");
          }
        }
        const readTimeout = config.query_timeout || this.connectionParameters.query_timeout;
        if (readTimeout) {
          const queryCallback = query.callback || (() => {
          });
          const readTimeoutTimer = setTimeout(() => {
            const error = new Error("Query read timeout");
            process.nextTick(() => {
              query.handleError(error, this.connection);
            });
            queryCallback(error);
            query.callback = () => {
            };
            const index = this._queryQueue.indexOf(query);
            if (index > -1) {
              this._queryQueue.splice(index, 1);
            } else if (this.pipeline) {
              this.connection.stream.destroy();
              return;
            }
            this._pulseQueryQueue();
          }, readTimeout);
          query.callback = (err, res) => {
            clearTimeout(readTimeoutTimer);
            queryCallback(err, res);
          };
        }
        if (this.binary && !query.binary) {
          query.binary = true;
        }
        if (query._result && !query._result._types) {
          query._result._types = this._types;
        }
        if (!this._queryable) {
          process.nextTick(() => {
            query.handleError(new Error("Client has encountered a connection error and is not queryable"), this.connection);
          });
          return result;
        }
        if (this._ending) {
          process.nextTick(() => {
            query.handleError(new Error("Client was closed and is not queryable"), this.connection);
          });
          return result;
        }
        if (this._queryQueue.length > 0 && !this.pipeline) {
          queryQueueLengthDeprecationNotice();
        }
        this._queryQueue.push(query);
        this._pulseQueryQueue();
        return result;
      }
      ref() {
        this.connection.ref();
      }
      unref() {
        this.connection.unref();
      }
      getTransactionStatus() {
        return this._txStatus;
      }
      end(cb) {
        this._ending = true;
        if (!this.connection._connecting || this._ended) {
          if (cb) {
            cb();
            return;
          } else {
            return this._Promise.resolve();
          }
        }
        if (!this._queryable) {
          this.connection.stream.destroy();
        } else if (this.pipeline && (this._getActiveQuery() || this._sentQueryQueue.length > 0 || this._queryQueue.length > 0)) {
          this.once("drain", () => this.connection.end());
        } else if (this._getActiveQuery()) {
          this.connection.stream.destroy();
        } else {
          this.connection.end();
        }
        if (cb) {
          this.connection.once("end", cb);
        } else {
          return new this._Promise((resolve) => {
            this.connection.once("end", resolve);
          });
        }
      }
      get queryQueue() {
        queryQueueDeprecationNotice();
        return this._queryQueue;
      }
    };
    Client.Query = Query;
    module2.exports = Client;
  }
});

// migration/pos/server/node_modules/pg-pool/index.js
var require_pg_pool = __commonJS({
  "migration/pos/server/node_modules/pg-pool/index.js"(exports2, module2) {
    "use strict";
    var EventEmitter = require("events").EventEmitter;
    var NOOP = function() {
    };
    var removeWhere = (list, predicate) => {
      const i = list.findIndex(predicate);
      return i === -1 ? void 0 : list.splice(i, 1)[0];
    };
    var IdleItem = class {
      constructor(client, idleListener, timeoutId) {
        this.client = client;
        this.idleListener = idleListener;
        this.timeoutId = timeoutId;
      }
    };
    var PendingItem = class {
      constructor(callback) {
        this.callback = callback;
      }
    };
    function throwOnDoubleRelease() {
      throw new Error("Release called on client which has already been released to the pool.");
    }
    function promisify(Promise2, callback) {
      if (callback) {
        return { callback, result: void 0 };
      }
      let rej;
      let res;
      const cb = function(err, client) {
        err ? rej(err) : res(client);
      };
      const result = new Promise2(function(resolve, reject) {
        res = resolve;
        rej = reject;
      }).catch((err) => {
        Error.captureStackTrace(err);
        throw err;
      });
      return { callback: cb, result };
    }
    function makeIdleListener(pool, client) {
      return function idleListener(err) {
        err.client = client;
        client.removeListener("error", idleListener);
        client.on("error", () => {
          pool.log("additional client error after disconnection due to error", err);
        });
        pool._remove(client);
        pool.emit("error", err, client);
      };
    }
    var Pool2 = class extends EventEmitter {
      constructor(options, Client) {
        super();
        this.options = Object.assign({}, options);
        if (options != null && "password" in options) {
          Object.defineProperty(this.options, "password", {
            configurable: true,
            enumerable: false,
            writable: true,
            value: options.password
          });
        }
        if (options != null && options.ssl && options.ssl.key) {
          Object.defineProperty(this.options.ssl, "key", {
            enumerable: false
          });
        }
        this.options.max = this.options.max || this.options.poolSize || 10;
        this.options.min = this.options.min || 0;
        this.options.maxUses = this.options.maxUses || Infinity;
        this.options.allowExitOnIdle = this.options.allowExitOnIdle || false;
        this.options.maxLifetimeSeconds = this.options.maxLifetimeSeconds || 0;
        this.log = this.options.log || function() {
        };
        this.Client = this.options.Client || Client || require_lib2().Client;
        this.Promise = this.options.Promise || global.Promise;
        if (typeof this.options.idleTimeoutMillis === "undefined") {
          this.options.idleTimeoutMillis = 1e4;
        }
        this._clients = [];
        this._idle = [];
        this._expired = /* @__PURE__ */ new WeakSet();
        this._pendingQueue = [];
        this._endCallback = void 0;
        this.ending = false;
        this.ended = false;
      }
      _promiseTry(f) {
        const Promise2 = this.Promise;
        if (typeof Promise2.try === "function") {
          return Promise2.try(f);
        }
        return new Promise2((resolve) => resolve(f()));
      }
      _isFull() {
        return this._clients.length >= this.options.max;
      }
      _isAboveMin() {
        return this._clients.length > this.options.min;
      }
      _pulseQueue() {
        this.log("pulse queue");
        if (this.ended) {
          this.log("pulse queue ended");
          return;
        }
        if (this.ending) {
          this.log("pulse queue on ending");
          if (this._idle.length) {
            this._idle.slice().map((item) => {
              this._remove(item.client);
            });
          }
          if (!this._clients.length) {
            this.ended = true;
            this._endCallback();
          }
          return;
        }
        if (!this._pendingQueue.length) {
          this.log("no queued requests");
          return;
        }
        if (!this._idle.length && this._isFull()) {
          return;
        }
        const pendingItem = this._pendingQueue.shift();
        if (this._idle.length) {
          const idleItem = this._idle.pop();
          clearTimeout(idleItem.timeoutId);
          const client = idleItem.client;
          client.ref && client.ref();
          const idleListener = idleItem.idleListener;
          return this._acquireClient(client, pendingItem, idleListener, false);
        }
        if (!this._isFull()) {
          return this.newClient(pendingItem);
        }
        throw new Error("unexpected condition");
      }
      _remove(client, callback) {
        const removed = removeWhere(this._idle, (item) => item.client === client);
        if (removed !== void 0) {
          clearTimeout(removed.timeoutId);
        }
        this._clients = this._clients.filter((c) => c !== client);
        const context = this;
        client.end(() => {
          context.emit("remove", client);
          if (typeof callback === "function") {
            callback();
          }
        });
      }
      connect(cb) {
        if (this.ending) {
          const err = new Error("Cannot use a pool after calling end on the pool");
          return cb ? cb(err) : this.Promise.reject(err);
        }
        const response = promisify(this.Promise, cb);
        const result = response.result;
        if (this._isFull() || this._idle.length) {
          if (this._idle.length) {
            process.nextTick(() => this._pulseQueue());
          }
          if (!this.options.connectionTimeoutMillis) {
            this._pendingQueue.push(new PendingItem(response.callback));
            return result;
          }
          const queueCallback = (err, res, done) => {
            clearTimeout(tid);
            response.callback(err, res, done);
          };
          const pendingItem = new PendingItem(queueCallback);
          const tid = setTimeout(() => {
            removeWhere(this._pendingQueue, (i) => i.callback === queueCallback);
            pendingItem.timedOut = true;
            response.callback(new Error("timeout exceeded when trying to connect"));
          }, this.options.connectionTimeoutMillis);
          if (tid.unref) {
            tid.unref();
          }
          this._pendingQueue.push(pendingItem);
          return result;
        }
        this.newClient(new PendingItem(response.callback));
        return result;
      }
      newClient(pendingItem) {
        const client = new this.Client(this.options);
        this._clients.push(client);
        const idleListener = makeIdleListener(this, client);
        this.log("checking client timeout");
        let tid;
        let timeoutHit = false;
        if (this.options.connectionTimeoutMillis) {
          tid = setTimeout(() => {
            if (client.connection) {
              this.log("ending client due to timeout");
              timeoutHit = true;
              client.connection.stream.destroy();
            } else if (!client.isConnected()) {
              this.log("ending client due to timeout");
              timeoutHit = true;
              client.end();
            }
          }, this.options.connectionTimeoutMillis);
        }
        this.log("connecting new client");
        client.connect((err) => {
          if (tid) {
            clearTimeout(tid);
          }
          client.on("error", idleListener);
          if (err) {
            this.log("client failed to connect", err);
            this._clients = this._clients.filter((c) => c !== client);
            if (timeoutHit) {
              err = new Error("Connection terminated due to connection timeout", { cause: err });
            }
            this._pulseQueue();
            if (!pendingItem.timedOut) {
              pendingItem.callback(err, void 0, NOOP);
            }
          } else {
            this.log("new client connected");
            if (this.options.onConnect) {
              this._promiseTry(() => this.options.onConnect(client)).then(
                () => {
                  this._afterConnect(client, pendingItem, idleListener);
                },
                (hookErr) => {
                  this._clients = this._clients.filter((c) => c !== client);
                  client.end(() => {
                    this._pulseQueue();
                    if (!pendingItem.timedOut) {
                      pendingItem.callback(hookErr, void 0, NOOP);
                    }
                  });
                }
              );
              return;
            }
            return this._afterConnect(client, pendingItem, idleListener);
          }
        });
      }
      _afterConnect(client, pendingItem, idleListener) {
        if (this.options.maxLifetimeSeconds !== 0) {
          const maxLifetimeTimeout = setTimeout(() => {
            this.log("ending client due to expired lifetime");
            this._expired.add(client);
            const idleIndex = this._idle.findIndex((idleItem) => idleItem.client === client);
            if (idleIndex !== -1) {
              this._acquireClient(
                client,
                new PendingItem((err, client2, clientRelease) => clientRelease()),
                idleListener,
                false
              );
            }
          }, this.options.maxLifetimeSeconds * 1e3);
          maxLifetimeTimeout.unref();
          client.once("end", () => clearTimeout(maxLifetimeTimeout));
        }
        return this._acquireClient(client, pendingItem, idleListener, true);
      }
      // acquire a client for a pending work item
      _acquireClient(client, pendingItem, idleListener, isNew) {
        if (isNew) {
          this.emit("connect", client);
        }
        this.emit("acquire", client);
        client.release = this._releaseOnce(client, idleListener);
        client.removeListener("error", idleListener);
        if (!pendingItem.timedOut) {
          if (isNew && this.options.verify) {
            this.options.verify(client, (err) => {
              if (err) {
                client.release(err);
                return pendingItem.callback(err, void 0, NOOP);
              }
              pendingItem.callback(void 0, client, client.release);
            });
          } else {
            pendingItem.callback(void 0, client, client.release);
          }
        } else {
          if (isNew && this.options.verify) {
            this.options.verify(client, client.release);
          } else {
            client.release();
          }
        }
      }
      // returns a function that wraps _release and throws if called more than once
      _releaseOnce(client, idleListener) {
        let released = false;
        return (err) => {
          if (released) {
            throwOnDoubleRelease();
          }
          released = true;
          this._release(client, idleListener, err);
        };
      }
      // release a client back to the poll, include an error
      // to remove it from the pool
      _release(client, idleListener, err) {
        client.on("error", idleListener);
        client._poolUseCount = (client._poolUseCount || 0) + 1;
        this.emit("release", err, client);
        if (err || this.ending || !client._queryable || client._ending || client._poolUseCount >= this.options.maxUses) {
          if (client._poolUseCount >= this.options.maxUses) {
            this.log("remove expended client");
          }
          return this._remove(client, this._pulseQueue.bind(this));
        }
        const isExpired = this._expired.has(client);
        if (isExpired) {
          this.log("remove expired client");
          this._expired.delete(client);
          return this._remove(client, this._pulseQueue.bind(this));
        }
        let tid;
        if (this.options.idleTimeoutMillis && this._isAboveMin()) {
          tid = setTimeout(() => {
            if (this._isAboveMin()) {
              this.log("remove idle client");
              this._remove(client, this._pulseQueue.bind(this));
            }
          }, this.options.idleTimeoutMillis);
          if (this.options.allowExitOnIdle) {
            tid.unref();
          }
        }
        if (this.options.allowExitOnIdle) {
          client.unref();
        }
        this._idle.push(new IdleItem(client, idleListener, tid));
        this._pulseQueue();
      }
      query(text, values, cb) {
        if (typeof text === "function") {
          const response2 = promisify(this.Promise, text);
          setImmediate(function() {
            return response2.callback(new Error("Passing a function as the first parameter to pool.query is not supported"));
          });
          return response2.result;
        }
        if (typeof values === "function") {
          cb = values;
          values = void 0;
        }
        const response = promisify(this.Promise, cb);
        cb = response.callback;
        this.connect((err, client) => {
          if (err) {
            return cb(err);
          }
          let clientReleased = false;
          const onError = (err2) => {
            if (clientReleased) {
              return;
            }
            clientReleased = true;
            client.release(err2);
            cb(err2);
          };
          client.once("error", onError);
          this.log("dispatching query");
          try {
            client.query(text, values, (err2, res) => {
              this.log("query dispatched");
              client.removeListener("error", onError);
              if (clientReleased) {
                return;
              }
              clientReleased = true;
              client.release(err2);
              if (err2) {
                return cb(err2);
              }
              return cb(void 0, res);
            });
          } catch (err2) {
            client.release(err2);
            return cb(err2);
          }
        });
        return response.result;
      }
      end(cb) {
        this.log("ending");
        if (this.ending) {
          const err = new Error("Called end on pool more than once");
          return cb ? cb(err) : this.Promise.reject(err);
        }
        this.ending = true;
        const promised = promisify(this.Promise, cb);
        this._endCallback = promised.callback;
        this._pulseQueue();
        return promised.result;
      }
      get waitingCount() {
        return this._pendingQueue.length;
      }
      get idleCount() {
        return this._idle.length;
      }
      get expiredCount() {
        return this._clients.reduce((acc, client) => acc + (this._expired.has(client) ? 1 : 0), 0);
      }
      get totalCount() {
        return this._clients.length;
      }
    };
    module2.exports = Pool2;
  }
});

// migration/pos/server/node_modules/pg/lib/native/query.js
var require_query2 = __commonJS({
  "migration/pos/server/node_modules/pg/lib/native/query.js"(exports2, module2) {
    "use strict";
    var EventEmitter = require("events").EventEmitter;
    var util = require("util");
    var utils = require_utils();
    var NativeQuery = module2.exports = function(config, values, callback) {
      EventEmitter.call(this);
      config = utils.normalizeQueryConfig(config, values, callback);
      this.text = config.text;
      this.values = config.values;
      this.name = config.name;
      this.queryMode = config.queryMode;
      this.callback = config.callback;
      this.state = "new";
      this._arrayMode = config.rowMode === "array";
      this._emitRowEvents = false;
      this.on(
        "newListener",
        function(event) {
          if (event === "row") this._emitRowEvents = true;
        }.bind(this)
      );
    };
    util.inherits(NativeQuery, EventEmitter);
    var errorFieldMap = {
      sqlState: "code",
      statementPosition: "position",
      messagePrimary: "message",
      context: "where",
      schemaName: "schema",
      tableName: "table",
      columnName: "column",
      dataTypeName: "dataType",
      constraintName: "constraint",
      sourceFile: "file",
      sourceLine: "line",
      sourceFunction: "routine"
    };
    NativeQuery.prototype.handleError = function(err) {
      const fields = this.native && this.native.pq.resultErrorFields();
      if (fields) {
        for (const key in fields) {
          const normalizedFieldName = errorFieldMap[key] || key;
          err[normalizedFieldName] = fields[key];
        }
      }
      if (this.callback) {
        this.callback(err);
      } else {
        this.emit("error", err);
      }
      this.state = "error";
    };
    NativeQuery.prototype.then = function(onSuccess, onFailure) {
      return this._getPromise().then(onSuccess, onFailure);
    };
    NativeQuery.prototype.catch = function(callback) {
      return this._getPromise().catch(callback);
    };
    NativeQuery.prototype._getPromise = function() {
      if (this._promise) return this._promise;
      this._promise = new Promise(
        function(resolve, reject) {
          this._once("end", resolve);
          this._once("error", reject);
        }.bind(this)
      );
      return this._promise;
    };
    NativeQuery.prototype.submit = function(client) {
      this.state = "running";
      const self = this;
      this.native = client.native;
      client.native.arrayMode = this._arrayMode;
      let after = function(err, rows, results) {
        client.native.arrayMode = false;
        setImmediate(function() {
          self.emit("_done");
        });
        if (err) {
          return self.handleError(err);
        }
        if (self._emitRowEvents) {
          if (results.length > 1) {
            rows.forEach((rowOfRows, i) => {
              rowOfRows.forEach((row) => {
                self.emit("row", row, results[i]);
              });
            });
          } else {
            rows.forEach(function(row) {
              self.emit("row", row, results);
            });
          }
        }
        self.state = "end";
        self.emit("end", results);
        if (self.callback) {
          self.callback(null, results);
        }
      };
      if (process.domain) {
        after = process.domain.bind(after);
      }
      if (this.name) {
        if (this.name.length > 63) {
          console.error("Warning! Postgres only supports 63 characters for query names.");
          console.error("You supplied %s (%s)", this.name, this.name.length);
          console.error("This can cause conflicts and silent errors executing queries");
        }
        const values = (this.values || []).map(utils.prepareValue);
        if (client.namedQueries[this.name]) {
          if (this.text && client.namedQueries[this.name] !== this.text) {
            const err = new Error(`Prepared statements must be unique - '${this.name}' was used for a different statement`);
            return after(err);
          }
          return client.native.execute(this.name, values, after);
        }
        return client.native.prepare(this.name, this.text, values.length, function(err) {
          if (err) return after(err);
          client.namedQueries[self.name] = self.text;
          return self.native.execute(self.name, values, after);
        });
      } else if (this.values) {
        if (!Array.isArray(this.values)) {
          const err = new Error("Query values must be an array");
          return after(err);
        }
        const vals = this.values.map(utils.prepareValue);
        client.native.query(this.text, vals, after);
      } else if (this.queryMode === "extended") {
        client.native.query(this.text, [], after);
      } else {
        client.native.query(this.text, after);
      }
    };
  }
});

// migration/pos/server/node_modules/pg/lib/native/client.js
var require_client2 = __commonJS({
  "migration/pos/server/node_modules/pg/lib/native/client.js"(exports2, module2) {
    var nodeUtils = require("util");
    var Native;
    try {
      Native = require("pg-native");
    } catch (e) {
      throw e;
    }
    var TypeOverrides = require_type_overrides();
    var EventEmitter = require("events").EventEmitter;
    var util = require("util");
    var ConnectionParameters = require_connection_parameters();
    var NativeQuery = require_query2();
    var queryQueueLengthDeprecationNotice = nodeUtils.deprecate(
      () => {
      },
      "Calling client.query() when the client is already executing a query is deprecated and will be removed in pg@9.0. Use async/await or an external async flow control mechanism instead."
    );
    var Client = module2.exports = function(config) {
      EventEmitter.call(this);
      config = config || {};
      this._Promise = config.Promise || global.Promise;
      this._types = new TypeOverrides(config.types);
      this.native = new Native({
        types: this._types
      });
      this._queryQueue = [];
      this._ending = false;
      this._connecting = false;
      this._connected = false;
      this._queryable = true;
      this.pipeline = Boolean(config.pipeline);
      this._pipelineInFlight = false;
      const cp = this.connectionParameters = new ConnectionParameters(config);
      if (config.nativeConnectionString) cp.nativeConnectionString = config.nativeConnectionString;
      this.user = cp.user;
      Object.defineProperty(this, "password", {
        configurable: true,
        enumerable: false,
        writable: true,
        value: cp.password
      });
      this.database = cp.database;
      this.host = cp.host;
      this.port = cp.port;
      this.namedQueries = {};
    };
    Client.Query = NativeQuery;
    util.inherits(Client, EventEmitter);
    Client.prototype._errorAllQueries = function(err) {
      const enqueueError = (query) => {
        process.nextTick(() => {
          query.native = this.native;
          query.handleError(err);
        });
      };
      if (this._hasActiveQuery()) {
        enqueueError(this._activeQuery);
        this._activeQuery = null;
      }
      this._queryQueue.forEach(enqueueError);
      this._queryQueue.length = 0;
    };
    Client.prototype._connect = function(cb) {
      const self = this;
      if (this._connecting) {
        process.nextTick(() => cb(new Error("Client has already been connected. You cannot reuse a client.")));
        return;
      }
      this._connecting = true;
      this.connectionParameters.getLibpqConnectionString(function(err, conString) {
        if (self.connectionParameters.nativeConnectionString) conString = self.connectionParameters.nativeConnectionString;
        if (err) return cb(err);
        self.native.connect(conString, function(err2) {
          if (err2) {
            self.native.end();
            return cb(err2);
          }
          self._connected = true;
          self.native.on("error", function(err3) {
            self._queryable = false;
            self._errorAllQueries(err3);
            self.emit("error", err3);
          });
          self.native.on("notification", function(msg) {
            self.emit("notification", {
              channel: msg.relname,
              payload: msg.extra
            });
          });
          self.emit("connect");
          self._pulseQueryQueue(true);
          cb(null, this);
        });
      });
    };
    Client.prototype.connect = function(callback) {
      if (callback) {
        this._connect(callback);
        return;
      }
      return new this._Promise((resolve, reject) => {
        this._connect((error) => {
          if (error) {
            reject(error);
          } else {
            resolve(this);
          }
        });
      });
    };
    Client.prototype.query = function(config, values, callback) {
      let query;
      let result;
      let readTimeout;
      let readTimeoutTimer;
      let queryCallback;
      if (config === null || config === void 0) {
        throw new TypeError("Client was passed a null or undefined query");
      } else if (typeof config.submit === "function") {
        readTimeout = config.query_timeout || this.connectionParameters.query_timeout;
        result = query = config;
        if (typeof values === "function") {
          config.callback = values;
        }
      } else {
        readTimeout = config.query_timeout || this.connectionParameters.query_timeout;
        query = new NativeQuery(config, values, callback);
        if (!query.callback) {
          let resolveOut, rejectOut;
          result = new this._Promise((resolve, reject) => {
            resolveOut = resolve;
            rejectOut = reject;
          }).catch((err) => {
            Error.captureStackTrace(err);
            throw err;
          });
          query.callback = (err, res) => err ? rejectOut(err) : resolveOut(res);
        }
      }
      if (readTimeout) {
        queryCallback = query.callback || (() => {
        });
        readTimeoutTimer = setTimeout(() => {
          const error = new Error("Query read timeout");
          process.nextTick(() => {
            query.handleError(error, this.connection);
          });
          queryCallback(error);
          query.callback = () => {
          };
          const index = this._queryQueue.indexOf(query);
          if (index > -1) {
            this._queryQueue.splice(index, 1);
          }
          this._pulseQueryQueue();
        }, readTimeout);
        query.callback = (err, res) => {
          clearTimeout(readTimeoutTimer);
          queryCallback(err, res);
        };
      }
      if (!this._queryable) {
        query.native = this.native;
        process.nextTick(() => {
          query.handleError(new Error("Client has encountered a connection error and is not queryable"));
        });
        return result;
      }
      if (this._ending) {
        query.native = this.native;
        process.nextTick(() => {
          query.handleError(new Error("Client was closed and is not queryable"));
        });
        return result;
      }
      if (this._queryQueue.length > 0 && !this.pipeline) {
        queryQueueLengthDeprecationNotice();
      }
      this._queryQueue.push(query);
      this._pulseQueryQueue();
      return result;
    };
    Client.prototype.end = function(cb) {
      const self = this;
      this._ending = true;
      if (this._connecting && !this._connected) {
        this.once("connect", () => {
          this.end(() => {
          });
        });
      }
      let result;
      if (!cb) {
        result = new this._Promise(function(resolve, reject) {
          cb = (err) => err ? reject(err) : resolve();
        });
      }
      const doEnd = function() {
        self.native.end(function() {
          self._connected = false;
          self._errorAllQueries(new Error("Connection terminated"));
          process.nextTick(() => {
            self.emit("end");
            if (cb) cb();
          });
        });
      };
      if (this.pipeline && (this._pipelineInFlight || this._queryQueue.length > 0)) {
        this.once("drain", doEnd);
      } else {
        doEnd();
      }
      return result;
    };
    Client.prototype._hasActiveQuery = function() {
      return this._activeQuery && this._activeQuery.state !== "error" && this._activeQuery.state !== "end";
    };
    Client.prototype._pulseQueryQueue = function(initialConnection) {
      if (!this._connected) {
        return;
      }
      if (this.pipeline && !initialConnection) {
        return this._pulsePipelinedQueryQueue();
      }
      if (this._hasActiveQuery()) {
        return;
      }
      const query = this._queryQueue.shift();
      if (!query) {
        if (!initialConnection) {
          this.emit("drain");
        }
        return;
      }
      this._activeQuery = query;
      query.submit(this);
      const self = this;
      query.once("_done", function() {
        self._pulseQueryQueue();
      });
    };
    Client.prototype._pulsePipelinedQueryQueue = function() {
      if (!this._connected || this._pipelineInFlight) {
        return;
      }
      if (this._queryQueue.length === 0) {
        if (this.hasExecuted) {
          this.emit("drain");
        }
        return;
      }
      this._pipelineInFlight = true;
      const self = this;
      const queries = [];
      const nativeQueries = [];
      const utils = require_utils();
      while (this._queryQueue.length > 0) {
        const query = this._queryQueue.shift();
        this.hasExecuted = true;
        nativeQueries.push(query);
        const values = query.values ? query.values.map(utils.prepareValue) : null;
        const pipelineEntry = { text: query.text, name: query.name };
        if (values) {
          pipelineEntry.values = values;
        }
        if (query.name && this.namedQueries[query.name]) {
          pipelineEntry._alreadyPrepared = true;
        }
        queries.push(pipelineEntry);
      }
      this.native.pipeline(queries, function(err, results) {
        self._pipelineInFlight = false;
        if (err) {
          for (let i = 0; i < nativeQueries.length; i++) {
            const q = nativeQueries[i];
            q.native = self.native;
            q.handleError(err);
          }
          self._pulsePipelinedQueryQueue();
          return;
        }
        for (let i = 0; i < nativeQueries.length; i++) {
          const q = nativeQueries[i];
          const r = results[i];
          q.native = self.native;
          if (r.err) {
            q.handleError(r.err);
          } else {
            if (q.name) {
              self.namedQueries[q.name] = q.text;
            }
            q.state = "end";
            q.emit("end", r.result);
            if (q.callback) {
              q.callback(null, r.result);
            }
          }
          setImmediate(function() {
            q.emit("_done");
          });
        }
        self._pulsePipelinedQueryQueue();
      });
    };
    Client.prototype.cancel = function(query) {
      if (this._activeQuery === query) {
        this.native.cancel(function() {
        });
      } else if (this._queryQueue.indexOf(query) !== -1) {
        this._queryQueue.splice(this._queryQueue.indexOf(query), 1);
      }
    };
    Client.prototype.ref = function() {
    };
    Client.prototype.unref = function() {
    };
    Client.prototype.setTypeParser = function(oid, format, parseFn) {
      return this._types.setTypeParser(oid, format, parseFn);
    };
    Client.prototype.getTypeParser = function(oid, format) {
      return this._types.getTypeParser(oid, format);
    };
    Client.prototype.isConnected = function() {
      return this._connected;
    };
    Client.prototype.getTransactionStatus = function() {
      return this.native.getTransactionStatus();
    };
  }
});

// migration/pos/server/node_modules/pg/lib/native/index.js
var require_native = __commonJS({
  "migration/pos/server/node_modules/pg/lib/native/index.js"(exports2, module2) {
    "use strict";
    module2.exports = require_client2();
  }
});

// migration/pos/server/node_modules/pg/lib/index.js
var require_lib2 = __commonJS({
  "migration/pos/server/node_modules/pg/lib/index.js"(exports2, module2) {
    "use strict";
    var Client = require_client();
    var defaults = require_defaults();
    var Connection = require_connection();
    var Result = require_result();
    var utils = require_utils();
    var Pool2 = require_pg_pool();
    var TypeOverrides = require_type_overrides();
    var { DatabaseError } = require_dist();
    var { escapeIdentifier, escapeLiteral } = require_utils();
    var poolFactory = (Client2) => {
      return class BoundPool extends Pool2 {
        constructor(options) {
          super(options, Client2);
        }
      };
    };
    var PG = function(clientConstructor2) {
      this.defaults = defaults;
      this.Client = clientConstructor2;
      this.Query = this.Client.Query;
      this.Pool = poolFactory(this.Client);
      this._pools = [];
      this.Connection = Connection;
      this.types = require_pg_types();
      this.DatabaseError = DatabaseError;
      this.TypeOverrides = TypeOverrides;
      this.escapeIdentifier = escapeIdentifier;
      this.escapeLiteral = escapeLiteral;
      this.Result = Result;
      this.utils = utils;
    };
    var clientConstructor = Client;
    var forceNative = false;
    try {
      forceNative = !!process.env.NODE_PG_FORCE_NATIVE;
    } catch {
    }
    if (forceNative) {
      clientConstructor = require_native();
    }
    module2.exports = new PG(clientConstructor);
    Object.defineProperty(module2.exports, "native", {
      configurable: true,
      enumerable: false,
      get() {
        let native = null;
        try {
          native = new PG(require_native());
        } catch (err) {
          if (err.code !== "MODULE_NOT_FOUND") {
            throw err;
          }
        }
        Object.defineProperty(module2.exports, "native", {
          value: native
        });
        return native;
      }
    });
  }
});

// migration/pos/renderer/vending-core.js
var require_vending_core = __commonJS({
  "migration/pos/renderer/vending-core.js"(exports2, module2) {
    "use strict";
    (function(host, factory) {
      const api = factory();
      if (typeof module2 === "object" && module2.exports) module2.exports = api;
      else host.Vending = api;
    })(globalThis, function() {
      const money = (v) => Math.round((Number(v) + Number.EPSILON) * 100) / 100;
      const clean = (v, n = 160) => String(v ?? "").trim().slice(0, n);
      const canonical = (v) => v && typeof v === "object" ? Array.isArray(v) ? "[" + v.map(canonical).join(",") + "]" : "{" + Object.keys(v).sort().map((k) => JSON.stringify(k) + ":" + canonical(v[k])).join(",") + "}" : JSON.stringify(v);
      const safeId = (v) => typeof v === "string" && /^[A-Za-z0-9_-]{1,120}$/.test(v) && !["__proto__", "constructor", "prototype"].includes(v);
      function number(v, label, integer = false) {
        if (v === null || v === void 0 || v === "" || typeof v === "boolean" || !/^\d+(?:\.\d+)?$/.test(String(v)) || !Number.isFinite(Number(v)) || Number(v) < 0 || Number(v) > 9999999 || integer && !Number.isSafeInteger(Number(v))) throw Error(label + "\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
        return integer ? Number(v) : money(v);
      }
      function list(state) {
        return state.vendingMachines || [];
      }
      function events(state) {
        return state.vendingEvents || [];
      }
      function machine(state, id) {
        const m = list(state).find((m2) => m2.id === id);
        if (!m) throw Error("\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E15\u0E39\u0E49\u0E02\u0E32\u0E22\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32");
        return m;
      }
      function defaultMachine(state, productId) {
        const ms = list(state).filter((m) => m.active !== false && m.items.some((i) => i.productId === productId && i.enabled !== false));
        return ms.find((m) => m.items.some((i) => i.productId === productId && i.queueDefault)) || (ms.length === 1 ? ms[0] : null);
      }
      function queueDispensed(state, queueId, productId) {
        return events(state).filter((e) => e.kind === "dispense" && e.queueId === queueId).reduce((s, e) => s + e.items.filter((i) => i.productId === productId).reduce((n, i) => n + i.quantity, 0), 0);
      }
      function queueRoutes(state, quantities) {
        return Object.entries(quantities || {}).filter(([, q]) => Number(q) > 0).flatMap(([productId, quantity]) => {
          const m = defaultMachine(state, productId), i = m?.items.find((i2) => i2.productId === productId);
          return i ? [{ machineId: m.id, machineName: m.name, productId, quantity: Number(quantity), unitPrice: i.price }] : [];
        });
      }
      function returnedCash(state, id) {
        return money((state.cashDrawerTransactions || []).filter((t) => t.parentTransactionId === id && Number(t.cashDelta) > 0).reduce((s, t) => s + Number(t.cashDelta), 0));
      }
      function releasedQuantity(state, id, productId, machineId) {
        return (state.cashDrawerTransactions || []).filter((t) => t.parentTransactionId === id).flatMap((t) => t.releasedVendingItems || []).filter((i) => i.productId === productId && i.machineId === machineId).reduce((s, i) => s + Number(i.quantity), 0);
      }
      function pendingDispenses(state) {
        return (state.cashDrawerTransactions || []).filter((t) => t.vendingItems?.length).map((t) => ({ ...t, vendingItems: t.vendingItems.map((i) => ({ ...i, quantity: Math.max(0, i.quantity - events(state).filter((e) => e.kind === "dispense" && e.withdrawalId === t.id && e.machineId === i.machineId).flatMap((e) => e.items).filter((j) => j.productId === i.productId).reduce((s, j) => s + j.quantity, 0) - releasedQuantity(state, t.id, i.productId, i.machineId)) })).filter((i) => i.quantity > 0) })).filter((t) => t.vendingItems.length);
      }
      function routesForDraft(state, draft, original = null) {
        const saved = original || draft;
        if (original || (state.queues || []).some((q) => q.id === saved.id)) {
          const prior = original || (state.queues || []).find((q) => q.id === saved.id) || saved;
          const kept = (prior.vendingRoutes || []).map((i) => ({ ...i, quantity: Number(draft.products?.[i.productId] || 0) })).filter((i) => i.quantity > 0);
          const additions = Object.fromEntries(Object.entries(draft.products || {}).filter(([id, q]) => q > 0 && !Number(prior.products?.[id] || 0)));
          return [...kept, ...queueRoutes(state, additions)];
        }
        return queueRoutes(state, draft.products);
      }
      function frontQuantities(quantities, routes) {
        const ids = new Set((routes || []).map((i) => i.productId));
        return Object.fromEntries(Object.entries(quantities || {}).filter(([id]) => !ids.has(id)));
      }
      function unfundedRoutes(state, queue) {
        return (queue.vendingRoutes || []).map((i) => {
          const reserved = (state.cashDrawerTransactions || []).filter((t) => t.queueId === queue.id).reduce((s, t) => s + (t.vendingItems || []).filter((j) => j.productId === i.productId).reduce((n, j) => n + j.quantity - releasedQuantity(state, t.id, j.productId, j.machineId), 0), 0);
          return { ...i, quantity: Math.max(0, Number(queue.products?.[i.productId] || 0) - reserved) };
        }).filter((i) => i.quantity > 0);
      }
      function queueStockAvailable(state, route, excludeQueueId) {
        const m = machine(state, route.machineId), item = m.items.find((i) => i.productId === route.productId);
        if (!item || m.active === false) return 0;
        const reserved = (state.queues || []).filter((q) => q.id !== excludeQueueId && q.status !== "CANCELLED" && (q.vendingRoutes || []).some((i) => i.machineId === route.machineId && i.productId === route.productId)).reduce((sum, q) => sum + Math.max(0, Number(q.products?.[route.productId] || 0) - queueDispensed(state, q.id, route.productId)), 0);
        return Math.max(0, Number(item.stock || 0) - reserved);
      }
      function validateQueueChanges(previous, next) {
        const old = new Map((previous.queues || []).map((q) => [q.id, q]));
        for (const q of next.queues || []) {
          const prior = old.get(q.id);
          if (q.status === "CANCELLED" || canonical(q.products) === canonical(prior?.products) && canonical(q.vendingRoutes) === canonical(prior?.vendingRoutes)) continue;
          for (const route of q.vendingRoutes || []) {
            const reserved = (next.cashDrawerTransactions || []).filter((t) => t.queueId === q.id).reduce((s, t) => s + (t.vendingItems || []).filter((i) => i.productId === route.productId).reduce((n, i) => n + i.quantity - releasedQuantity(next, t.id, i.productId, i.machineId), 0), 0);
            const qty = Number(q.products?.[route.productId] || 0), dispensed = queueDispensed(next, q.id, route.productId);
            if (qty < Math.max(reserved, dispensed)) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E04\u0E37\u0E19\u0E40\u0E07\u0E34\u0E19\u0E40\u0E1A\u0E34\u0E01\u0E17\u0E35\u0E48\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E43\u0E0A\u0E49\u0E01\u0E48\u0E2D\u0E19\u0E25\u0E14\u0E08\u0E33\u0E19\u0E27\u0E19\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E43\u0E19\u0E04\u0E34\u0E27");
            if (qty - dispensed > queueStockAvailable(next, route, q.id)) throw Error("\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E43\u0E19\u0E15\u0E39\u0E49\u0E44\u0E21\u0E48\u0E1E\u0E2D\u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A\u0E04\u0E34\u0E27\u0E19\u0E35\u0E49 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E40\u0E15\u0E34\u0E21\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E2B\u0E23\u0E37\u0E2D\u0E25\u0E14\u0E08\u0E33\u0E19\u0E27\u0E19");
          }
          for (const route of prior?.vendingRoutes || []) if (!(q.vendingRoutes || []).some((i) => i.productId === route.productId) && Number(prior.products?.[route.productId] || 0) > 0) {
            const pending = pendingDispenses(next).some((t) => t.queueId === q.id && t.vendingItems.some((i) => i.productId === route.productId));
            if (pending || queueDispensed(next, q.id, route.productId) > 0) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E04\u0E37\u0E19\u0E40\u0E07\u0E34\u0E19\u0E40\u0E1A\u0E34\u0E01\u0E01\u0E48\u0E2D\u0E19\u0E25\u0E1A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E17\u0E35\u0E48\u0E23\u0E2D\u0E01\u0E14\u0E08\u0E32\u0E01\u0E15\u0E39\u0E49");
          }
        }
        return true;
      }
      function washingBudget(state, q) {
        const baskets = q.baskets?.length ? q.baskets : [q];
        return money(baskets.reduce((sum, b) => {
          const lines = b.pricing?.lines?.length ? b.pricing.lines : (q.pricing?.lines || []).filter((l) => l.basketId === b.id || Number(l.basketNumber || 0) === Number(b.number || 0));
          let amount = lines.filter((l) => ["wash", "dry", "extraDryTime"].includes(l.type)).reduce((s, l) => s + Math.max(0, Number(l.amount || 0)), 0);
          if (amount <= 0) {
            if (["wash", "washDry", "wash-dry", "WASH", "WASH_DRY"].includes(b.serviceType)) amount += Number(state.settings?.washPrices?.[b.wash?.size || "13"]?.[b.wash?.program || "cold"] || 0) * Math.max(1, Number(b.wash?.rounds || 1));
            if (["dry", "washDry", "wash-dry", "DRY", "WASH_DRY"].includes(b.serviceType)) amount += Number(state.settings?.dryPrices?.[b.dry?.size || "13"]?.[b.dry?.heat || "medium"] || 0) * Math.max(1, Number(b.dry?.rounds || 1)) + Math.max(0, Number(b.dry?.extraTimeRounds || 0)) * 10;
          }
          return sum + amount;
        }, 0) + (q.extras || []).filter((e) => e.kind === "EXTRA_DRY").reduce((s, e) => s + Math.max(0, Number(e.amount || 0)), 0));
      }
      function availableWashingBudget(state, q) {
        const spent = (state.cashDrawerTransactions || []).filter((t) => t.queueId === q.id && t.cashDelta < 0).reduce((s, t) => {
          const reserved = (t.vendingItems || []).reduce((n, i) => n + (i.quantity - releasedQuantity(state, t.id, i.productId, i.machineId)) * i.unitPrice, 0);
          return s + Math.max(0, -Number(t.cashDelta) - returnedCash(state, t.id) - reserved);
        }, 0);
        return money(Math.max(0, washingBudget(state, q) - spent));
      }
      function validateCashChanges(previous, next, deviceId = null) {
        const originals = new Map((previous.cashDrawerTransactions || []).map((t) => [t.id, t]));
        const fresh = (next.cashDrawerTransactions || []).filter((t) => !originals.has(t.id)).slice().reverse().sort((a, b) => String(a.createdAt).localeCompare(String(b.createdAt)));
        const working = { ...next, cashDrawerTransactions: [...originals.values()] };
        for (const t of next.cashDrawerTransactions || []) {
          const old = originals.get(t.id);
          if (old && (old.vendingItems || old.parentTransactionId) && canonical(old) !== canonical(t)) throw Error("\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E40\u0E07\u0E34\u0E19\u0E40\u0E1A\u0E34\u0E01\u0E41\u0E25\u0E30\u0E04\u0E37\u0E19\u0E17\u0E35\u0E48\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E41\u0E25\u0E49\u0E27\u0E41\u0E01\u0E49\u0E17\u0E31\u0E1A\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49");
        }
        for (const t of fresh) {
          const q = (next.queues || []).find((q2) => q2.id === t.queueId), parent = working.cashDrawerTransactions.find((r) => r.id === t.parentTransactionId);
          if (deviceId && (q?.deviceId && q.deviceId !== deviceId || parent?.deviceId && parent.deviceId !== deviceId)) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E40\u0E1A\u0E34\u0E01\u0E2B\u0E23\u0E37\u0E2D\u0E04\u0E37\u0E19\u0E40\u0E07\u0E34\u0E19\u0E17\u0E35\u0E48 POS \u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E40\u0E08\u0E49\u0E32\u0E02\u0E2D\u0E07\u0E04\u0E34\u0E27");
          if (Array.isArray(t.vendingItems)) {
            if (!q || q.status === "CANCELLED") throw Error("\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E04\u0E34\u0E27\u0E17\u0E35\u0E48\u0E40\u0E1A\u0E34\u0E01\u0E40\u0E07\u0E34\u0E19\u0E44\u0E14\u0E49");
            const amount = number(t.amount, "\u0E40\u0E07\u0E34\u0E19\u0E40\u0E1A\u0E34\u0E01");
            if (amount <= 0 || t.cashDelta !== -amount || Number(t.qrDelta || 0) !== 0 || Number(t.revenueDelta || 0) !== 0) throw Error("\u0E22\u0E2D\u0E14\u0E40\u0E07\u0E34\u0E19\u0E40\u0E1A\u0E34\u0E01\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23");
            if (new Set(t.vendingItems.map((i) => i.productId)).size !== t.vendingItems.length) throw Error("\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E40\u0E1A\u0E34\u0E01\u0E0B\u0E49\u0E33\u0E43\u0E19\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E40\u0E14\u0E35\u0E22\u0E27\u0E01\u0E31\u0E19");
            let goods = 0;
            for (const i of t.vendingItems) {
              const quantity = number(i.quantity, "\u0E08\u0E33\u0E19\u0E27\u0E19\u0E40\u0E1A\u0E34\u0E01", true), price = number(i.unitPrice, "\u0E23\u0E32\u0E04\u0E32\u0E2B\u0E22\u0E2D\u0E14"), m = machine(working, i.machineId), item = m.items.find((j) => j.productId === i.productId && j.enabled !== false);
              if (!item || m.active === false || price !== item.price) throw Error("\u0E23\u0E32\u0E04\u0E32\u0E2B\u0E23\u0E37\u0E2D\u0E15\u0E39\u0E49\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E41\u0E25\u0E49\u0E27 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E40\u0E1B\u0E34\u0E14\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E40\u0E1A\u0E34\u0E01\u0E43\u0E2B\u0E21\u0E48");
              const remaining = unfundedRoutes(working, q).find((j) => j.productId === i.productId)?.quantity || 0;
              if (quantity <= 0 || quantity > remaining) throw Error("\u0E08\u0E33\u0E19\u0E27\u0E19\u0E40\u0E1A\u0E34\u0E01\u0E40\u0E01\u0E34\u0E19\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E17\u0E35\u0E48\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E40\u0E1A\u0E34\u0E01\u0E43\u0E19\u0E04\u0E34\u0E27");
              goods = money(goods + quantity * price);
            }
            if (amount < goods || amount > goods + availableWashingBudget(working, q) + 1e-3) throw Error("\u0E22\u0E2D\u0E14\u0E40\u0E07\u0E34\u0E19\u0E40\u0E1A\u0E34\u0E01\u0E40\u0E01\u0E34\u0E19\u0E04\u0E48\u0E32\u0E2B\u0E22\u0E2D\u0E14\u0E17\u0E35\u0E48\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E40\u0E1A\u0E34\u0E01\u0E02\u0E2D\u0E07\u0E04\u0E34\u0E27");
          }
          if (t.parentTransactionId) {
            if (!parent || Number(parent.cashDelta) >= 0 || t.queueId !== parent.queueId) throw Error("\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E04\u0E37\u0E19\u0E40\u0E07\u0E34\u0E19\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E40\u0E07\u0E34\u0E19\u0E40\u0E1A\u0E34\u0E01");
            const amount = number(t.amount, "\u0E40\u0E07\u0E34\u0E19\u0E04\u0E37\u0E19");
            if (amount <= 0 || t.cashDelta !== amount || Number(t.qrDelta || 0) !== 0 || Number(t.revenueDelta || 0) !== 0) throw Error("\u0E22\u0E2D\u0E14\u0E40\u0E07\u0E34\u0E19\u0E04\u0E37\u0E19\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23");
            const pending = pendingDispenses(working).find((p) => p.id === parent.id)?.vendingItems || [], released = t.releasedVendingItems || [];
            if (new Set(released.map((i) => i.machineId + "/" + i.productId)).size !== released.length) throw Error("\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E0B\u0E2D\u0E07\u0E04\u0E37\u0E19\u0E0B\u0E49\u0E33");
            let releaseAmount = 0;
            for (const i of released) {
              const old = pending.find((j) => j.machineId === i.machineId && j.productId === i.productId), qty = number(i.quantity, "\u0E08\u0E33\u0E19\u0E27\u0E19\u0E04\u0E37\u0E19", true);
              if (!old || qty <= 0 || qty > old.quantity || Number(i.unitPrice) !== old.unitPrice) throw Error("\u0E08\u0E33\u0E19\u0E27\u0E19\u0E0B\u0E2D\u0E07\u0E04\u0E37\u0E19\u0E40\u0E01\u0E34\u0E19\u0E17\u0E35\u0E48\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E01\u0E14");
              releaseAmount = money(releaseAmount + qty * old.unitPrice);
            }
            const spent = events(working).filter((e) => e.kind === "dispense" && e.withdrawalId === parent.id).reduce((s, e) => s + e.amount, 0), left = money(-parent.cashDelta - spent - returnedCash(working, parent.id) - amount), reserved = money(pending.reduce((s, i) => s + i.quantity * i.unitPrice, 0) - releaseAmount);
            if (left < 0 || releaseAmount > amount || reserved > left + 1e-3) throw Error("\u0E40\u0E07\u0E34\u0E19\u0E04\u0E37\u0E19\u0E40\u0E01\u0E34\u0E19\u0E40\u0E07\u0E34\u0E19\u0E17\u0E35\u0E48\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E43\u0E0A\u0E49 \u0E2B\u0E23\u0E37\u0E2D\u0E22\u0E31\u0E07\u0E21\u0E35\u0E0B\u0E2D\u0E07\u0E23\u0E2D\u0E01\u0E14\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01");
          }
          working.cashDrawerTransactions.push(t);
        }
        return true;
      }
      function apply(state, command, now = (/* @__PURE__ */ new Date()).toISOString()) {
        const p = command?.payload || {}, action = p.workflow;
        if (!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(command?.id || "")) throw Error("\u0E40\u0E25\u0E02\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
        const signature = canonical({ type: command.type, payload: p });
        const prior = events(state).find((e) => e.commandId === command.id);
        if (prior) {
          if (prior.signature !== signature) throw Error("\u0E40\u0E25\u0E02\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E0B\u0E49\u0E33\u0E01\u0E31\u0E1A\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E2D\u0E37\u0E48\u0E19");
          return { state, result: { id: command.id, status: "applied", message: prior.message, completedAt: prior.createdAt }, duplicate: true };
        }
        const next = structuredClone(state);
        next.vendingMachines ||= [];
        next.vendingEvents ||= [];
        next.inventoryMovements ||= [];
        const event = { id: "vend_" + command.id, commandId: command.id, signature, createdAt: now, actor: clean(command.actor || p.actor || "\u0E1C\u0E39\u0E49\u0E08\u0E31\u0E14\u0E01\u0E32\u0E23"), employeeId: p.employeeId || null, deviceId: "SERVERJJ", kind: action?.replace("vending.", ""), machineId: p.machineId || null, items: [] };
        const product = (id) => {
          if (!safeId(id) || !next.settings?.products?.[id]) throw Error("\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32");
          return next.settings.products[id];
        };
        const movement = (item, delta, type, extra = {}) => {
          next.inventoryMovements.unshift({ id: "vstock_" + command.id + "_" + item.productId + "_" + type, productId: item.productId, delta, type, sourceId: event.id, sourceType: "VENDING", createdAt: now, actor: event.actor, machineId: event.machineId, ...extra });
        };
        try {
          if (action === "vending.machine.save") {
            const id = p.machineId || "machine_" + command.id;
            if (!safeId(id)) throw Error("\u0E23\u0E2B\u0E31\u0E2A\u0E15\u0E39\u0E49\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
            let m = next.vendingMachines.find((m2) => m2.id === id);
            if (Number(p.expectedRevision) !== Number(m?.revision || 0)) throw Error("\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E15\u0E39\u0E49\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E41\u0E25\u0E49\u0E27 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E2B\u0E21\u0E48");
            if (!clean(p.name)) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E15\u0E31\u0E49\u0E07\u0E0A\u0E37\u0E48\u0E2D\u0E15\u0E39\u0E49");
            if (!Array.isArray(p.items) || p.items.length > 100 || new Set(p.items.map((i) => i.productId)).size !== p.items.length) throw Error("\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E0B\u0E49\u0E33\u0E2B\u0E23\u0E37\u0E2D\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
            const items = p.items.map((i) => {
              const pr = product(i.productId), old = m?.items.find((o) => o.productId === i.productId);
              if (pr.trackStock === false) throw Error("\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E43\u0E19\u0E15\u0E39\u0E49\u0E15\u0E49\u0E2D\u0E07\u0E15\u0E34\u0E14\u0E15\u0E32\u0E21\u0E2A\u0E15\u0E4A\u0E2D\u0E01");
              return { productId: pr.id, name: pr.name, unit: pr.unit, price: number(i.price, "\u0E23\u0E32\u0E04\u0E32"), stock: old?.stock || 0, averageCost: old?.averageCost || Number(pr.costPrice || 0), enabled: i.enabled !== false, queueDefault: i.queueDefault === true };
            });
            for (const old of m?.items || []) if (old.stock > 0 && !items.some((i) => i.productId === old.productId)) throw Error("\u0E15\u0E39\u0E49\u0E22\u0E31\u0E07\u0E21\u0E35\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E04\u0E07\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E44\u0E27\u0E49\u0E01\u0E48\u0E2D\u0E19");
            if (p.active === false && (m?.cashBalance || m?.items.some((i) => i.stock > 0))) throw Error("\u0E40\u0E01\u0E47\u0E1A\u0E40\u0E07\u0E34\u0E19\u0E41\u0E25\u0E30\u0E19\u0E33\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E04\u0E07\u0E40\u0E2B\u0E25\u0E37\u0E2D\u0E2D\u0E2D\u0E01\u0E01\u0E48\u0E2D\u0E19\u0E1B\u0E34\u0E14\u0E15\u0E39\u0E49");
            for (const i of items.filter((i2) => i2.queueDefault)) for (const other of next.vendingMachines.filter((o) => o.id !== id)) for (const oi of other.items) if (oi.productId === i.productId && oi.queueDefault) {
              oi.queueDefault = false;
              other.revision++;
            }
            if (!m) {
              m = { id, items: [], cashBalance: 0, openingBalance: 0, queueDeposits: 0, directDeposits: 0, createdAt: now, revision: 0 };
              next.vendingMachines.push(m);
            }
            Object.assign(m, { name: clean(p.name), active: p.active !== false, items, revision: m.revision + 1, updatedAt: now });
            event.machineId = m.id;
            event.machineName = m.name;
            event.message = "\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E15\u0E39\u0E49 " + m.name + " \u0E41\u0E25\u0E49\u0E27";
          } else {
            const m = machine(next, p.machineId);
            event.machineName = m.name;
            if (m.active === false) throw Error("\u0E15\u0E39\u0E49\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\u0E2D\u0E22\u0E39\u0E48");
            if (Number(p.expectedRevision) !== Number(m.revision)) throw Error("\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E15\u0E39\u0E49\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E41\u0E25\u0E49\u0E27 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E42\u0E2B\u0E25\u0E14\u0E43\u0E2B\u0E21\u0E48\u0E01\u0E48\u0E2D\u0E19\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19");
            if (action === "vending.refill") {
              if (!Array.isArray(p.items) || !p.items.length || new Set(p.items.map((i) => i.productId)).size !== p.items.length) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E01\u0E23\u0E2D\u0E01\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E40\u0E15\u0E34\u0E21\u0E43\u0E2B\u0E49\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
              for (const line of p.items) {
                const i = m.items.find((i2) => i2.productId === line.productId);
                if (!i) throw Error("\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E19\u0E35\u0E49\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E15\u0E31\u0E49\u0E07\u0E02\u0E32\u0E22\u0E43\u0E19\u0E15\u0E39\u0E49");
                const pr = product(i.productId);
                const before = number(i.stock, "\u0E2A\u0E15\u0E4A\u0E2D\u0E01\u0E43\u0E19\u0E15\u0E39\u0E49", true), counted = number(line.counted, "\u0E08\u0E33\u0E19\u0E27\u0E19\u0E17\u0E35\u0E48\u0E19\u0E31\u0E1A", true), added = number(line.added, "\u0E08\u0E33\u0E19\u0E27\u0E19\u0E40\u0E15\u0E34\u0E21", true), directSold = number(line.directSold ?? 0, "\u0E02\u0E32\u0E22\u0E2B\u0E22\u0E2D\u0E14\u0E40\u0E2D\u0E07", true), loss = number(line.loss ?? 0, "\u0E2A\u0E39\u0E0D\u0E40\u0E2A\u0E35\u0E22", true), surplus = number(line.surplus ?? 0, "\u0E1E\u0E1A\u0E40\u0E01\u0E34\u0E19", true);
                if (before - directSold - loss + surplus !== counted) throw Error("\u0E08\u0E33\u0E19\u0E27\u0E19\u0E17\u0E35\u0E48\u0E19\u0E31\u0E1A\u0E15\u0E48\u0E32\u0E07\u0E08\u0E32\u0E01\u0E23\u0E30\u0E1A\u0E1A \u0E01\u0E23\u0E38\u0E13\u0E32\u0E41\u0E22\u0E01\u0E02\u0E32\u0E22\u0E2B\u0E22\u0E2D\u0E14\u0E40\u0E2D\u0E07\u0E41\u0E25\u0E30\u0E2A\u0E48\u0E27\u0E19\u0E15\u0E48\u0E32\u0E07");
                if ((loss || surplus) && !clean(line.reason)) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E23\u0E30\u0E1A\u0E38\u0E40\u0E2B\u0E15\u0E38\u0E1C\u0E25\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E02\u0E32\u0E14\u0E2B\u0E23\u0E37\u0E2D\u0E40\u0E01\u0E34\u0E19");
                if (directSold && pendingDispenses(next).some((t) => t.vendingItems.some((j) => j.machineId === m.id && j.productId === i.productId))) throw Error("\u0E22\u0E31\u0E07\u0E21\u0E35\u0E40\u0E07\u0E34\u0E19\u0E40\u0E1A\u0E34\u0E01\u0E23\u0E2D\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E01\u0E14\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E19\u0E35\u0E49 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E01\u0E14\u0E2B\u0E23\u0E37\u0E2D\u0E04\u0E37\u0E19\u0E40\u0E07\u0E34\u0E19\u0E01\u0E48\u0E2D\u0E19\u0E41\u0E22\u0E01\u0E22\u0E2D\u0E14\u0E02\u0E32\u0E22\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E39\u0E49");
                if (directSold && !p.confirmDirectSales) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E22\u0E2D\u0E14\u0E25\u0E39\u0E01\u0E04\u0E49\u0E32\u0E2B\u0E22\u0E2D\u0E14\u0E0B\u0E37\u0E49\u0E2D\u0E40\u0E2D\u0E07");
                if (added > Number(pr.stockOnHand || 0)) throw Error(pr.name + " \u0E2A\u0E15\u0E4A\u0E2D\u0E01\u0E2B\u0E19\u0E49\u0E32\u0E23\u0E49\u0E32\u0E19\u0E44\u0E21\u0E48\u0E1E\u0E2D\u0E40\u0E15\u0E34\u0E21");
                const directAmount = money(directSold * i.price), unitCost = Number(i.averageCost || 0);
                m.cashBalance = money(m.cashBalance + directAmount);
                m.directDeposits = money(m.directDeposits + directAmount);
                const sourceBefore = Number(pr.stockOnHand || 0);
                pr.stockOnHand = sourceBefore - added;
                if (added) pr.updatedAt = now;
                i.averageCost = counted + added ? (counted * unitCost + added * Number(pr.costPrice || 0)) / (counted + added) : unitCost;
                i.stock = counted + added;
                const record = { productId: i.productId, name: pr.name, unit: pr.unit, before, counted, added, after: i.stock, directSold, directAmount, loss, surplus, reason: clean(line.reason), unitCost, unitPrice: i.price };
                event.items.push(record);
                if (added) movement(i, -added, "VENDING_TRANSFER", { qtyBefore: sourceBefore, qtyAfter: pr.stockOnHand, unitCost: pr.costPrice, note: "\u0E40\u0E15\u0E34\u0E21 " + m.name });
                if (directSold || loss || surplus) movement(i, 0, "VENDING_COUNT", { qtyBefore: pr.stockOnHand, qtyAfter: pr.stockOnHand, machineBefore: before, machineAfter: counted, note: clean(line.reason) || "\u0E15\u0E23\u0E27\u0E08\u0E19\u0E31\u0E1A\u0E02\u0E32\u0E22\u0E1C\u0E48\u0E32\u0E19\u0E15\u0E39\u0E49", directSold, loss, surplus });
              }
              event.directSales = money(event.items.reduce((s, i) => s + i.directAmount, 0));
              event.message = "\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E40\u0E15\u0E34\u0E21\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 " + m.name + " \u0E41\u0E25\u0E49\u0E27";
            } else if (action === "vending.dispense") {
              const withdrawal = (next.cashDrawerTransactions || []).find((t) => t.id === p.withdrawalId);
              if (!withdrawal) throw Error("\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E40\u0E1A\u0E34\u0E01\u0E40\u0E07\u0E34\u0E19");
              const queue = (next.queues || []).find((q) => q.id === withdrawal.queueId);
              if (!queue || queue.status === "CANCELLED") throw Error("\u0E04\u0E34\u0E27\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E2B\u0E23\u0E37\u0E2D\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E41\u0E25\u0E49\u0E27");
              const pending = pendingDispenses(next).find((t) => t.id === withdrawal.id)?.vendingItems.filter((i) => i.machineId === m.id) || [];
              if (p.items && (!Array.isArray(p.items) || new Set(p.items.map((i) => i.productId)).size !== p.items.length || p.items.some((i) => !pending.some((j) => j.productId === i.productId)))) throw Error("\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E01\u0E14\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E40\u0E07\u0E34\u0E19\u0E40\u0E1A\u0E34\u0E01");
              const lines = p.items ? p.items.map((l) => {
                const old = pending.find((i) => i.productId === l.productId), quantity = number(l.quantity, "\u0E08\u0E33\u0E19\u0E27\u0E19\u0E01\u0E14", true);
                if (quantity > old.quantity) throw Error("\u0E08\u0E33\u0E19\u0E27\u0E19\u0E01\u0E14\u0E40\u0E01\u0E34\u0E19\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E40\u0E1A\u0E34\u0E01");
                return { ...old, quantity };
              }).filter((l) => l.quantity > 0) : pending;
              if (!lines.length) throw Error("\u0E44\u0E21\u0E48\u0E21\u0E35\u0E08\u0E33\u0E19\u0E27\u0E19\u0E04\u0E07\u0E40\u0E2B\u0E25\u0E37\u0E2D\u0E43\u0E2B\u0E49\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E01\u0E14");
              const returned = returnedCash(next, withdrawal.id);
              const priorSpent = events(next).filter((e) => e.kind === "dispense" && e.withdrawalId === withdrawal.id).reduce((s, e) => s + e.amount, 0), amount = money(lines.reduce((s, i) => s + i.quantity * i.unitPrice, 0));
              if (amount + priorSpent + returned > Math.abs(withdrawal.cashDelta)) throw Error("\u0E40\u0E07\u0E34\u0E19\u0E40\u0E1A\u0E34\u0E01\u0E04\u0E07\u0E40\u0E2B\u0E25\u0E37\u0E2D\u0E44\u0E21\u0E48\u0E1E\u0E2D \u0E01\u0E23\u0E38\u0E13\u0E32\u0E15\u0E23\u0E27\u0E08\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E04\u0E37\u0E19\u0E40\u0E07\u0E34\u0E19");
              for (const l of lines) {
                const i = m.items.find((i2) => i2.productId === l.productId);
                const qty = number(l.quantity, "\u0E08\u0E33\u0E19\u0E27\u0E19\u0E01\u0E14", true);
                if (!i || qty > i.stock || qty === 0) throw Error("\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E43\u0E19\u0E15\u0E39\u0E49\u0E44\u0E21\u0E48\u0E1E\u0E2D\u0E01\u0E14\u0E15\u0E32\u0E21\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23");
                if (queueDispensed(next, queue.id, i.productId) + qty > Number(queue.products?.[i.productId] || 0)) throw Error("\u0E08\u0E33\u0E19\u0E27\u0E19\u0E01\u0E14\u0E40\u0E01\u0E34\u0E19\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E17\u0E35\u0E48\u0E02\u0E32\u0E22\u0E43\u0E19\u0E04\u0E34\u0E27");
                const before = i.stock;
                i.stock -= qty;
                event.items.push({ productId: i.productId, name: i.name, unit: i.unit, quantity: qty, before, after: i.stock, unitPrice: number(l.unitPrice, "\u0E23\u0E32\u0E04\u0E32\u0E2B\u0E22\u0E2D\u0E14"), unitCost: i.averageCost, amount: money(qty * l.unitPrice) });
              }
              Object.assign(event, { queueId: queue.id, queueNo: queue.queueNo, withdrawalId: withdrawal.id, amount });
              m.cashBalance = money(m.cashBalance + amount);
              m.queueDeposits = money(m.queueDeposits + amount);
              event.message = "\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E01\u0E14\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 " + m.name + " \u0E41\u0E25\u0E49\u0E27";
            } else if (action === "vending.collect") {
              const counted = number(p.counted, "\u0E40\u0E07\u0E34\u0E19\u0E17\u0E35\u0E48\u0E19\u0E31\u0E1A"), collected = number(p.collected, "\u0E40\u0E07\u0E34\u0E19\u0E19\u0E33\u0E2D\u0E2D\u0E01");
              if (collected > counted) throw Error("\u0E40\u0E07\u0E34\u0E19\u0E19\u0E33\u0E2D\u0E2D\u0E01\u0E40\u0E01\u0E34\u0E19\u0E40\u0E07\u0E34\u0E19\u0E17\u0E35\u0E48\u0E19\u0E31\u0E1A\u0E44\u0E14\u0E49");
              const expected = money(m.cashBalance), variance = money(counted - expected), remaining = money(counted - collected);
              if (variance && !clean(p.reason)) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E23\u0E30\u0E1A\u0E38\u0E40\u0E2B\u0E15\u0E38\u0E1C\u0E25\u0E2A\u0E48\u0E27\u0E19\u0E15\u0E48\u0E32\u0E07\u0E40\u0E07\u0E34\u0E19");
              if (!["drawer", "outside"].includes(p.destination)) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E23\u0E30\u0E1A\u0E38\u0E17\u0E35\u0E48\u0E23\u0E31\u0E1A\u0E40\u0E07\u0E34\u0E19");
              Object.assign(event, { periodFrom: m.lastCollectedAt || m.createdAt, openingBalance: m.openingBalance || 0, queueDeposits: m.queueDeposits || 0, directDeposits: m.directDeposits || 0, expected, counted, collected, remaining, variance, reason: clean(p.reason), destination: p.destination });
              if (p.destination === "drawer" && collected) {
                const shift = (next.shifts || []).find((s) => s.id === p.shiftId && s.status === "OPEN");
                if (!shift) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E40\u0E1B\u0E34\u0E14\u0E01\u0E30\u0E17\u0E35\u0E48\u0E23\u0E31\u0E1A\u0E40\u0E07\u0E34\u0E19");
                next.cashDrawerTransactions ||= [];
                next.cashDrawerTransactions.push({ id: "drawer_" + command.id, type: "VENDING_COLLECTION", reasonCode: "VENDING_COLLECTION", reason: "\u0E23\u0E31\u0E1A\u0E40\u0E07\u0E34\u0E19\u0E08\u0E32\u0E01 " + m.name, amount: collected, cashDelta: collected, qrDelta: 0, revenueDelta: 0, createdAt: now, businessDate: new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Bangkok" }).format(new Date(now)), shiftId: shift.id, employeeId: shift.employeeId, deviceId: shift.deviceId, machineId: m.id, vendingEventId: event.id });
              }
              Object.assign(m, { cashBalance: remaining, openingBalance: remaining, queueDeposits: 0, directDeposits: 0, lastCollectedAt: now });
              event.message = "\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E40\u0E01\u0E47\u0E1A\u0E40\u0E07\u0E34\u0E19 " + m.name + " \u0E41\u0E25\u0E49\u0E27";
            } else throw Error("\u0E44\u0E21\u0E48\u0E23\u0E2D\u0E07\u0E23\u0E31\u0E1A\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E15\u0E39\u0E49");
            m.revision++;
            m.updatedAt = now;
          }
          next.vendingEvents.push(event);
          next.auditLogs ||= [];
          next.auditLogs.push({ id: "vaudit_" + command.id, action: "VENDING_" + event.kind.toUpperCase(), createdAt: now, actor: event.actor, details: { machineId: event.machineId, message: event.message } });
          return { state: next, event, result: { id: command.id, status: "applied", message: event.message, completedAt: now } };
        } catch (e) {
          return { state, result: { id: command.id, status: "rejected", message: e.message, completedAt: now } };
        }
      }
      return { list, events, machine, defaultMachine, queueRoutes, queueDispensed, pendingDispenses, returnedCash, releasedQuantity, routesForDraft, frontQuantities, unfundedRoutes, washingBudget, availableWashingBudget, validateCashChanges, queueStockAvailable, validateQueueChanges, apply, money, number };
    });
  }
});

// migration/pos/central/model.cjs
var require_model = __commonJS({
  "migration/pos/central/model.cjs"(exports2, module2) {
    "use strict";
    var crypto = require("node:crypto");
    var Vending = require_vending_core();
    var INVALID_KEYS = /* @__PURE__ */ new Set(["__proto__", "constructor", "prototype"]);
    var LOCAL_SETTINGS = /* @__PURE__ */ new Set(["printerName", "printingEnabled", "silentPrint", "fontScale", "fullscreen", "quotaTargets"]);
    var OWNED = /* @__PURE__ */ new Set(["queues", "productSales", "productReturns", "shifts", "cashDrawerTransactions", "purchases", "purchaseOrders", "supplierReturns", "documentHistory"]);
    var APPEND_ONLY = /* @__PURE__ */ new Set(["inventoryMovements", "auditLogs", "vendingEvents"]);
    var COUNT_LIMIT = 9999999;
    var BUSINESS_COLLECTIONS = ["employees", "queues", "productSales", "productReturns", "inventoryMovements", "suppliers", "purchases", "cashDrawerTransactions", "customers", "promotions", "shifts", "auditLogs"];
    function canonical(value) {
      if (value === null || typeof value !== "object") return JSON.stringify(value);
      if (Array.isArray(value)) return "[" + value.map((v) => canonical(v) ?? "null").join(",") + "]";
      return "{" + Object.keys(value).filter((k) => value[k] !== void 0).sort().map((k) => JSON.stringify(k) + ":" + canonical(value[k])).join(",") + "}";
    }
    function hash(value) {
      return crypto.createHash("sha256").update(canonical(value)).digest("hex");
    }
    function id(value) {
      return typeof value === "string" && /^[A-Za-z0-9_-]{1,160}$/.test(value) && !INVALID_KEYS.has(value);
    }
    function assertCount(value, label = "\u0E08\u0E33\u0E19\u0E27\u0E19\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32") {
      if (!Number.isSafeInteger(value) || value < 0 || value > COUNT_LIMIT) throw Error(`${label}\u0E15\u0E49\u0E2D\u0E07\u0E40\u0E1B\u0E47\u0E19\u0E08\u0E33\u0E19\u0E27\u0E19\u0E40\u0E15\u0E47\u0E21\u0E15\u0E31\u0E49\u0E07\u0E41\u0E15\u0E48 0 \u0E16\u0E36\u0E07 ${COUNT_LIMIT}`);
      return value;
    }
    function entityKey(collection, key) {
      if (!id(collection) || !id(key)) throw Error("\u0E23\u0E2B\u0E31\u0E2A\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
      return collection + "/" + key;
    }
    function entities(state) {
      const result = /* @__PURE__ */ new Map();
      const put = (collection, key, value) => {
        const k = entityKey(collection, key);
        if (result.has(k)) throw Error(`\u0E23\u0E2B\u0E31\u0E2A\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E0B\u0E49\u0E33: ${k}`);
        result.set(k, { collection, key, value: structuredClone(value) });
      };
      for (const [field, value] of Object.entries(state || {})) {
        if (field === "meta" || field === "settings") continue;
        if (Array.isArray(value)) {
          for (const record of value) {
            if (!record || !id(record.id)) throw Error(`\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25 ${field} \u0E44\u0E21\u0E48\u0E21\u0E35\u0E23\u0E2B\u0E31\u0E2A\u0E17\u0E35\u0E48\u0E43\u0E0A\u0E49\u0E0B\u0E34\u0E07\u0E04\u0E4C\u0E44\u0E14\u0E49`);
            put(field, record.id, record);
          }
        } else put("app", field, value);
      }
      for (const [field, value] of Object.entries(state.settings || {})) {
        if (field === "products") {
          for (const [key, product] of Object.entries(value || {})) put("products", key, product);
        } else if (!LOCAL_SETTINGS.has(field)) put("settings", field, value);
      }
      return result;
    }
    function changes(previous, next) {
      const before = entities(previous), after = entities(next), result = [];
      for (const [key, record] of after) {
        const original = before.get(key);
        if (!original || canonical(original.value) !== canonical(record.value)) {
          result.push({ ...record, before: original ? original.value : null, beforeHash: original ? hash(original.value) : null });
        }
      }
      for (const [key, record] of before) {
        if (!after.has(key) && !APPEND_ONLY.has(record.collection)) result.push({ ...record, before: record.value, beforeHash: hash(record.value), value: null });
      }
      return result.sort((a, b) => entityKey(a.collection, a.key).localeCompare(entityKey(b.collection, b.key)));
    }
    function applyRecords(state, records) {
      const next = structuredClone(state);
      for (const collection of BUSINESS_COLLECTIONS) if (!Array.isArray(next[collection])) next[collection] = [];
      for (const record of records) {
        const { collection, key, value } = record;
        entityKey(collection, key);
        if (collection === "products") {
          next.settings ||= {};
          next.settings.products ||= {};
          if (value === null) delete next.settings.products[key];
          else next.settings.products[key] = structuredClone(value);
        } else if (collection === "settings") {
          if (LOCAL_SETTINGS.has(key)) continue;
          next.settings ||= {};
          if (value === null) delete next.settings[key];
          else next.settings[key] = structuredClone(value);
        } else if (collection === "app") {
          if (["meta", "settings"].includes(key)) throw Error("\u0E44\u0E21\u0E48\u0E2D\u0E19\u0E38\u0E0D\u0E32\u0E15\u0E43\u0E2B\u0E49\u0E17\u0E31\u0E1A\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E1B\u0E23\u0E30\u0E08\u0E33\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07");
          if (value === null) delete next[key];
          else next[key] = structuredClone(value);
        } else {
          if (!Array.isArray(next[collection])) next[collection] = [];
          const index = next[collection].findIndex((item) => item.id === key);
          if (value === null) {
            if (index >= 0) next[collection].splice(index, 1);
          } else if (index >= 0) next[collection][index] = structuredClone(value);
          else next[collection].unshift(structuredClone(value));
        }
      }
      return next;
    }
    function stampOwners(previous, state, deviceId) {
      if (!id(deviceId)) throw Error("\u0E23\u0E2B\u0E31\u0E2A\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
      for (const collection of OWNED) {
        const old = new Map((previous[collection] || []).map((row) => [row.id, row]));
        for (const row of state[collection] || []) {
          const original = old.get(row.id);
          row.deviceId = original?.deviceId || deviceId;
          if (original?.deviceId && original.deviceId !== deviceId && canonical(original) !== canonical(row)) {
            throw Error("\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E19\u0E35\u0E49\u0E40\u0E1B\u0E47\u0E19\u0E02\u0E2D\u0E07 POS \u0E2D\u0E35\u0E01\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E17\u0E33\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E17\u0E35\u0E48\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E40\u0E08\u0E49\u0E32\u0E02\u0E2D\u0E07\u0E07\u0E32\u0E19");
          }
        }
        for (const original of old.values()) {
          if (original.deviceId && original.deviceId !== deviceId && !(state[collection] || []).some((row) => row.id === original.id)) throw Error("\u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E25\u0E1A\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E02\u0E2D\u0E07 POS \u0E2D\u0E35\u0E01\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07");
        }
      }
      for (const row of state.productReturns || []) {
        if ((previous.productReturns || []).some((old) => old.id === row.id)) continue;
        const sale = (previous.productSales || []).find((s) => s.id === row.saleId);
        if (sale?.deviceId && sale.deviceId !== deviceId) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E04\u0E37\u0E19\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E17\u0E35\u0E48 POS \u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E17\u0E35\u0E48\u0E2D\u0E2D\u0E01\u0E1A\u0E34\u0E25 \u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E1B\u0E49\u0E2D\u0E07\u0E01\u0E31\u0E19\u0E04\u0E37\u0E19\u0E40\u0E07\u0E34\u0E19\u0E0B\u0E49\u0E33");
      }
      Vending.validateCashChanges(previous, state, deviceId);
      Vending.validateQueueChanges(previous, state);
      return state;
    }
    function validateStocks(previous, next) {
      for (const [key, product] of Object.entries(next.settings?.products || {})) {
        if (!id(key) || product.id !== key) throw Error("\u0E23\u0E2B\u0E31\u0E2A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E19");
        assertCount(Number(product.stockOnHand), product.name || "\u0E2A\u0E15\u0E4A\u0E2D\u0E01");
        if (previous.settings?.products?.[key]?.trackStock !== false && product.trackStock === false) throw Error("\u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E1B\u0E34\u0E14\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E15\u0E4A\u0E2D\u0E01\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E02\u0E32\u0E22\u0E40\u0E01\u0E34\u0E19\u0E08\u0E33\u0E19\u0E27\u0E19");
      }
    }
    function stockDeltas(previous, next) {
      const result = {};
      for (const key of /* @__PURE__ */ new Set([...Object.keys(previous.settings?.products || {}), ...Object.keys(next.settings?.products || {})])) {
        const a = previous.settings?.products?.[key], b = next.settings?.products?.[key];
        if ((b || a)?.trackStock === false) continue;
        const delta = Number(b?.stockOnHand || 0) - Number(a?.stockOnHand || 0);
        if (delta) result[key] = delta;
      }
      return result;
    }
    module2.exports = { canonical, hash, id, assertCount, entityKey, entities, changes, applyRecords, stampOwners, validateStocks, stockDeltas, LOCAL_SETTINGS, OWNED, APPEND_ONLY };
  }
});

// migration/pos/server/engine.cjs
var require_engine = __commonJS({
  "migration/pos/server/engine.cjs"(exports2, module2) {
    "use strict";
    var crypto = require("node:crypto");
    var fs2 = require("node:fs");
    var path2 = require("node:path");
    var Model = require_model();
    function mergeValue(current, before, after, field = "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25") {
      if (Model.canonical(before) === Model.canonical(after)) return structuredClone(current);
      if (Model.canonical(current) === Model.canonical(before) || Model.canonical(current) === Model.canonical(after)) return structuredClone(after);
      if (current && before && after && !Array.isArray(current) && !Array.isArray(before) && !Array.isArray(after) && typeof current === "object" && typeof before === "object" && typeof after === "object") {
        const result = structuredClone(current);
        for (const key of /* @__PURE__ */ new Set([...Object.keys(before), ...Object.keys(after)])) {
          if (Model.canonical(before[key]) === Model.canonical(after[key])) continue;
          if (["updatedAt"].includes(key)) {
            result[key] = after[key];
            continue;
          }
          const value = mergeValue(current[key], before[key], after[key], `${field}.${key}`);
          if (value === void 0) delete result[key];
          else result[key] = value;
        }
        return result;
      }
      const error = Error(`\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E08\u0E32\u0E01\u0E2D\u0E35\u0E01\u0E0A\u0E48\u0E2D\u0E07\u0E17\u0E32\u0E07: ${field} \u0E01\u0E23\u0E38\u0E13\u0E32\u0E15\u0E23\u0E27\u0E08\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E01\u0E48\u0E2D\u0E19\u0E0B\u0E34\u0E07\u0E04\u0E4C\u0E15\u0E48\u0E2D`);
      error.code = "CONFLICT";
      throw error;
    }
    var Engine2 = class {
      constructor(pool) {
        this.pool = pool;
      }
      async connection() {
        return typeof this.pool.connect === "function" ? this.pool.connect() : this.pool;
      }
      async transaction(fn) {
        const client = await this.connection();
        try {
          await client.query("BEGIN");
          await client.query("SELECT id FROM chutima.coordination WHERE id=1 FOR UPDATE");
          const result = await fn(client);
          await client.query("COMMIT");
          return result;
        } catch (error) {
          await client.query("ROLLBACK");
          throw error;
        } finally {
          client.release?.();
        }
      }
      async init() {
        const client = await this.connection();
        try {
          const sql = fs2.readFileSync(path2.join(__dirname, "schema.sql"), "utf8");
          if (typeof client.exec === "function") await client.exec(sql);
          else await client.query(sql);
        } finally {
          client.release?.();
        }
      }
      async register({ id, label, keyHash }) {
        if (!Model.id(id) || !label || !keyHash) throw Error("\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E44\u0E21\u0E48\u0E04\u0E23\u0E1A");
        return this.transaction(async (db) => {
          const existing = (await db.query("SELECT id,label,slot,role FROM chutima.devices WHERE id=$1", [id])).rows[0];
          if (existing) return existing;
          const devices = (await db.query("SELECT slot FROM chutima.devices ORDER BY slot")).rows;
          if (devices.length >= 10) throw Error("\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19 POS \u0E44\u0E14\u0E49\u0E44\u0E21\u0E48\u0E40\u0E01\u0E34\u0E19 10 \u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07");
          const slot = Array.from({ length: 10 }, (_, i) => i + 1).find((n) => !devices.some((d) => d.slot === n));
          const role = slot === 1 ? "primary" : slot === 2 ? "secondary" : "reserve";
          return (await db.query("INSERT INTO chutima.devices(id,label,slot,key_hash,role) VALUES($1,$2,$3,$4,$5) RETURNING id,label,slot,role", [id, label.slice(0, 80), slot, keyHash, role])).rows[0];
        });
      }
      async device(id) {
        return (await this.pool.query("SELECT * FROM chutima.devices WHERE id=$1 AND enabled=true", [id])).rows[0];
      }
      async write(db, record, operationId, owner = null) {
        const { collection, key, value } = record;
        Model.entityKey(collection, key);
        const revision = Number((await db.query("INSERT INTO chutima.changefeed(collection,id,body,operation_id) VALUES($1,$2,$3,$4) RETURNING sequence", [collection, key, JSON.stringify(value), operationId])).rows[0].sequence);
        await db.query("INSERT INTO chutima.entities(collection,id,body,owner_device,revision) VALUES($1,$2,$3,$4,$5) ON CONFLICT(collection,id) DO UPDATE SET body=excluded.body,revision=excluded.revision,owner_device=coalesce(chutima.entities.owner_device,excluded.owner_device)", [collection, key, JSON.stringify(value), owner, revision]);
        return revision;
      }
      async apply(operation) {
        const { sequence, digest, ...payload } = operation;
        if (payload.protocol !== 1 || !Model.id(payload.deviceId) || !Model.id(payload.operationId) || !Number.isSafeInteger(sequence) || sequence < 1 || !Array.isArray(payload.changes) || payload.changes.length > 5e4 || Model.hash(payload) !== digest) throw Error("\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E0B\u0E34\u0E07\u0E04\u0E4C\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
        return this.transaction(async (db) => {
          const device = (await db.query("SELECT * FROM chutima.devices WHERE id=$1 AND enabled=true", [payload.deviceId])).rows[0];
          if (!device || device.role === "reserve") throw Error("\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E2A\u0E33\u0E23\u0E2D\u0E07\u0E22\u0E31\u0E07\u0E17\u0E33\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E08\u0E23\u0E34\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49");
          const duplicate = (await db.query("SELECT digest,result FROM chutima.operations WHERE id=$1", [payload.operationId])).rows[0];
          if (duplicate) {
            if (duplicate.digest !== digest) throw Error("\u0E23\u0E2B\u0E31\u0E2A\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E40\u0E14\u0E34\u0E21\u0E21\u0E35\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E19");
            return duplicate.result;
          }
          if (sequence !== Number(device.last_sequence) + 1) throw Error("\u0E25\u0E33\u0E14\u0E31\u0E1A\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E44\u0E21\u0E48\u0E15\u0E48\u0E2D\u0E40\u0E19\u0E37\u0E48\u0E2D\u0E07 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E2A\u0E48\u0E07\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E04\u0E49\u0E32\u0E07\u0E01\u0E48\u0E2D\u0E19");
          const initialized = (await db.query("SELECT initialized FROM chutima.coordination WHERE id=1")).rows[0].initialized;
          if (payload.bootstrap && (initialized || device.role !== "primary")) throw Error("\u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E19\u0E33\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E15\u0E31\u0E49\u0E07\u0E15\u0E49\u0E19\u0E17\u0E31\u0E1A\u0E23\u0E49\u0E32\u0E19\u0E17\u0E35\u0E48\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\u0E41\u0E25\u0E49\u0E27");
          if (!payload.bootstrap && !initialized) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E19\u0E33\u0E40\u0E02\u0E49\u0E32\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E15\u0E31\u0E49\u0E07\u0E15\u0E49\u0E19\u0E01\u0E48\u0E2D\u0E19");
          const transfers = payload.transfers || [];
          const releases = payload.releases || [];
          if (!Array.isArray(releases) || releases.length > 100 || payload.bootstrap && releases.length) throw Error("\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E1E\u0E31\u0E01\u0E2A\u0E15\u0E4A\u0E2D\u0E01\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
          const releaseTotals = {};
          for (const r of releases) {
            if (!Model.id(r.commandId) || !Model.id(r.productId) || !Number.isSafeInteger(r.quantity) || r.quantity < 1 || releaseTotals[r.productId]) throw Error("\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E1E\u0E31\u0E01\u0E2A\u0E15\u0E4A\u0E2D\u0E01\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
            const command = (await db.query("SELECT id FROM chutima.web_commands WHERE id=$1 AND product_id=$2", [r.commandId, r.productId])).rows[0];
            if (!command) throw Error("\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E15\u0E23\u0E27\u0E08\u0E19\u0E31\u0E1A\u0E17\u0E35\u0E48\u0E23\u0E2D\u0E2D\u0E22\u0E39\u0E48");
            releaseTotals[r.productId] = r.quantity;
          }
          if (!Array.isArray(transfers) || transfers.length > 100 || payload.bootstrap && transfers.length) throw Error("\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E42\u0E2D\u0E19\u0E08\u0E33\u0E19\u0E27\u0E19\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
          const transferTotals = {};
          for (const t of transfers) {
            if (!Model.id(t.productId) || !Model.id(t.toDevice) || t.toDevice === device.id || !Number.isSafeInteger(t.quantity) || t.quantity < 1) throw Error("\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E42\u0E2D\u0E19\u0E08\u0E33\u0E19\u0E27\u0E19\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
            if (!(await db.query("SELECT id FROM chutima.devices WHERE id=$1 AND enabled=true", [t.toDevice])).rows.length) throw Error("\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07");
            transferTotals[t.productId] = (transferTotals[t.productId] || 0) + t.quantity;
          }
          let cashBefore = null;
          if (payload.changes.some((c) => ["cashDrawerTransactions", "queues"].includes(c.collection))) {
            const records = (await db.query("SELECT collection,id,body FROM chutima.entities WHERE body IS NOT NULL")).rows;
            cashBefore = Model.applyRecords({ meta: {} }, records.map((r) => ({ collection: r.collection, key: r.id, value: r.body })));
            const after = Model.applyRecords(cashBefore, payload.changes);
            require_vending_core().validateCashChanges(cashBefore, after, device.id);
            require_vending_core().validateQueueChanges(cashBefore, after);
          }
          let cursor = 0;
          const seen = /* @__PURE__ */ new Set();
          for (const change of payload.changes) {
            const { collection, key, before, value } = change, k = Model.entityKey(collection, key);
            if (["vendingMachines", "vendingEvents"].includes(collection)) throw Error("\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E15\u0E39\u0E49\u0E15\u0E49\u0E2D\u0E07\u0E17\u0E33\u0E1C\u0E48\u0E32\u0E19\u0E40\u0E21\u0E19\u0E39 \u0E40\u0E15\u0E34\u0E21 \u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E1B\u0E49\u0E2D\u0E07\u0E01\u0E31\u0E19\u0E22\u0E2D\u0E14\u0E15\u0E39\u0E49\u0E0B\u0E49\u0E33");
            if (collection === "reportPages" || collection === "app" && ["reportPage", "officeSettings", "officeCapabilities"].includes(key)) throw Error("\u0E23\u0E32\u0E22\u0E07\u0E32\u0E19\u0E41\u0E01\u0E49\u0E44\u0E02\u0E08\u0E32\u0E01 POS \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49");
            if (seen.has(k)) throw Error("\u0E21\u0E35\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E0B\u0E49\u0E33\u0E43\u0E19\u0E18\u0E38\u0E23\u0E01\u0E23\u0E23\u0E21");
            seen.add(k);
            const row = (await db.query("SELECT * FROM chutima.entities WHERE collection=$1 AND id=$2", [collection, key])).rows[0];
            if (Model.OWNED.has(collection) && row?.owner_device && row.owner_device !== device.id) throw Error("\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E19\u0E35\u0E49\u0E40\u0E1B\u0E47\u0E19\u0E02\u0E2D\u0E07 POS \u0E2D\u0E35\u0E01\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07");
            if (Model.OWNED.has(collection) && row?.body?.deviceId === "SERVERJJ") throw Error("\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E19\u0E35\u0E49\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E08\u0E32\u0E01\u0E40\u0E27\u0E47\u0E1A \u0E01\u0E23\u0E38\u0E13\u0E32\u0E08\u0E31\u0E14\u0E01\u0E32\u0E23\u0E17\u0E35\u0E48\u0E40\u0E27\u0E47\u0E1A\u0E2B\u0E25\u0E31\u0E07\u0E1A\u0E49\u0E32\u0E19");
            if (["settings", "promotions", "employees", "suppliers"].includes(collection) && device.role !== "primary") throw Error("\u0E41\u0E01\u0E49\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E23\u0E49\u0E32\u0E19\u0E17\u0E35\u0E48 POS \u0E2B\u0E25\u0E31\u0E01\u0E2B\u0E23\u0E37\u0E2D\u0E40\u0E27\u0E47\u0E1A\u0E2B\u0E25\u0E31\u0E07\u0E1A\u0E49\u0E32\u0E19");
            let merged;
            if (collection === "products") {
              const a = structuredClone(before), b = structuredClone(value), c = structuredClone(row?.body ?? null);
              for (const field of ["packBarcode", "packSize"]) if (b && c && !(field in b)) {
                b[field] = c[field];
                if (a) a[field] = c[field];
              }
              if (b) {
                if (b.id !== key) throw Error("\u0E23\u0E2B\u0E31\u0E2A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E19");
                Model.assertCount(Number(b.stockOnHand));
              }
              if (c && c.trackStock !== false && b?.trackStock === false) throw Error("\u0E2B\u0E49\u0E32\u0E21\u0E1B\u0E34\u0E14\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E15\u0E4A\u0E2D\u0E01\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E02\u0E32\u0E22\u0E40\u0E01\u0E34\u0E19");
              for (const v of [a, b, c]) if (v) delete v.stockOnHand;
              if (device.role !== "primary") {
                const fields = (v) => {
                  const copy = structuredClone(v);
                  if (copy) delete copy.updatedAt;
                  return copy;
                };
                if (Model.canonical(fields(a)) !== Model.canonical(fields(b))) throw Error("\u0E41\u0E01\u0E49\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E17\u0E35\u0E48 POS \u0E2B\u0E25\u0E31\u0E01\u0E2B\u0E23\u0E37\u0E2D\u0E40\u0E27\u0E47\u0E1A\u0E2B\u0E25\u0E31\u0E07\u0E1A\u0E49\u0E32\u0E19");
              }
              merged = payload.bootstrap ? structuredClone(value) : mergeValue(c, a, b, k);
              const quota = Number((await db.query("SELECT available FROM chutima.allocations WHERE product_id=$1 AND device_id=$2", [key, device.id])).rows[0]?.available || 0);
              const delta = payload.bootstrap ? Number(value?.stockOnHand || 0) : Number(payload.stockDeltas?.[key] || 0);
              if (!Number.isSafeInteger(delta)) throw Error("\u0E08\u0E33\u0E19\u0E27\u0E19\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E2A\u0E15\u0E4A\u0E2D\u0E01\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
              if (!payload.bootstrap && delta !== Number(value?.stockOnHand || 0) - Number(before?.stockOnHand || 0)) throw Error("\u0E1C\u0E25\u0E2A\u0E15\u0E4A\u0E2D\u0E01\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23");
              const available = Model.assertCount(quota + delta, "\u0E08\u0E33\u0E19\u0E27\u0E19\u0E17\u0E35\u0E48\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E02\u0E32\u0E22\u0E44\u0E14\u0E49");
              const total = Model.assertCount(Number(row?.body?.stockOnHand || 0) + delta + (transferTotals[key] || 0) + (releaseTotals[key] || 0), "\u0E2A\u0E15\u0E4A\u0E2D\u0E01\u0E23\u0E27\u0E21");
              if (merged === null && total !== 0) throw Error("\u0E22\u0E31\u0E07\u0E21\u0E35\u0E2A\u0E15\u0E4A\u0E2D\u0E01\u0E04\u0E07\u0E40\u0E2B\u0E25\u0E37\u0E2D \u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E25\u0E1A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32");
              if (merged) merged.stockOnHand = total;
              await db.query("INSERT INTO chutima.allocations VALUES($1,$2,$3) ON CONFLICT(product_id,device_id) DO UPDATE SET available=excluded.available", [key, device.id, available]);
            } else {
              merged = payload.bootstrap ? structuredClone(value) : mergeValue(row?.body ?? null, before, value, k);
            }
            if (Model.APPEND_ONLY.has(collection) && row && Model.canonical(row.body) !== Model.canonical(merged)) throw Error("\u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E41\u0E01\u0E49\u0E1B\u0E23\u0E30\u0E27\u0E31\u0E15\u0E34\u0E17\u0E35\u0E48\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E41\u0E25\u0E49\u0E27");
            if (Model.OWNED.has(collection) && merged) merged.deviceId = row?.owner_device || device.id;
            cursor = await this.write(db, { collection, key, value: merged }, payload.operationId, Model.OWNED.has(collection) ? device.id : null);
          }
          for (const [productId, delta] of Object.entries(payload.stockDeltas || {})) if (delta && !seen.has("products/" + productId)) throw Error("\u0E44\u0E21\u0E48\u0E21\u0E35\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E1B\u0E23\u0E30\u0E01\u0E2D\u0E1A\u0E01\u0E32\u0E23\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E2A\u0E15\u0E4A\u0E2D\u0E01");
          for (const r of releases) {
            if (!seen.has("products/" + r.productId) || transferTotals[r.productId] || Number(payload.stockDeltas?.[r.productId] || 0) !== -r.quantity) throw Error("\u0E15\u0E49\u0E2D\u0E07\u0E1E\u0E31\u0E01\u0E08\u0E33\u0E19\u0E27\u0E19\u0E02\u0E32\u0E22\u0E43\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E01\u0E48\u0E2D\u0E19\u0E15\u0E23\u0E27\u0E08\u0E19\u0E31\u0E1A");
            await db.query("INSERT INTO chutima.web_releases(command_id,device_id,product_id,quantity) VALUES($1,$2,$3,$4) ON CONFLICT(command_id,device_id,product_id) DO UPDATE SET quantity=chutima.web_releases.quantity+excluded.quantity", [r.commandId, device.id, r.productId, r.quantity]);
            if ((await db.query("SELECT id FROM chutima.web_results WHERE id=$1", [r.commandId])).rows.length) await db.query("UPDATE chutima.allocations SET available=available+$1 WHERE product_id=$2 AND device_id=$3", [r.quantity, r.productId, device.id]);
          }
          for (let index = 0; index < transfers.length; index++) {
            const t = transfers[index];
            if (!seen.has("products/" + t.productId) || Number(payload.stockDeltas?.[t.productId] || 0) > -transferTotals[t.productId]) throw Error("\u0E15\u0E49\u0E2D\u0E07\u0E25\u0E14\u0E08\u0E33\u0E19\u0E27\u0E19\u0E17\u0E35\u0E48\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E15\u0E49\u0E19\u0E17\u0E32\u0E07\u0E01\u0E48\u0E2D\u0E19\u0E42\u0E2D\u0E19");
            const current = Number((await db.query("SELECT available FROM chutima.allocations WHERE product_id=$1 AND device_id=$2", [t.productId, t.toDevice])).rows[0]?.available || 0);
            await db.query("INSERT INTO chutima.allocations VALUES($1,$2,$3) ON CONFLICT(product_id,device_id) DO UPDATE SET available=excluded.available", [t.productId, t.toDevice, Model.assertCount(current + t.quantity)]);
            await db.query("INSERT INTO chutima.stock_transfers(id,product_id,from_device,to_device,quantity) VALUES($1,$2,$3,$4,$5)", [payload.operationId + "_" + index, t.productId, device.id, t.toDevice, t.quantity]);
          }
          if (payload.bootstrap) await db.query("UPDATE chutima.coordination SET initialized=true WHERE id=1");
          const result = { applied: true, operationId: payload.operationId, digest, cursor };
          await db.query("INSERT INTO chutima.operations(id,device_id,device_sequence,digest,payload,result) VALUES($1,$2,$3,$4,$5,$6)", [payload.operationId, device.id, sequence, digest, JSON.stringify(payload), JSON.stringify(result)]);
          await db.query("UPDATE chutima.devices SET last_sequence=$1,last_seen=now() WHERE id=$2", [sequence, device.id]);
          return result;
        });
      }
      async pull(deviceId, after = 0, limit = 500) {
        if (!Number.isSafeInteger(after) || after < 0 || !Number.isSafeInteger(limit) || limit < 1 || limit > 1e3) throw Error("\u0E0A\u0E48\u0E27\u0E07\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
        return this.transaction(async (db) => {
          const rows = (await db.query("SELECT c.sequence,c.collection,c.id,e.body FROM chutima.changefeed c JOIN chutima.entities e ON e.collection=c.collection AND e.id=c.id WHERE c.sequence>$1 ORDER BY c.sequence LIMIT $2", [after, limit])).rows;
          const quota = new Map((await db.query("SELECT product_id,available FROM chutima.allocations WHERE device_id=$1", [deviceId])).rows.map((r) => [r.product_id, Number(r.available)]));
          const records = rows.map((row) => {
            const value = structuredClone(row.body);
            if (row.collection === "products" && value) {
              value.stockOnHand = quota.get(row.id) || 0;
            }
            return { collection: row.collection, key: row.id, value, revision: Number(row.sequence) };
          });
          return { records, cursor: rows.length ? Number(rows.at(-1).sequence) : after, hasMore: rows.length === limit };
        });
      }
      async exportState() {
        const rows = (await this.pool.query("SELECT collection,id,body FROM chutima.entities WHERE body IS NOT NULL ORDER BY revision")).rows;
        return Model.applyRecords({ meta: {} }, rows.map((r) => ({ collection: r.collection, key: r.id, value: r.body })));
      }
    };
    module2.exports = { Engine: Engine2, mergeValue };
  }
});

// migration/pos/server/device-manager.cjs
var require_device_manager = __commonJS({
  "migration/pos/server/device-manager.cjs"(exports2, module2) {
    "use strict";
    var crypto = require("node:crypto");
    var Model = require_model();
    var active = (d) => ["primary", "secondary"].includes(d?.role);
    var DeviceManager = class {
      constructor(engine) {
        this.engine = engine;
      }
      async manager(db, pin) {
        const row = (await db.query("SELECT body FROM chutima.entities WHERE collection='settings' AND id='managerPin'")).rows[0];
        const a = Buffer.from(String(pin || "")), b = Buffer.from(String(row?.body || ""));
        if (!b.length || a.length !== b.length || !crypto.timingSafeEqual(a, b)) throw Error("PIN \u0E1C\u0E39\u0E49\u0E08\u0E31\u0E14\u0E01\u0E32\u0E23\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
      }
      async stock(db, deviceId) {
        const products = (await db.query("SELECT id,body FROM chutima.entities WHERE collection='products' AND body IS NOT NULL ORDER BY id")).rows;
        const rows = (await db.query("SELECT product_id,device_id,available FROM chutima.allocations")).rows;
        return products.map((p) => {
          const allocations = rows.filter((a) => a.product_id === p.id).map((a) => ({ deviceId: a.device_id, quantity: Number(a.available) }));
          const total = Number(p.body.stockOnHand || 0), held = allocations.reduce((s, a) => s + a.quantity, 0);
          return { id: p.id, name: p.body.name, unit: p.body.unit, total, free: Math.max(0, total - held), own: allocations.find((a) => a.deviceId === deviceId)?.quantity || 0, allocations };
        });
      }
      async status(deviceId) {
        return this.engine.transaction(async (db) => ({
          devices: (await db.query("SELECT id,label,slot,role,last_seen,reported_pending,client_version FROM chutima.devices WHERE enabled=true ORDER BY slot")).rows,
          stocks: await this.stock(db, deviceId),
          switching: (await db.query("SELECT id,source_id,target_id,role,target_role FROM chutima.device_switches WHERE status='pending' ORDER BY created_at")).rows
        }));
      }
      async adjust(deviceId, input) {
        if (!Model.id(input?.id) || !["target", "checkout"].includes(input.mode) || !Number.isSafeInteger(input.sequence) || !input.desired || Object.keys(input.desired).length > 1e4) throw Error("\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E42\u0E04\u0E27\u0E15\u0E32\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
        const digest = Model.hash(input);
        return this.engine.transaction(async (db) => {
          const old = (await db.query("SELECT digest,result FROM chutima.quota_operations WHERE id=$1 AND device_id=$2", [input.id, deviceId])).rows[0];
          if (old) {
            if (old.digest !== digest) throw Error("\u0E23\u0E2B\u0E31\u0E2A\u0E42\u0E04\u0E27\u0E15\u0E32\u0E0B\u0E49\u0E33\u0E01\u0E31\u0E1A\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E2D\u0E37\u0E48\u0E19");
            return old.result;
          }
          const device = (await db.query("SELECT * FROM chutima.devices WHERE id=$1 AND enabled=true", [deviceId])).rows[0];
          if (!active(device)) throw Error("\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E2A\u0E33\u0E23\u0E2D\u0E07\u0E22\u0E31\u0E07\u0E17\u0E33\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E08\u0E23\u0E34\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49");
          if (Number(device.last_sequence) !== input.sequence) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E2A\u0E48\u0E07\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E04\u0E49\u0E32\u0E07\u0E01\u0E48\u0E2D\u0E19\u0E1B\u0E23\u0E31\u0E1A\u0E42\u0E04\u0E27\u0E15\u0E32");
          if ((await db.query("SELECT id FROM chutima.device_switches WHERE source_id=$1 AND status='pending'", [deviceId])).rows.length) throw Error("\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49\u0E01\u0E33\u0E25\u0E31\u0E07\u0E23\u0E2D\u0E2A\u0E25\u0E31\u0E1A\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C \u0E01\u0E23\u0E38\u0E13\u0E32\u0E1B\u0E34\u0E14\u0E01\u0E30\u0E41\u0E25\u0E30\u0E2A\u0E48\u0E07\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E04\u0E49\u0E32\u0E07");
          const stocks = await this.stock(db, deviceId), changes = [];
          for (const [id, wanted] of Object.entries(input.desired)) {
            Model.assertCount(wanted);
            const p = stocks.find((p2) => p2.id === id);
            if (!p) throw Error("\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32");
            if (Number(input.expected?.[id]) !== p.own) throw Error("\u0E42\u0E04\u0E27\u0E15\u0E32\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E41\u0E25\u0E49\u0E27 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E23\u0E31\u0E1A\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E25\u0E48\u0E32\u0E2A\u0E38\u0E14");
            if ((await db.query("SELECT w.id FROM chutima.web_commands w LEFT JOIN chutima.web_results r ON r.id=w.id WHERE w.product_id=$1 AND r.id IS NULL", [id])).rows.length) throw Error("\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E19\u0E35\u0E49\u0E01\u0E33\u0E25\u0E31\u0E07\u0E15\u0E23\u0E27\u0E08\u0E19\u0E31\u0E1A \u0E01\u0E23\u0E38\u0E13\u0E32\u0E23\u0E2D\u0E1C\u0E25\u0E15\u0E23\u0E27\u0E08\u0E19\u0E31\u0E1A");
            const next = input.mode === "checkout" ? Math.max(p.own, wanted) : Math.min(wanted, p.own + p.free);
            if (next > p.own + p.free) throw Error(`${p.name} \u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E44\u0E21\u0E48\u0E1E\u0E2D \u0E1E\u0E23\u0E49\u0E2D\u0E21\u0E02\u0E32\u0E22 ${p.own + p.free} ${p.unit || "\u0E0A\u0E34\u0E49\u0E19"} (\u0E2A\u0E48\u0E27\u0E19\u0E17\u0E35\u0E48\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E2D\u0E37\u0E48\u0E19\u0E01\u0E31\u0E19\u0E44\u0E27\u0E49\u0E22\u0E31\u0E07\u0E19\u0E33\u0E21\u0E32\u0E02\u0E32\u0E22\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49)`);
            if (next !== p.own) {
              await db.query("INSERT INTO chutima.allocations(product_id,device_id,available) VALUES($1,$2,$3) ON CONFLICT(product_id,device_id) DO UPDATE SET available=excluded.available", [id, deviceId, next]);
              const row = (await db.query("SELECT body FROM chutima.entities WHERE collection='products' AND id=$1", [id])).rows[0];
              await this.engine.write(db, { collection: "products", key: id, value: row.body }, "quota_" + input.id);
            }
            changes.push({ id, before: p.own, quantity: next });
          }
          const result = { id: input.id, changes };
          await db.query("INSERT INTO chutima.quota_operations(id,device_id,digest,result) VALUES($1,$2,$3,$4)", [input.id, deviceId, digest, JSON.stringify(result)]);
          return result;
        });
      }
      async manage(deviceId, input) {
        return this.engine.transaction(async (db) => {
          await this.manager(db, input?.pin);
          if (input.action === "rename") {
            const label = String(input.label || "").trim();
            if (!label || label.length > 80) throw Error("\u0E0A\u0E37\u0E48\u0E2D\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E15\u0E49\u0E2D\u0E07\u0E21\u0E35 1\u201380 \u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23");
            await db.query("UPDATE chutima.devices SET label=$1 WHERE id=$2", [label, input.targetId]);
            return { saved: true };
          }
          if (input.action !== "activate" || !["primary", "secondary"].includes(input.role)) throw Error("\u0E04\u0E33\u0E2A\u0E31\u0E48\u0E07\u0E08\u0E31\u0E14\u0E01\u0E32\u0E23\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
          const target = (await db.query("SELECT * FROM chutima.devices WHERE id=$1 AND enabled=true", [input.targetId])).rows[0];
          if (!target) throw Error("\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07");
          if (target.role === input.role) return { saved: true };
          if ((await db.query("SELECT id FROM chutima.device_switches WHERE status='pending'")).rows.length) throw Error("\u0E21\u0E35\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E2A\u0E25\u0E31\u0E1A\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E17\u0E35\u0E48\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E40\u0E2A\u0E23\u0E47\u0E08 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E40\u0E1B\u0E34\u0E14\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E40\u0E14\u0E34\u0E21\u0E43\u0E2B\u0E49\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E41\u0E25\u0E30\u0E1B\u0E34\u0E14\u0E01\u0E30\u0E01\u0E48\u0E2D\u0E19");
          const source = (await db.query("SELECT * FROM chutima.devices WHERE role=$1 AND enabled=true", [input.role])).rows[0];
          if (!source) {
            await db.query("UPDATE chutima.devices SET role=$1 WHERE id=$2", [input.role, target.id]);
            return { saved: true };
          }
          const id = crypto.randomUUID();
          await db.query("INSERT INTO chutima.device_switches(id,source_id,target_id,role,target_role) VALUES($1,$2,$3,$4,$5)", [id, source.id, target.id, input.role, target.role]);
          return { pending: true, message: "\u0E23\u0E2D\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E40\u0E14\u0E34\u0E21\u0E1B\u0E34\u0E14\u0E01\u0E30 \u0E2A\u0E48\u0E07\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E04\u0E49\u0E32\u0E07 \u0E41\u0E25\u0E30\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E1E\u0E31\u0E01\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E2D\u0E31\u0E15\u0E42\u0E19\u0E21\u0E31\u0E15\u0E34\u0E40\u0E21\u0E37\u0E48\u0E2D\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21\u0E15\u0E48\u0E2D" };
        });
      }
      async quiesce(deviceId, input) {
        return this.engine.transaction(async (db) => {
          const request = (await db.query("SELECT * FROM chutima.device_switches WHERE id=$1 AND (source_id=$2 OR target_id=$2)", [input.id, deviceId])).rows[0];
          if (!request) throw Error("\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E2A\u0E25\u0E31\u0E1A\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07");
          if (request.status === "done") return { done: true, role: (await db.query("SELECT role FROM chutima.devices WHERE id=$1", [deviceId])).rows[0].role };
          const device = (await db.query("SELECT * FROM chutima.devices WHERE id=$1", [deviceId])).rows[0];
          if (Number(input.sequence) !== Number(device.last_sequence) || input.pending !== 0) throw Error("\u0E22\u0E31\u0E07\u0E21\u0E35\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E04\u0E49\u0E32\u0E07\u0E43\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E40\u0E14\u0E34\u0E21");
          if ((await db.query("SELECT id FROM chutima.entities WHERE collection='shifts' AND owner_device=$1 AND body->>'status'='OPEN'", [deviceId])).rows.length) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E1B\u0E34\u0E14\u0E01\u0E30\u0E17\u0E35\u0E48\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E40\u0E14\u0E34\u0E21\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E25\u0E31\u0E1A\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07");
          if (deviceId === request.source_id) {
            await db.query("UPDATE chutima.device_switches SET source_ack=true WHERE id=$1", [request.id]);
            request.source_ack = true;
          } else {
            await db.query("UPDATE chutima.device_switches SET target_ack=true WHERE id=$1", [request.id]);
            request.target_ack = true;
          }
          if (!request.source_ack || request.target_role !== "reserve" && !request.target_ack) return { done: false };
          const ids = request.target_role === "reserve" ? [request.source_id] : [request.source_id, request.target_id];
          for (const id of ids) {
            await db.query("UPDATE chutima.allocations SET available=0 WHERE device_id=$1", [id]);
            await db.query("UPDATE chutima.devices SET role='reserve' WHERE id=$1", [id]);
          }
          await db.query("UPDATE chutima.devices SET role=$1 WHERE id=$2", [request.role, request.target_id]);
          if (request.target_role !== "reserve") await db.query("UPDATE chutima.devices SET role=$1 WHERE id=$2", [request.target_role, request.source_id]);
          else {
            const owned = (await db.query("SELECT collection,id,body FROM chutima.entities WHERE owner_device=$1 AND collection IN ('queues','productSales','productReturns') AND body IS NOT NULL", [request.source_id])).rows;
            for (const row of owned) {
              const value = { ...row.body, originalDeviceId: row.body.originalDeviceId || request.source_id, deviceId: request.target_id };
              await db.query("UPDATE chutima.entities SET owner_device=$1 WHERE collection=$2 AND id=$3", [request.target_id, row.collection, row.id]);
              await this.engine.write(db, { collection: row.collection, key: row.id, value }, "switch_" + request.id);
            }
          }
          await db.query("UPDATE chutima.device_switches SET status='done' WHERE id=$1", [request.id]);
          const products = (await db.query("SELECT id,body FROM chutima.entities WHERE collection='products' AND body IS NOT NULL")).rows;
          for (const p of products) await this.engine.write(db, { collection: "products", key: p.id, value: p.body }, "switch_" + request.id);
          return { done: true, role: deviceId === request.target_id ? request.role : request.target_role };
        });
      }
    };
    module2.exports = { DeviceManager, active };
  }
});

// migration/pos/renderer/pos-core.js
var require_pos_core = __commonJS({
  "migration/pos/renderer/pos-core.js"(exports2, module2) {
    "use strict";
    (function(host) {
      const clean = (value) => String(value ?? "").trim();
      const key = (value) => clean(value).toLocaleLowerCase();
      const money = (value) => Math.round(Number(value) * 100) / 100;
      const count = (value) => Number.isSafeInteger(Number(value)) && Number(value) >= 0 && Number(value) <= 9999999;
      function nonnegative(value) {
        return clean(value) !== "" && Number.isFinite(Number(value)) && Number(value) >= 0 && Number(value) <= 99999999;
      }
      function products(state) {
        return Object.values(state.settings.products || {});
      }
      function lookup(state, code) {
        const wanted = key(code);
        if (!wanted) return null;
        const found = products(state).filter((p) => key(p.barcode) === wanted || key(p.sku) === wanted);
        if (found.length > 1) throw Error("\u0E23\u0E2B\u0E31\u0E2A\u0E19\u0E35\u0E49\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E21\u0E32\u0E01\u0E01\u0E27\u0E48\u0E32 1 \u0E23\u0E32\u0E22\u0E01\u0E32\u0E23 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E41\u0E01\u0E49\u0E23\u0E2B\u0E31\u0E2A\u0E43\u0E19\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32");
        return found[0] || null;
      }
      function validateProduct(state, p) {
        if (!clean(p.name) || !clean(p.sku) || !clean(p.unit)) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E01\u0E23\u0E2D\u0E01\u0E0A\u0E37\u0E48\u0E2D \u0E23\u0E2B\u0E31\u0E2A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 \u0E41\u0E25\u0E30\u0E2B\u0E19\u0E48\u0E27\u0E22\u0E02\u0E32\u0E22");
        if (clean(p.name).length > 160 || clean(p.sku).length > 64 || clean(p.barcode).length > 128) throw Error("\u0E0A\u0E37\u0E48\u0E2D\u0E2B\u0E23\u0E37\u0E2D\u0E23\u0E2B\u0E31\u0E2A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E22\u0E32\u0E27\u0E40\u0E01\u0E34\u0E19\u0E44\u0E1B");
        if (/[\u0000-\u001f\u007f]/.test(p.barcode || "")) throw Error("\u0E1A\u0E32\u0E23\u0E4C\u0E42\u0E04\u0E49\u0E14\u0E21\u0E35\u0E2D\u0E31\u0E01\u0E02\u0E23\u0E30\u0E17\u0E35\u0E48\u0E43\u0E0A\u0E49\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49");
        if (![p.price, p.costPrice].every(nonnegative) || !count(p.lowStockAt) || !count(p.stockOnHand)) throw Error("\u0E23\u0E32\u0E04\u0E32\u0E41\u0E25\u0E30\u0E08\u0E33\u0E19\u0E27\u0E19\u0E15\u0E49\u0E2D\u0E07\u0E44\u0E21\u0E48\u0E15\u0E34\u0E14\u0E25\u0E1A \u0E08\u0E33\u0E19\u0E27\u0E19\u0E15\u0E49\u0E2D\u0E07\u0E40\u0E1B\u0E47\u0E19\u0E08\u0E33\u0E19\u0E27\u0E19\u0E40\u0E15\u0E47\u0E21");
        const ownCodes = [key(p.sku), key(p.barcode)].filter(Boolean);
        if (products(state).some((other) => other.id !== p.id && [key(other.sku), key(other.barcode)].filter(Boolean).some((c) => ownCodes.includes(c)))) throw Error("\u0E23\u0E2B\u0E31\u0E2A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E2B\u0E23\u0E37\u0E2D\u0E1A\u0E32\u0E23\u0E4C\u0E42\u0E04\u0E49\u0E14\u0E19\u0E35\u0E49\u0E16\u0E39\u0E01\u0E43\u0E0A\u0E49\u0E41\u0E25\u0E49\u0E27");
        return p;
      }
      function lines(state, quantities, available = (p) => Number(p.stockOnHand || 0)) {
        return Object.entries(quantities).filter(([, qty]) => Number(qty) !== 0).map(([id, qty]) => {
          const p = state.settings.products[id];
          if (!p || p.enabled === false) throw Error("\u0E21\u0E35\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E17\u0E35\u0E48\u0E1B\u0E34\u0E14\u0E02\u0E32\u0E22\u0E2B\u0E23\u0E37\u0E2D\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E41\u0E25\u0E49\u0E27 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E25\u0E1A\u0E2D\u0E2D\u0E01\u0E08\u0E32\u0E01\u0E15\u0E30\u0E01\u0E23\u0E49\u0E32");
          if (!count(qty) || Number(qty) < 1) throw Error("\u0E08\u0E33\u0E19\u0E27\u0E19\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E15\u0E49\u0E2D\u0E07\u0E40\u0E1B\u0E47\u0E19\u0E08\u0E33\u0E19\u0E27\u0E19\u0E40\u0E15\u0E47\u0E21\u0E21\u0E32\u0E01\u0E01\u0E27\u0E48\u0E32 0");
          if (!nonnegative(p.price)) throw Error("\u0E23\u0E32\u0E04\u0E32\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
          if (p.trackStock !== false && qty > available(p)) throw Error(`${p.name} \u0E04\u0E07\u0E40\u0E2B\u0E25\u0E37\u0E2D ${available(p)} ${p.unit}`);
          return {
            productId: id,
            sku: p.sku,
            barcode: p.barcode || "",
            label: p.name,
            unit: p.unit,
            quantity: Number(qty),
            unitPrice: money(p.price),
            unitCost: Number(p.costPrice || 0),
            tracked: p.trackStock !== false,
            amount: money(Number(qty) * money(p.price))
          };
        });
      }
      function remaining(state, sale, item) {
        const returned = (state.productReturns || []).filter((r) => r.saleId === sale.id).flatMap((r) => r.items).filter((i) => i.productId === item.productId).reduce((sum, i) => sum + i.quantity, 0);
        return Math.max(0, item.quantity - returned);
      }
      function refundLines(state, sale, selected) {
        const results = sale.items.flatMap((item) => {
          const request = selected[item.productId];
          if (!request || Number(request.quantity) === 0) return [];
          if (!count(request.quantity) || request.quantity < 1 || request.quantity > remaining(state, sale, item)) throw Error("\u0E08\u0E33\u0E19\u0E27\u0E19\u0E04\u0E37\u0E19\u0E40\u0E01\u0E34\u0E19\u0E08\u0E33\u0E19\u0E27\u0E19\u0E17\u0E35\u0E48\u0E22\u0E31\u0E07\u0E04\u0E37\u0E19\u0E44\u0E14\u0E49");
          if (!["restock", "damaged"].includes(request.condition)) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E23\u0E30\u0E1A\u0E38\u0E2A\u0E20\u0E32\u0E1E\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E17\u0E35\u0E48\u0E04\u0E37\u0E19");
          return [{ ...item, quantity: Number(request.quantity), condition: request.condition, amount: money(request.quantity * item.unitPrice) }];
        });
        if (!results.length) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E08\u0E33\u0E19\u0E27\u0E19\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E17\u0E35\u0E48\u0E08\u0E30\u0E04\u0E37\u0E19");
        return results;
      }
      const api = { clean, key, money, count, nonnegative, products, lookup, validateProduct, lines, remaining, refundLines };
      if (typeof module2 !== "undefined" && module2.exports) module2.exports = api;
      else host.POS = Object.freeze(api);
    })(globalThis);
  }
});

// migration/pos/renderer/inventory-bridge-core.js
var require_inventory_bridge_core = __commonJS({
  "migration/pos/renderer/inventory-bridge-core.js"(exports2, module2) {
    (function(root, factory) {
      const api = factory(typeof module2 === "object" && module2.exports ? require_pos_core() : root.POS);
      if (typeof module2 === "object" && module2.exports) module2.exports = api;
      else root.InventoryBridge = api;
    })(typeof globalThis !== "undefined" ? globalThis : exports2, function(POS) {
      "use strict";
      const fields = ["id", "name", "sku", "barcode", "packBarcode", "packSize", "category", "unit", "price", "costPrice", "stockOnHand", "lowStockAt", "enabled", "showInQueue", "trackStock", "image", "createdAt", "updatedAt", "trashedAt", "trashedBy"];
      const clean = (value, limit = 240) => String(value ?? "").trim().slice(0, limit);
      const own = (obj, key) => Object.prototype.hasOwnProperty.call(obj || {}, key);
      const safeId = (value) => /^[A-Za-z0-9_-]{1,100}$/.test(String(value));
      function version(product) {
        if (!product) return null;
        return JSON.stringify(fields.filter((k) => k !== "image").map((k) => product[k] ?? null));
      }
      function stockVersion(state, product) {
        return JSON.stringify([Number(product.stockOnHand || 0), (state.inventoryMovements || []).find((m) => m.productId === product.id)?.id || null, product.trackStock !== false]);
      }
      function snapshot(state) {
        return {
          schema: 1,
          productTrashVersion: 1,
          revision: Number(state.meta?.inventoryBridge?.revision || 0),
          products: Object.values(state.settings?.products || {}).map((p) => ({ ...Object.fromEntries(fields.map((k) => [k, p[k] ?? null])), version: version(p), stockVersion: stockVersion(state, p) })),
          categories: [...state.settings?.productCategories || []],
          suppliers: structuredClone(state.suppliers || []),
          purchases: structuredClone(state.purchases || []),
          movements: (state.inventoryMovements || []).slice(0, 2e3).map((m) => ({ id: m.id, productId: m.productId, delta: m.delta, type: m.type, qtyBefore: m.qtyBefore, qtyAfter: m.qtyAfter, unitCost: m.unitCost, note: m.note, documentNo: m.documentNo, createdAt: m.createdAt, actor: m.actor || "POS", sourceId: m.sourceId }))
        };
      }
      function changed(previous, next) {
        const a = snapshot(previous), b = snapshot(next);
        a.revision = 0;
        b.revision = 0;
        return JSON.stringify(a) !== JSON.stringify(b);
      }
      function number(value, label, integer = false, positive = false) {
        if (value === "" || value === null || value === void 0 || !POS.nonnegative(value) || integer && !POS.count(value) || positive && Number(value) <= 0) throw Error(`${label}\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07`);
        return Number(value);
      }
      function apply(state, command, now = (/* @__PURE__ */ new Date()).toISOString()) {
        if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(command?.id || "")) throw Error("\u0E40\u0E25\u0E02\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
        const existing = state.meta?.inventoryBridge?.results?.[command.id];
        if (existing) return { state, result: existing, duplicate: true };
        const next = structuredClone(state), input = command.payload || {}, id = command.id, actor = clean(command.actor || "\u0E40\u0E08\u0E49\u0E32\u0E02\u0E2D\u0E07\u0E23\u0E49\u0E32\u0E19\u0E1C\u0E48\u0E32\u0E19\u0E40\u0E27\u0E47\u0E1A", 120);
        const date = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Bangkok" }).format(new Date(now));
        let movementIndex = 0;
        next.settings ||= {};
        next.settings.products ||= {};
        next.inventoryMovements ||= [];
        next.suppliers ||= [];
        next.purchases ||= [];
        const getProduct = (productId) => {
          if (!safeId(productId) || !own(next.settings.products, productId)) throw Error("\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32");
          return next.settings.products[productId];
        };
        const assertVersion = (actual, expected) => {
          if (expected !== actual) throw Error("\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E2B\u0E25\u0E31\u0E07\u0E08\u0E32\u0E01\u0E40\u0E1B\u0E34\u0E14\u0E1F\u0E2D\u0E23\u0E4C\u0E21 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E2D\u0E31\u0E1B\u0E40\u0E14\u0E15\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E41\u0E25\u0E49\u0E27\u0E15\u0E23\u0E27\u0E08\u0E2D\u0E35\u0E01\u0E04\u0E23\u0E31\u0E49\u0E07");
        };
        const movement = (p, delta, type, note, documentNo = "") => next.inventoryMovements.unshift({ id: `web_stock_${id}_${movementIndex++}`, productId: p.id, delta, type, sourceType: "WEB_BACKOFFICE", sourceId: id, qtyBefore: p.stockOnHand - delta, qtyAfter: p.stockOnHand, unitCost: p.costPrice, note: clean(note), documentNo: clean(documentNo, 80), businessDate: date, createdAt: now, actor, shiftId: null, employeeId: null, dedupeKey: `web:${id}:${p.id}:${type}` });
        let message = "\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E41\u0E25\u0E49\u0E27";
        try {
          if (command.type === "product.save" && ["product.trash", "product.restore"].includes(input.workflow)) {
            const p = getProduct(input.id);
            assertVersion(version(p), input.expectedVersion);
            const trash = input.workflow === "product.trash";
            if (trash === !!p.trashedAt) throw Error(trash ? "\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E19\u0E35\u0E49\u0E2D\u0E22\u0E39\u0E48\u0E43\u0E19\u0E16\u0E31\u0E07\u0E02\u0E22\u0E30\u0E41\u0E25\u0E49\u0E27" : "\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E19\u0E35\u0E49\u0E16\u0E39\u0E01\u0E01\u0E39\u0E49\u0E04\u0E37\u0E19\u0E41\u0E25\u0E49\u0E27");
            p.trashedAt = trash ? now : null;
            p.trashedBy = trash ? actor : null;
            p.updatedAt = now;
            message = trash ? `\u0E22\u0E49\u0E32\u0E22 ${p.name} \u0E44\u0E1B\u0E16\u0E31\u0E07\u0E02\u0E22\u0E30\u0E41\u0E25\u0E49\u0E27 \xB7 \u0E40\u0E01\u0E47\u0E1A\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E27\u0E49 \u0E44\u0E21\u0E48\u0E25\u0E1A\u0E2D\u0E31\u0E15\u0E42\u0E19\u0E21\u0E31\u0E15\u0E34` : `\u0E01\u0E39\u0E49\u0E04\u0E37\u0E19 ${p.name} \u0E01\u0E25\u0E31\u0E1A\u0E2B\u0E19\u0E49\u0E32\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E41\u0E25\u0E49\u0E27`;
          } else if (command.type === "product.save") {
            const productId = input.id || `web_product_${id}`;
            if (!safeId(productId) || ["__proto__", "constructor", "prototype"].includes(productId)) throw Error("\u0E23\u0E2B\u0E31\u0E2A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
            const original = own(next.settings.products, productId) ? next.settings.products[productId] : null;
            assertVersion(version(original), input.expectedVersion ?? null);
            if (original?.trashedAt) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E01\u0E39\u0E49\u0E04\u0E37\u0E19\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E08\u0E32\u0E01\u0E16\u0E31\u0E07\u0E02\u0E22\u0E30\u0E01\u0E48\u0E2D\u0E19\u0E41\u0E01\u0E49\u0E44\u0E02");
            const p = { ...original || {}, id: productId, name: clean(input.name, 120), sku: clean(input.sku, 80).toUpperCase(), barcode: clean(input.barcode, 100), category: clean(input.category, 80) || "\u0E17\u0E31\u0E48\u0E27\u0E44\u0E1B", unit: clean(input.unit, 40), price: number(input.price, "\u0E23\u0E32\u0E04\u0E32"), costPrice: original ? original.costPrice : number(input.costPrice, "\u0E15\u0E49\u0E19\u0E17\u0E38\u0E19"), stockOnHand: original ? original.stockOnHand : number(input.stockOnHand, "\u0E22\u0E2D\u0E14\u0E15\u0E31\u0E49\u0E07\u0E15\u0E49\u0E19", true), lowStockAt: number(input.lowStockAt, "\u0E22\u0E2D\u0E14\u0E40\u0E15\u0E37\u0E2D\u0E19", true), enabled: input.enabled !== false, trackStock: original ? original.trackStock : input.trackStock !== false, createdAt: original?.createdAt || now, updatedAt: now, image: original?.image || "" };
            if (own(input, "image")) {
              if (input.image && (!/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(input.image) || input.image.length > 2e5)) throw Error("\u0E23\u0E39\u0E1B\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07\u0E2B\u0E23\u0E37\u0E2D\u0E21\u0E35\u0E02\u0E19\u0E32\u0E14\u0E43\u0E2B\u0E0D\u0E48\u0E40\u0E01\u0E34\u0E19\u0E44\u0E1B");
              p.image = input.image;
            }
            p.showInQueue = own(input, "showInQueue") ? input.showInQueue === true : typeof original?.showInQueue === "boolean" ? original.showInQueue : !!original && /น้ำยาซักผ้า|น้ำยาปรับผ้านุ่ม/.test(p.name);
            p.packBarcode = own(input, "packBarcode") ? clean(input.packBarcode, 100) : original?.packBarcode || "";
            p.packSize = own(input, "packSize") ? number(input.packSize, "\u0E0A\u0E34\u0E49\u0E19\u0E15\u0E48\u0E2D\u0E41\u0E1E\u0E47\u0E01", true, true) : original?.packSize || 1;
            if (p.packBarcode && p.packBarcode === p.barcode) throw Error("\u0E1A\u0E32\u0E23\u0E4C\u0E42\u0E04\u0E49\u0E14\u0E0A\u0E34\u0E49\u0E19\u0E41\u0E25\u0E30\u0E41\u0E1E\u0E47\u0E01\u0E15\u0E49\u0E2D\u0E07\u0E15\u0E48\u0E32\u0E07\u0E01\u0E31\u0E19");
            const codes = [p.barcode, p.packBarcode].filter(Boolean);
            if (Object.values(next.settings.products).some((other) => other.id !== p.id && [other.barcode, other.packBarcode].some((c) => c && codes.includes(c)))) throw Error("\u0E1A\u0E32\u0E23\u0E4C\u0E42\u0E04\u0E49\u0E14\u0E19\u0E35\u0E49\u0E43\u0E0A\u0E49\u0E01\u0E31\u0E1A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E2D\u0E37\u0E48\u0E19\u0E41\u0E25\u0E49\u0E27");
            POS.validateProduct(next, p);
            next.settings.products[productId] = p;
            if (!original && p.trackStock !== false && p.stockOnHand > 0) movement(p, p.stockOnHand, "OPENING", "\u0E22\u0E2D\u0E14\u0E15\u0E31\u0E49\u0E07\u0E15\u0E49\u0E19\u0E08\u0E32\u0E01\u0E40\u0E27\u0E47\u0E1A");
            next.settings.productCategories = [.../* @__PURE__ */ new Set([...next.settings.productCategories || [], p.category])];
            message = `\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01 ${p.name} \u0E41\u0E25\u0E49\u0E27`;
          } else if (command.type === "stock.receive" || command.type === "stock.count") {
            const p = getProduct(input.productId);
            if (p.trackStock === false) throw Error("\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E19\u0E35\u0E49\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E15\u0E34\u0E14\u0E15\u0E32\u0E21\u0E2A\u0E15\u0E4A\u0E2D\u0E01");
            const note = clean(input.note);
            if (!note) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E23\u0E30\u0E1A\u0E38\u0E40\u0E2B\u0E15\u0E38\u0E1C\u0E25");
            const before = number(p.stockOnHand, "\u0E2A\u0E15\u0E4A\u0E2D\u0E01\u0E1B\u0E31\u0E08\u0E08\u0E38\u0E1A\u0E31\u0E19", true), value = number(input.quantity, "\u0E08\u0E33\u0E19\u0E27\u0E19", true, command.type === "stock.receive");
            if (command.type === "stock.count") assertVersion(stockVersion(next, p), input.expectedStockVersion);
            if (command.type === "stock.receive") {
              const cost = number(input.unitCost, "\u0E15\u0E49\u0E19\u0E17\u0E38\u0E19");
              p.costPrice = (before * Number(p.costPrice || 0) + value * cost) / (before + value);
              p.stockOnHand = before + value;
            } else p.stockOnHand = value;
            if (!POS.count(p.stockOnHand)) throw Error("\u0E08\u0E33\u0E19\u0E27\u0E19\u0E2A\u0E15\u0E4A\u0E2D\u0E01\u0E2A\u0E39\u0E07\u0E40\u0E01\u0E34\u0E19\u0E02\u0E2D\u0E1A\u0E40\u0E02\u0E15");
            p.updatedAt = now;
            movement(p, p.stockOnHand - before, command.type === "stock.receive" ? "RECEIVE" : "ADJUST", note, input.documentNo);
            message = `${p.name}: ${before} \u2192 ${p.stockOnHand} ${p.unit}`;
          } else if (command.type === "supplier.save") {
            const supplierId = input.id || `web_supplier_${id}`;
            if (!safeId(supplierId)) throw Error("\u0E23\u0E2B\u0E31\u0E2A\u0E1C\u0E39\u0E49\u0E08\u0E33\u0E2B\u0E19\u0E48\u0E32\u0E22\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
            const original = next.suppliers.find((s) => s.id === supplierId);
            assertVersion(original?.updatedAt || null, input.expectedVersion ?? null);
            const supplier = { ...original || {}, id: supplierId, code: clean(input.code, 40).toUpperCase(), name: clean(input.name, 120), contactName: clean(input.contactName, 100), phone: clean(input.phone, 40), lineId: clean(input.lineId, 100), address: clean(input.address, 400), notes: clean(input.notes), taxId: clean(input.taxId, 30), creditDays: number(input.creditDays ?? 0, "\u0E40\u0E04\u0E23\u0E14\u0E34\u0E15", true), active: input.active !== false, createdAt: original?.createdAt || now, updatedAt: now };
            if (!supplier.code || !supplier.name) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E01\u0E23\u0E2D\u0E01\u0E23\u0E2B\u0E31\u0E2A\u0E41\u0E25\u0E30\u0E0A\u0E37\u0E48\u0E2D\u0E1C\u0E39\u0E49\u0E08\u0E33\u0E2B\u0E19\u0E48\u0E32\u0E22");
            if (next.suppliers.some((s) => s.id !== supplierId && POS.key(s.code) === POS.key(supplier.code))) throw Error("\u0E23\u0E2B\u0E31\u0E2A\u0E1C\u0E39\u0E49\u0E08\u0E33\u0E2B\u0E19\u0E48\u0E32\u0E22\u0E0B\u0E49\u0E33");
            next.suppliers = next.suppliers.filter((s) => s.id !== supplierId);
            next.suppliers.push(supplier);
            message = `\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E1C\u0E39\u0E49\u0E08\u0E33\u0E2B\u0E19\u0E48\u0E32\u0E22 ${supplier.name} \u0E41\u0E25\u0E49\u0E27`;
          } else if (command.type === "purchase.receive") {
            const supplier = next.suppliers.find((s) => s.id === input.supplierId && s.active !== false);
            if (!supplier) throw Error("\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E1C\u0E39\u0E49\u0E08\u0E33\u0E2B\u0E19\u0E48\u0E32\u0E22\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19");
            if (!Array.isArray(input.items) || !input.items.length || input.items.length > 100) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E08\u0E31\u0E14\u0E0B\u0E37\u0E49\u0E2D");
            if (new Set(input.items.map((i) => i.productId)).size !== input.items.length) throw Error("\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E08\u0E31\u0E14\u0E0B\u0E37\u0E49\u0E2D\u0E0B\u0E49\u0E33");
            const items = input.items.map((i) => ({ product: getProduct(i.productId), quantity: number(i.quantity, "\u0E08\u0E33\u0E19\u0E27\u0E19\u0E23\u0E31\u0E1A\u0E40\u0E02\u0E49\u0E32", true, true), unitCost: number(i.unitCost, "\u0E15\u0E49\u0E19\u0E17\u0E38\u0E19") }));
            const subtotal = POS.money(items.reduce((sum, i) => sum + i.quantity * i.unitCost, 0)), discount = number(input.discount ?? 0, "\u0E2A\u0E48\u0E27\u0E19\u0E25\u0E14"), shipping = number(input.shipping ?? 0, "\u0E04\u0E48\u0E32\u0E02\u0E19\u0E2A\u0E48\u0E07");
            if (discount > subtotal) throw Error("\u0E2A\u0E48\u0E27\u0E19\u0E25\u0E14\u0E40\u0E01\u0E34\u0E19\u0E22\u0E2D\u0E14\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32");
            const total = POS.money(subtotal - discount + shipping), paidAmount = number(input.paidAmount ?? 0, "\u0E22\u0E2D\u0E14\u0E08\u0E48\u0E32\u0E22");
            if (!POS.nonnegative(total) || paidAmount > total) throw Error("\u0E22\u0E2D\u0E14\u0E0A\u0E33\u0E23\u0E30\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
            const method = ["cash", "qr", "credit"].includes(input.paymentMethod) ? input.paymentMethod : "credit";
            if (method === "credit" && paidAmount > 0) throw Error("\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E0A\u0E48\u0E2D\u0E07\u0E17\u0E32\u0E07\u0E17\u0E35\u0E48\u0E08\u0E48\u0E32\u0E22\u0E08\u0E23\u0E34\u0E07 \u0E2B\u0E23\u0E37\u0E2D\u0E23\u0E30\u0E1A\u0E38\u0E22\u0E2D\u0E14\u0E08\u0E48\u0E32\u0E22\u0E40\u0E1B\u0E47\u0E19 0");
            const purchaseId = `web_purchase_${id}`, purchaseNo = `PO-W-${date.replaceAll("-", "")}-${id.slice(0, 8).toUpperCase()}`;
            const purchaseItems = items.map((i) => {
              const p = i.product, before = Number(p.stockOnHand || 0), oldCost = Number(p.costPrice || 0), lineTotal = POS.money(i.quantity * i.unitCost), share = subtotal > 0 ? lineTotal / subtotal : 1 / items.length, effectiveLineTotal = lineTotal + (shipping - discount) * share, effectiveUnitCost = effectiveLineTotal / i.quantity;
              p.stockOnHand = p.trackStock === false ? before : before + i.quantity;
              if (!POS.count(p.stockOnHand)) throw Error("\u0E08\u0E33\u0E19\u0E27\u0E19\u0E2A\u0E15\u0E4A\u0E2D\u0E01\u0E2A\u0E39\u0E07\u0E40\u0E01\u0E34\u0E19\u0E02\u0E2D\u0E1A\u0E40\u0E02\u0E15");
              p.costPrice = p.trackStock === false ? effectiveUnitCost : (before * oldCost + i.quantity * effectiveUnitCost) / (before + i.quantity);
              p.updatedAt = now;
              if (p.trackStock !== false) movement(p, i.quantity, "PURCHASE_RECEIVE", `${purchaseNo} \xB7 ${supplier.name}`, input.documentNo);
              return { productId: p.id, sku: p.sku, name: p.name, unit: p.unit, purchaseMode: "piece", quantity: i.quantity, unitCost: i.unitCost, lineTotal, effectiveUnitCost, effectiveLineTotal, stockBefore: before, stockAfter: p.stockOnHand, previousAverageCost: oldCost, newAverageCost: p.costPrice };
            });
            next.purchases.unshift({ id: purchaseId, purchaseNo, businessDate: date, supplierId: supplier.id, supplierSnapshot: { code: supplier.code, name: supplier.name, contactName: supplier.contactName, phone: supplier.phone }, documentNo: clean(input.documentNo, 80), items: purchaseItems, subtotal, discount, shipping, total, paymentMethod: method, paidAmount, balance: POS.money(total - paidAmount), paymentStatus: paidAmount === total ? "PAID" : paidAmount > 0 ? "PARTIAL" : "UNPAID", payments: paidAmount ? [{ id: `web_payment_${id}`, method, amount: paidAmount, paidAt: now, createdAt: now, note: "\u0E0A\u0E33\u0E23\u0E30\u0E08\u0E32\u0E01\u0E40\u0E27\u0E47\u0E1A\u0E2B\u0E25\u0E31\u0E07\u0E1A\u0E49\u0E32\u0E19 (\u0E19\u0E2D\u0E01\u0E25\u0E34\u0E49\u0E19\u0E0A\u0E31\u0E01 POS)", shiftId: null, employeeId: null }] : [], dueDate: clean(input.dueDate, 10) || null, notes: clean(input.notes), createdAt: now, updatedAt: now, shiftId: null, employeeId: null, actor });
            message = `\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01 ${purchaseNo} \u0E41\u0E25\u0E30\u0E23\u0E31\u0E1A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E41\u0E25\u0E49\u0E27`;
          } else throw Error("\u0E44\u0E21\u0E48\u0E23\u0E2D\u0E07\u0E23\u0E31\u0E1A\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E19\u0E35\u0E49");
          const result = { id, status: "applied", message, completedAt: now };
          next.meta ||= {};
          next.meta.inventoryBridge ||= { revision: 0, results: {} };
          next.meta.inventoryBridge.results ||= {};
          next.meta.inventoryBridge.results[id] = result;
          next.auditLogs ||= [];
          next.auditLogs.push({ id: `web_audit_${id}`, action: "WEB_INVENTORY", createdAt: now, details: { type: command.type, actor, message } });
          return { state: next, result, duplicate: false };
        } catch (error) {
          const rejected = structuredClone(state);
          rejected.meta ||= {};
          rejected.meta.inventoryBridge ||= { revision: 0, results: {} };
          rejected.meta.inventoryBridge.results ||= {};
          const result = { id, status: "rejected", message: clean(error.message), completedAt: now };
          rejected.meta.inventoryBridge.results[id] = result;
          return { state: rejected, result, duplicate: false };
        }
      }
      return { snapshot, changed, apply, version, stockVersion };
    });
  }
});

// migration/pos/renderer/basket-fees.js
var require_basket_fees = __commonJS({
  "migration/pos/renderer/basket-fees.js"(exports2, module2) {
    "use strict";
    (function(host) {
      const cents = (n) => Math.round(Number(n || 0) * 100);
      function payments(queue) {
        const fee = Math.max(0, (queue.pricing?.lines || []).filter((l) => l.type === "fee").reduce((s, l) => s + cents(l.amount), 0));
        const extras = (queue.extras || []).filter((e) => !e.cancelled && !e.voided).reduce((s, e) => s + cents(e.amount), 0);
        const total = Math.max(0, cents(queue.pricing?.total) + extras), result = /* @__PURE__ */ new Map();
        let paid = 0, allocated = 0;
        for (const p of [...queue.payments || []].sort((a, b) => String(a.createdAt || "").localeCompare(String(b.createdAt || "")))) {
          paid = Math.max(0, paid + cents(p.amount));
          const expected = total ? Math.round(Math.min(paid, total) * Math.min(fee, total) / total) : 0;
          const amount = Number.isFinite(p.basketServiceFee) ? cents(p.basketServiceFee) : expected - allocated;
          result.set(p.id, amount / 100);
          allocated += amount;
        }
        return result;
      }
      function stamp(state) {
        for (const q of state.queues || []) {
          const fees = payments(q);
          for (const p of q.payments || []) if (!Number.isFinite(p.basketServiceFee)) p.basketServiceFee = fees.get(p.id) || 0;
        }
        return state;
      }
      function count(queue) {
        if (!queue || queue.status === "CANCELLED") return 0;
        return Array.isArray(queue.baskets) && queue.baskets.length ? queue.baskets.filter((b) => b.status !== "CANCELLED").length : Math.max(1, Math.trunc(Number(queue.basketCount || 1)));
      }
      function openingShift(queue) {
        return queue.openingShiftId || queue.shiftId || (queue.payments || []).find((p) => p.stage === "OPEN_QUEUE")?.shiftId || null;
      }
      function forShift(state, shift) {
        if (!shift) return { basketCount: 0, basketServiceFee: 0 };
        const queues = state.queues || [];
        const basketCount = queues.filter((q) => openingShift(q) === shift.id).reduce((sum, q) => sum + count(q), 0);
        const basketServiceFee = queues.reduce((sum, q) => {
          const fees = payments(q);
          return sum + (q.payments || []).filter((p) => p.shiftId === shift.id).reduce((s, p) => s + (fees.get(p.id) || 0), 0);
        }, 0);
        return { basketCount, basketServiceFee: Math.round(basketServiceFee * 100) / 100 };
      }
      const api = { payments, stamp, count, openingShift, forShift };
      if (typeof module2 !== "undefined" && module2.exports) module2.exports = api;
      else host.BasketFees = api;
    })(globalThis);
  }
});

// migration/pos/server/reports.cjs
var require_reports = __commonJS({
  "migration/pos/server/reports.cjs"(exports2, module2) {
    "use strict";
    var Model = require_model();
    var BasketFees = require_basket_fees();
    var Vending = require_vending_core();
    var n = (v) => Number.isFinite(Number(v)) ? Number(v) : 0;
    var day = (v) => {
      const d = new Date(v);
      return Number.isFinite(+d) ? new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Bangkok" }).format(d) : "";
    };
    function build(state, input, now = (/* @__PURE__ */ new Date()).toISOString()) {
      const { kind, from, to } = input;
      if (!/^\d{4}-\d{2}-\d{2}$/.test(from || "") || !/^\d{4}-\d{2}-\d{2}$/.test(to || "") || from > to || (/* @__PURE__ */ new Date(from + "T00:00:00Z")).toISOString().slice(0, 10) !== from || (/* @__PURE__ */ new Date(to + "T00:00:00Z")).toISOString().slice(0, 10) !== to) throw Error("\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E0A\u0E48\u0E27\u0E07\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E43\u0E2B\u0E49\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
      const within = (v) => {
        const d = day(v);
        return d >= from && d <= to;
      }, who = (id) => state.employees?.find((e) => e.id === id)?.name || id || "", allowed = (r) => (!input.deviceId || r.deviceId === input.deviceId) && (!input.employeeId || r.employeeId === input.employeeId);
      let rows = [], note = "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48 SERVERJJ \u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A\u0E41\u0E25\u0E49\u0E27 \u0E2D\u0E32\u0E08\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E23\u0E27\u0E21\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E08\u0E32\u0E01\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E2D\u0E2D\u0E1F\u0E44\u0E25\u0E19\u0E4C";
      const queues = state.queues || [], sales = state.productSales || [], returns = state.productReturns || [];
      if (kind === "sales") {
        for (const [docs, sign, label] of [[sales, 1, "\u0E02\u0E32\u0E22"], [returns, -1, "\u0E04\u0E37\u0E19"]]) for (const doc of docs.filter((r) => within(r.createdAt) && allowed(r))) for (const i of doc.items || []) {
          const cost = i.unitCost == null ? null : n(i.unitCost);
          rows.push({ "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48": day(doc.createdAt), "\u0E40\u0E25\u0E02\u0E1A\u0E34\u0E25": String(doc.saleNo || doc.returnNo || doc.id), "\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17": label, "\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32": i.label || i.name || i.productId, "\u0E08\u0E33\u0E19\u0E27\u0E19": sign * n(i.quantity), "\u0E22\u0E2D\u0E14\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32": sign * n(i.amount), "\u0E15\u0E49\u0E19\u0E17\u0E38\u0E19\u0E15\u0E2D\u0E19\u0E02\u0E32\u0E22/\u0E0A\u0E34\u0E49\u0E19": cost, "\u0E01\u0E33\u0E44\u0E23\u0E02\u0E31\u0E49\u0E19\u0E15\u0E49\u0E19\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E27\u0E19\u0E25\u0E14\u0E23\u0E30\u0E14\u0E31\u0E1A\u0E1A\u0E34\u0E25": cost === null ? null : sign * (n(i.amount) - cost * n(i.quantity)), "\u0E1E\u0E19\u0E31\u0E01\u0E07\u0E32\u0E19": who(doc.employeeId), "\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07": doc.deviceId || "" });
        }
        for (const e of Vending.events(state).filter((e2) => e2.kind === "refill" && within(e2.createdAt) && allowed(e2))) for (const i of e.items.filter((i2) => i2.directSold > 0)) rows.push({ "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48": day(e.createdAt), "\u0E40\u0E25\u0E02\u0E1A\u0E34\u0E25": e.id, "\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17": "\u0E02\u0E32\u0E22\u0E2B\u0E22\u0E2D\u0E14\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E39\u0E49", "\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32": i.name, "\u0E08\u0E33\u0E19\u0E27\u0E19": i.directSold, "\u0E22\u0E2D\u0E14\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32": i.directAmount, "\u0E15\u0E49\u0E19\u0E17\u0E38\u0E19\u0E15\u0E2D\u0E19\u0E02\u0E32\u0E22/\u0E0A\u0E34\u0E49\u0E19": i.unitCost, "\u0E01\u0E33\u0E44\u0E23\u0E02\u0E31\u0E49\u0E19\u0E15\u0E49\u0E19\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E27\u0E19\u0E25\u0E14\u0E23\u0E30\u0E14\u0E31\u0E1A\u0E1A\u0E34\u0E25": i.directAmount - i.directSold * i.unitCost, "\u0E1E\u0E19\u0E31\u0E01\u0E07\u0E32\u0E19": e.actor || "", "\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07": e.machineName || e.machineId });
        note += " \xB7 \u0E01\u0E33\u0E44\u0E23\u0E0A\u0E48\u0E2D\u0E07\u0E27\u0E48\u0E32\u0E07\u0E2B\u0E21\u0E32\u0E22\u0E16\u0E36\u0E07\u0E44\u0E21\u0E48\u0E21\u0E35\u0E15\u0E49\u0E19\u0E17\u0E38\u0E19\u0E22\u0E49\u0E2D\u0E19\u0E2B\u0E25\u0E31\u0E07 \u0E44\u0E21\u0E48\u0E43\u0E0A\u0E49\u0E15\u0E49\u0E19\u0E17\u0E38\u0E19\u0E1B\u0E31\u0E08\u0E08\u0E38\u0E1A\u0E31\u0E19\u0E41\u0E17\u0E19";
      } else if (kind === "laundry") {
        rows = queues.filter((q) => within(q.createdAt) && allowed(q)).map((q) => {
          const total = n(q.pricing?.total) + (q.extras || []).reduce((s, e) => s + n(e.amount), 0), paid = (q.payments || []).reduce((s, p) => s + n(p.amount), 0);
          return { "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E23\u0E31\u0E1A\u0E07\u0E32\u0E19": day(q.createdAt), "\u0E04\u0E34\u0E27": String(q.queueNo || q.id), "\u0E25\u0E39\u0E01\u0E04\u0E49\u0E32": q.customerName || "", "\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23": (q.baskets || []).map((b) => b.serviceType || "").join(", "), "\u0E2A\u0E16\u0E32\u0E19\u0E30": q.status, "\u0E22\u0E2D\u0E14\u0E15\u0E32\u0E21\u0E1A\u0E34\u0E25": total, "\u0E23\u0E31\u0E1A\u0E2A\u0E38\u0E17\u0E18\u0E34\u0E2A\u0E30\u0E2A\u0E21": paid, "\u0E04\u0E49\u0E32\u0E07\u0E23\u0E31\u0E1A": q.status === "CANCELLED" ? 0 : Math.max(0, total - paid), "\u0E08\u0E33\u0E19\u0E27\u0E19\u0E15\u0E30\u0E01\u0E23\u0E49\u0E32": q.baskets?.length || 1, "\u0E1E\u0E19\u0E31\u0E01\u0E07\u0E32\u0E19": who(q.employeeId), "\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07": q.deviceId || "" };
        });
        note += " \xB7 \u0E22\u0E2D\u0E14\u0E23\u0E31\u0E1A\u0E2A\u0E30\u0E2A\u0E21\u0E02\u0E2D\u0E07\u0E04\u0E34\u0E27\u0E2D\u0E32\u0E08\u0E23\u0E31\u0E1A\u0E40\u0E07\u0E34\u0E19\u0E04\u0E19\u0E25\u0E30\u0E27\u0E31\u0E19\u0E01\u0E31\u0E1A\u0E27\u0E31\u0E19\u0E1D\u0E32\u0E01\u0E0B\u0E31\u0E01";
      } else if (kind === "cash" || kind === "overview") {
        const all = [];
        for (const q of queues) for (const p of q.payments || []) all.push({ ...p, basketServiceFee: BasketFees.payments(q).get(p.id) || 0, deviceId: q.deviceId, employeeId: p.employeeId || q.employeeId, source: "\u0E07\u0E32\u0E19\u0E0B\u0E31\u0E01", ref: String(q.queueNo || q.id) });
        for (const s of sales) if (s.payment) all.push({ ...s.payment, createdAt: s.payment.createdAt || s.createdAt, deviceId: s.deviceId, employeeId: s.employeeId, source: "\u0E02\u0E32\u0E22\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32", ref: String(s.saleNo || s.id) });
        for (const r of returns) if (r.payment) all.push({ ...r.payment, createdAt: r.payment.createdAt || r.createdAt, deviceId: r.deviceId, employeeId: r.employeeId, source: "\u0E04\u0E37\u0E19\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32", ref: String(r.returnNo || r.id) });
        for (const e of Vending.events(state).filter((e2) => e2.kind === "refill" && n(e2.directSales) > 0)) all.push({ createdAt: e.createdAt, amount: n(e.directSales), method: "\u0E40\u0E07\u0E34\u0E19\u0E2A\u0E14\u0E43\u0E19\u0E15\u0E39\u0E49", source: "\u0E02\u0E32\u0E22\u0E2B\u0E22\u0E2D\u0E14\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E39\u0E49", ref: e.id, deviceId: e.deviceId, employeeId: e.employeeId });
        const filtered = all.filter((p) => within(p.createdAt) && allowed(p));
        if (kind === "cash") rows = filtered.map((p) => ({ "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E23\u0E31\u0E1A/\u0E04\u0E37\u0E19\u0E40\u0E07\u0E34\u0E19\u0E08\u0E23\u0E34\u0E07": day(p.createdAt), "\u0E2D\u0E49\u0E32\u0E07\u0E2D\u0E34\u0E07": p.ref, "\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17": p.source, "\u0E0A\u0E48\u0E2D\u0E07\u0E17\u0E32\u0E07": p.method, "\u0E08\u0E33\u0E19\u0E27\u0E19\u0E40\u0E07\u0E34\u0E19": n(p.amount), "\u0E1E\u0E19\u0E31\u0E01\u0E07\u0E32\u0E19": who(p.employeeId), "\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07": p.deviceId || "" }));
        else {
          const days = /* @__PURE__ */ new Map();
          for (const p of filtered) {
            const d = day(p.createdAt), r = days.get(d) || { "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48": d, "\u0E23\u0E31\u0E1A\u0E2A\u0E38\u0E17\u0E18\u0E34\u0E07\u0E32\u0E19\u0E0B\u0E31\u0E01": 0, "\u0E23\u0E31\u0E1A\u0E2A\u0E38\u0E17\u0E18\u0E34\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32": 0, "\u0E40\u0E07\u0E34\u0E19\u0E2A\u0E14\u0E2A\u0E38\u0E17\u0E18\u0E34": 0, "\u0E40\u0E07\u0E34\u0E19\u0E2A\u0E14\u0E02\u0E32\u0E22\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E39\u0E49": 0, "\u0E42\u0E2D\u0E19\u0E2A\u0E38\u0E17\u0E18\u0E34": 0, "\u0E40\u0E07\u0E34\u0E19\u0E23\u0E31\u0E1A\u0E2A\u0E38\u0E17\u0E18\u0E34\u0E23\u0E27\u0E21": 0, "\u0E04\u0E48\u0E32\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E15\u0E48\u0E2D\u0E15\u0E30\u0E01\u0E23\u0E49\u0E32": 0, "\u0E08\u0E33\u0E19\u0E27\u0E19\u0E15\u0E30\u0E01\u0E23\u0E49\u0E32": 0 };
            r[p.source === "\u0E07\u0E32\u0E19\u0E0B\u0E31\u0E01" ? "\u0E23\u0E31\u0E1A\u0E2A\u0E38\u0E17\u0E18\u0E34\u0E07\u0E32\u0E19\u0E0B\u0E31\u0E01" : "\u0E23\u0E31\u0E1A\u0E2A\u0E38\u0E17\u0E18\u0E34\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32"] += n(p.amount);
            if (p.method === "cash") r["\u0E40\u0E07\u0E34\u0E19\u0E2A\u0E14\u0E2A\u0E38\u0E17\u0E18\u0E34"] += n(p.amount);
            if (p.source === "\u0E02\u0E32\u0E22\u0E2B\u0E22\u0E2D\u0E14\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E39\u0E49") r["\u0E40\u0E07\u0E34\u0E19\u0E2A\u0E14\u0E02\u0E32\u0E22\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E39\u0E49"] += n(p.amount);
            if (p.method === "qr") r["\u0E42\u0E2D\u0E19\u0E2A\u0E38\u0E17\u0E18\u0E34"] += n(p.amount);
            r["\u0E40\u0E07\u0E34\u0E19\u0E23\u0E31\u0E1A\u0E2A\u0E38\u0E17\u0E18\u0E34\u0E23\u0E27\u0E21"] += n(p.amount);
            r["\u0E04\u0E48\u0E32\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E15\u0E48\u0E2D\u0E15\u0E30\u0E01\u0E23\u0E49\u0E32"] += n(p.basketServiceFee);
            days.set(d, r);
          }
          for (const q of queues.filter((q2) => within(q2.createdAt) && allowed(q2) && q2.status !== "CANCELLED")) {
            const d = day(q.createdAt), r = days.get(d) || { "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48": d, "\u0E23\u0E31\u0E1A\u0E2A\u0E38\u0E17\u0E18\u0E34\u0E07\u0E32\u0E19\u0E0B\u0E31\u0E01": 0, "\u0E23\u0E31\u0E1A\u0E2A\u0E38\u0E17\u0E18\u0E34\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32": 0, "\u0E40\u0E07\u0E34\u0E19\u0E2A\u0E14\u0E2A\u0E38\u0E17\u0E18\u0E34": 0, "\u0E40\u0E07\u0E34\u0E19\u0E2A\u0E14\u0E02\u0E32\u0E22\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E39\u0E49": 0, "\u0E42\u0E2D\u0E19\u0E2A\u0E38\u0E17\u0E18\u0E34": 0, "\u0E40\u0E07\u0E34\u0E19\u0E23\u0E31\u0E1A\u0E2A\u0E38\u0E17\u0E18\u0E34\u0E23\u0E27\u0E21": 0, "\u0E04\u0E48\u0E32\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E15\u0E48\u0E2D\u0E15\u0E30\u0E01\u0E23\u0E49\u0E32": 0, "\u0E08\u0E33\u0E19\u0E27\u0E19\u0E15\u0E30\u0E01\u0E23\u0E49\u0E32": 0 };
            r["\u0E08\u0E33\u0E19\u0E27\u0E19\u0E15\u0E30\u0E01\u0E23\u0E49\u0E32"] += BasketFees.count(q);
            days.set(d, r);
          }
          rows = [...days.values()].sort((a, b) => a["\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48"].localeCompare(b["\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48"]));
        }
        note += " \xB7 \u0E02\u0E32\u0E22\u0E2B\u0E22\u0E2D\u0E14\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E39\u0E49\u0E25\u0E07\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E22\u0E2D\u0E14\u0E15\u0E2D\u0E19\u0E40\u0E15\u0E34\u0E21 \u0E23\u0E27\u0E21\u0E43\u0E19\u0E23\u0E32\u0E22\u0E44\u0E14\u0E49\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E41\u0E25\u0E49\u0E27 \u0E01\u0E32\u0E23\u0E40\u0E01\u0E47\u0E1A\u0E40\u0E07\u0E34\u0E19\u0E2D\u0E2D\u0E01\u0E08\u0E32\u0E01\u0E15\u0E39\u0E49\u0E44\u0E21\u0E48\u0E40\u0E1B\u0E47\u0E19\u0E23\u0E32\u0E22\u0E44\u0E14\u0E49\u0E0B\u0E49\u0E33";
      } else if (kind === "stock") {
        rows = Object.values(state.settings?.products || {}).map((p) => ({ "\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32": p.name, "\u0E23\u0E2B\u0E31\u0E2A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32": p.sku, "\u0E1A\u0E32\u0E23\u0E4C\u0E42\u0E04\u0E49\u0E14\u0E0A\u0E34\u0E49\u0E19": p.barcode || "", "\u0E1A\u0E32\u0E23\u0E4C\u0E42\u0E04\u0E49\u0E14\u0E41\u0E1E\u0E47\u0E01": p.packBarcode || "", "\u0E0A\u0E34\u0E49\u0E19\u0E15\u0E48\u0E2D\u0E41\u0E1E\u0E47\u0E01": p.packSize || 1, "\u0E04\u0E07\u0E40\u0E2B\u0E25\u0E37\u0E2D\u0E2B\u0E19\u0E49\u0E32\u0E23\u0E49\u0E32\u0E19": n(p.stockOnHand), "\u0E04\u0E07\u0E40\u0E2B\u0E25\u0E37\u0E2D\u0E43\u0E19\u0E15\u0E39\u0E49": Vending.list(state).flatMap((m) => m.items).filter((i) => i.productId === p.id).reduce((s, i) => s + n(i.stock), 0), "\u0E04\u0E07\u0E40\u0E2B\u0E25\u0E37\u0E2D\u0E17\u0E31\u0E49\u0E07\u0E23\u0E49\u0E32\u0E19": n(p.stockOnHand) + Vending.list(state).flatMap((m) => m.items).filter((i) => i.productId === p.id).reduce((s, i) => s + n(i.stock), 0), "\u0E15\u0E49\u0E19\u0E17\u0E38\u0E19\u0E40\u0E09\u0E25\u0E35\u0E48\u0E22/\u0E0A\u0E34\u0E49\u0E19": n(p.costPrice), "\u0E21\u0E39\u0E25\u0E04\u0E48\u0E32\u0E04\u0E07\u0E40\u0E2B\u0E25\u0E37\u0E2D": n(p.stockOnHand) * n(p.costPrice) + Vending.list(state).flatMap((m) => m.items).filter((i) => i.productId === p.id).reduce((s, i) => s + n(i.stock) * n(i.averageCost), 0), "\u0E23\u0E32\u0E04\u0E32\u0E02\u0E32\u0E22": n(p.price), "\u0E43\u0E01\u0E25\u0E49\u0E2B\u0E21\u0E14": n(p.stockOnHand) <= n(p.lowStockAt) ? "\u0E43\u0E0A\u0E48" : "\u0E44\u0E21\u0E48" }));
        note += " \xB7 \u0E2A\u0E15\u0E4A\u0E2D\u0E01\u0E1B\u0E31\u0E08\u0E08\u0E38\u0E1A\u0E31\u0E19 \u0E13 \u0E40\u0E27\u0E25\u0E32\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E23\u0E32\u0E22\u0E07\u0E32\u0E19 \u0E44\u0E21\u0E48\u0E43\u0E0A\u0E48\u0E2A\u0E15\u0E4A\u0E2D\u0E01\u0E22\u0E49\u0E2D\u0E19\u0E2B\u0E25\u0E31\u0E07";
      } else if (kind === "movements") rows = (state.inventoryMovements || []).filter((m) => within(m.createdAt)).map((m) => ({ "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48": day(m.createdAt), "\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32": state.settings?.products?.[m.productId]?.name || m.productId, "\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17": m.type, "\u0E01\u0E48\u0E2D\u0E19": n(m.qtyBefore), "\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E41\u0E1B\u0E25\u0E07": n(m.delta), "\u0E2B\u0E25\u0E31\u0E07": n(m.qtyAfter), "\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23": m.documentNo || m.sourceId || "", "\u0E40\u0E2B\u0E15\u0E38\u0E1C\u0E25": m.note || "" }));
      else if (kind === "purchases") rows = (state.purchases || []).filter((p) => within(p.createdAt)).map((p) => ({ "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48": day(p.createdAt), "\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23": p.purchaseNo, "\u0E1C\u0E39\u0E49\u0E08\u0E33\u0E2B\u0E19\u0E48\u0E32\u0E22": p.supplierSnapshot?.name || "", "\u0E22\u0E2D\u0E14\u0E0B\u0E37\u0E49\u0E2D": n(p.total), "\u0E08\u0E48\u0E32\u0E22\u0E41\u0E25\u0E49\u0E27": n(p.paidAmount), "\u0E40\u0E04\u0E23\u0E14\u0E34\u0E15\u0E04\u0E37\u0E19\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32": n(p.supplierCreditTotal), "\u0E40\u0E07\u0E34\u0E19\u0E23\u0E2D\u0E23\u0E31\u0E1A\u0E04\u0E37\u0E19\u0E08\u0E32\u0E01\u0E1C\u0E39\u0E49\u0E08\u0E33\u0E2B\u0E19\u0E48\u0E32\u0E22": n(p.refundReceivable), "\u0E04\u0E49\u0E32\u0E07\u0E0A\u0E33\u0E23\u0E30": n(p.balance), "\u0E04\u0E23\u0E1A\u0E01\u0E33\u0E2B\u0E19\u0E14": p.dueDate || "" }));
      else if (kind === "shifts") rows = (state.shifts || []).filter((s) => within(s.openedAt) && allowed(s)).map((s) => ({ "\u0E27\u0E31\u0E19\u0E40\u0E1B\u0E34\u0E14\u0E01\u0E30": day(s.openedAt), "\u0E40\u0E1B\u0E34\u0E14\u0E01\u0E30": s.openedAt, "\u0E1B\u0E34\u0E14\u0E01\u0E30": s.closedAt || "", "\u0E1E\u0E19\u0E31\u0E01\u0E07\u0E32\u0E19": who(s.employeeId), "\u0E2A\u0E16\u0E32\u0E19\u0E30": s.status, "\u0E08\u0E33\u0E19\u0E27\u0E19\u0E15\u0E30\u0E01\u0E23\u0E49\u0E32\u0E02\u0E2D\u0E07\u0E01\u0E30": s.basketCount ?? BasketFees.forShift(state, s).basketCount, "\u0E04\u0E48\u0E32\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E15\u0E48\u0E2D\u0E15\u0E30\u0E01\u0E23\u0E49\u0E32": s.basketServiceFee ?? BasketFees.forShift(state, s).basketServiceFee, "\u0E40\u0E07\u0E34\u0E19\u0E15\u0E31\u0E49\u0E07\u0E15\u0E49\u0E19": n(s.openingFloat), "\u0E40\u0E07\u0E34\u0E19\u0E17\u0E35\u0E48\u0E04\u0E27\u0E23\u0E21\u0E35": s.expectedCash ?? null, "\u0E19\u0E31\u0E1A\u0E08\u0E23\u0E34\u0E07": s.countedCash ?? null, "\u0E02\u0E32\u0E14/\u0E40\u0E01\u0E34\u0E19": s.variance ?? null, "\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07": s.deviceId || "" }));
      else if (kind === "customers") {
        const map = /* @__PURE__ */ new Map();
        for (const q of queues.filter((q2) => within(q2.createdAt) && q2.status !== "CANCELLED")) {
          const key = q.customerId || q.customerPhone || q.customerName || q.id, r = map.get(key) || { "\u0E25\u0E39\u0E01\u0E04\u0E49\u0E32": q.customerName || "\u0E44\u0E21\u0E48\u0E23\u0E30\u0E1A\u0E38\u0E0A\u0E37\u0E48\u0E2D", "\u0E08\u0E33\u0E19\u0E27\u0E19\u0E04\u0E23\u0E31\u0E49\u0E07": 0, "\u0E22\u0E2D\u0E14\u0E15\u0E32\u0E21\u0E1A\u0E34\u0E25": 0, "\u0E43\u0E0A\u0E49\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E25\u0E48\u0E32\u0E2A\u0E38\u0E14": "" };
          r["\u0E08\u0E33\u0E19\u0E27\u0E19\u0E04\u0E23\u0E31\u0E49\u0E07"]++;
          r["\u0E22\u0E2D\u0E14\u0E15\u0E32\u0E21\u0E1A\u0E34\u0E25"] += n(q.pricing?.total) + (q.extras || []).reduce((s, e) => s + n(e.amount), 0);
          r["\u0E43\u0E0A\u0E49\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E25\u0E48\u0E32\u0E2A\u0E38\u0E14"] = [r["\u0E43\u0E0A\u0E49\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E25\u0E48\u0E32\u0E2A\u0E38\u0E14"], day(q.createdAt)].sort().at(-1);
          map.set(key, r);
        }
        rows = [...map.values()].sort((a, b) => b["\u0E08\u0E33\u0E19\u0E27\u0E19\u0E04\u0E23\u0E31\u0E49\u0E07"] - a["\u0E08\u0E33\u0E19\u0E27\u0E19\u0E04\u0E23\u0E31\u0E49\u0E07"]);
      } else if (kind === "audit") rows = (state.auditLogs || []).filter((a) => a.action !== "WEB_REPORT" && within(a.createdAt)).map((a) => ({ "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48": day(a.createdAt), "\u0E40\u0E27\u0E25\u0E32": a.createdAt, "\u0E01\u0E32\u0E23\u0E17\u0E33\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23": a.action, "\u0E2D\u0E49\u0E32\u0E07\u0E2D\u0E34\u0E07": a.queueId || a.entityId || "", "\u0E1C\u0E39\u0E49\u0E17\u0E33": a.actor || a.employeeId || "", "\u0E40\u0E2B\u0E15\u0E38\u0E1C\u0E25/\u0E1C\u0E25": a.details?.message || a.details?.reason || "" }));
      else throw Error("\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17\u0E23\u0E32\u0E22\u0E07\u0E32\u0E19");
      const hash = Model.hash(rows);
      if (input.expectedHash && input.expectedHash !== hash) throw Error("\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E23\u0E32\u0E22\u0E07\u0E32\u0E19\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E2A\u0E48\u0E07\u0E2D\u0E2D\u0E01 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E23\u0E32\u0E22\u0E07\u0E32\u0E19\u0E43\u0E2B\u0E21\u0E48");
      const offset = n(input.offset);
      if (!Number.isSafeInteger(offset) || offset < 0 || offset > rows.length) throw Error("\u0E2B\u0E19\u0E49\u0E32\u0E23\u0E32\u0E22\u0E07\u0E32\u0E19\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
      const page = rows.slice(offset, offset + 100);
      return { kind, from, to, generatedAt: now, hash, offset, totalRows: rows.length, rows: page, hasMore: offset + page.length < rows.length, note };
    }
    module2.exports = { build };
  }
});

// migration/pos/server/purchase-workflow.cjs
var require_purchase_workflow = __commonJS({
  "migration/pos/server/purchase-workflow.cjs"(exports2, module2) {
    "use strict";
    var Core = require_inventory_bridge_core();
    var Reports = require_reports();
    var clean = (v) => String(v ?? "").trim().slice(0, 240);
    function num(v, label, integer = false) {
      const n = Number(v);
      if (v == null || v === "" || !Number.isFinite(n) || n < 0 || n > 99999999 || integer && (!Number.isSafeInteger(n) || n > 9999999)) throw Error(label + "\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
      return n;
    }
    function apply(state, command, now = (/* @__PURE__ */ new Date()).toISOString()) {
      const action = command.payload?.workflow;
      if (!action) return Core.apply(state, command, now);
      const previous = state.meta?.inventoryBridge?.results?.[command.id];
      if (previous) return { state, result: previous, duplicate: true };
      const next = structuredClone(state), p = command.payload;
      next.purchaseOrders ||= [];
      try {
        if (!["order.create", "order.receive", "order.cancel", "report.prepare", "purchase.pay", "purchase.return"].includes(action)) throw Error("\u0E44\u0E21\u0E48\u0E23\u0E2D\u0E07\u0E23\u0E31\u0E1A\u0E02\u0E31\u0E49\u0E19\u0E15\u0E2D\u0E19\u0E08\u0E31\u0E14\u0E0B\u0E37\u0E49\u0E2D");
        let message;
        if (action === "report.prepare") {
          next.reportPage = { ...Reports.build(state, p, now), requestId: command.id, id: command.id };
          next.reportPages = [...(state.reportPages || []).filter((x) => new Date(now) - new Date(x.generatedAt) < 6e5), next.reportPage].slice(-10);
          message = "\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E23\u0E32\u0E22\u0E07\u0E32\u0E19\u0E41\u0E25\u0E49\u0E27";
        } else if (action === "purchase.pay" || action === "purchase.return") {
          const doc = next.purchases?.find((d) => d.id === p.purchaseId);
          if (!doc) throw Error("\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23\u0E23\u0E31\u0E1A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32");
          if (Number(p.expectedRevision) !== Number(doc.revision || 0)) throw Error("\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E41\u0E25\u0E49\u0E27 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E42\u0E2B\u0E25\u0E14\u0E43\u0E2B\u0E21\u0E48");
          if (action === "purchase.pay") {
            const amount = num(p.amount, "\u0E22\u0E2D\u0E14\u0E08\u0E48\u0E32\u0E22");
            if (!amount || amount > num(doc.balance, "\u0E04\u0E49\u0E32\u0E07\u0E0A\u0E33\u0E23\u0E30")) throw Error("\u0E22\u0E2D\u0E14\u0E08\u0E48\u0E32\u0E22\u0E40\u0E01\u0E34\u0E19\u0E22\u0E2D\u0E14\u0E04\u0E49\u0E32\u0E07 \u0E2B\u0E23\u0E37\u0E2D\u0E40\u0E1B\u0E47\u0E19\u0E28\u0E39\u0E19\u0E22\u0E4C");
            if (!["cash", "qr"].includes(p.paymentMethod)) throw Error("\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E0A\u0E48\u0E2D\u0E07\u0E17\u0E32\u0E07\u0E0A\u0E33\u0E23\u0E30");
            doc.payments ||= [];
            doc.payments.push({ id: "web_payment_" + command.id, amount, method: p.paymentMethod, paidAt: now, createdAt: now, note: clean(p.notes), shiftId: null, employeeId: null });
            doc.paidAmount = num(doc.paidAmount || 0, "\u0E08\u0E48\u0E32\u0E22\u0E41\u0E25\u0E49\u0E27") + amount;
            message = "\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E0A\u0E33\u0E23\u0E30\u0E2B\u0E19\u0E35\u0E49\u0E41\u0E25\u0E49\u0E27 (\u0E19\u0E2D\u0E01\u0E25\u0E34\u0E49\u0E19\u0E0A\u0E31\u0E01 POS)";
          } else {
            const product = next.settings?.products?.[p.productId], item = doc.items?.find((i) => i.productId === p.productId);
            if (!product || !item || product.trackStock === false) throw Error("\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E43\u0E19\u0E43\u0E1A\u0E23\u0E31\u0E1A\u0E2B\u0E23\u0E37\u0E2D\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E15\u0E34\u0E14\u0E15\u0E32\u0E21\u0E2A\u0E15\u0E4A\u0E2D\u0E01");
            const qty = num(p.quantity, "\u0E08\u0E33\u0E19\u0E27\u0E19\u0E04\u0E37\u0E19", true);
            next.supplierReturns ||= [];
            const returned = next.supplierReturns.filter((r) => r.purchaseId === doc.id && r.productId === p.productId).reduce((sum, r) => sum + r.quantity, 0);
            if (!qty || qty > item.quantity - returned || qty > num(product.stockOnHand, "\u0E2A\u0E15\u0E4A\u0E2D\u0E01")) throw Error("\u0E08\u0E33\u0E19\u0E27\u0E19\u0E04\u0E37\u0E19\u0E40\u0E01\u0E34\u0E19\u0E22\u0E2D\u0E14\u0E23\u0E31\u0E1A\u0E17\u0E35\u0E48\u0E22\u0E31\u0E07\u0E04\u0E37\u0E19\u0E44\u0E14\u0E49 \u0E2B\u0E23\u0E37\u0E2D\u0E40\u0E01\u0E34\u0E19\u0E2A\u0E15\u0E4A\u0E2D\u0E01");
            if (!clean(p.notes)) throw Error("\u0E23\u0E30\u0E1A\u0E38\u0E40\u0E2B\u0E15\u0E38\u0E1C\u0E25\u0E04\u0E37\u0E19\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32");
            const credit = num(p.creditAmount, "\u0E22\u0E2D\u0E14\u0E25\u0E14\u0E2B\u0E19\u0E35\u0E49");
            if (credit > num(item.effectiveUnitCost ?? item.unitCost, "\u0E15\u0E49\u0E19\u0E17\u0E38\u0E19") * qty + 0.01) throw Error("\u0E22\u0E2D\u0E14\u0E25\u0E14\u0E2B\u0E19\u0E35\u0E49\u0E40\u0E01\u0E34\u0E19\u0E21\u0E39\u0E25\u0E04\u0E48\u0E32\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E17\u0E35\u0E48\u0E04\u0E37\u0E19");
            const before = product.stockOnHand;
            product.stockOnHand -= qty;
            product.updatedAt = now;
            const record = { id: "supplier_return_" + command.id, purchaseId: doc.id, productId: p.productId, quantity: qty, creditAmount: credit, note: clean(p.notes), createdAt: now, deviceId: "SERVERJJ" };
            next.supplierReturns.unshift(record);
            next.inventoryMovements ||= [];
            next.inventoryMovements.unshift({ id: "supplier_return_move_" + command.id, productId: p.productId, delta: -qty, qtyBefore: before, qtyAfter: product.stockOnHand, unitCost: product.costPrice, type: "SUPPLIER_RETURN", documentNo: doc.purchaseNo, note: record.note, createdAt: now, actor: "\u0E40\u0E08\u0E49\u0E32\u0E02\u0E2D\u0E07\u0E23\u0E49\u0E32\u0E19\u0E1C\u0E48\u0E32\u0E19\u0E40\u0E27\u0E47\u0E1A" });
            doc.supplierCreditTotal = num(doc.supplierCreditTotal || 0, "\u0E25\u0E14\u0E2B\u0E19\u0E35\u0E49") + credit;
            message = "\u0E04\u0E37\u0E19\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E41\u0E25\u0E30\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E25\u0E14\u0E2B\u0E19\u0E35\u0E49\u0E41\u0E25\u0E49\u0E27";
          }
          doc.balance = Math.max(0, Math.round((doc.total - doc.paidAmount - (doc.supplierCreditTotal || 0)) * 100) / 100);
          doc.refundReceivable = Math.max(0, doc.paidAmount + (doc.supplierCreditTotal || 0) - doc.total);
          doc.paymentStatus = doc.balance === 0 ? "PAID" : "PARTIAL";
          doc.revision = Number(doc.revision || 0) + 1;
          doc.updatedAt = now;
        } else if (action === "order.create") {
          const supplier = next.suppliers?.find((s) => s.id === p.supplierId && s.active !== false);
          if (!supplier) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E1C\u0E39\u0E49\u0E08\u0E33\u0E2B\u0E19\u0E48\u0E32\u0E22");
          if (!Array.isArray(p.items) || !p.items.length || p.items.length > 100) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E23\u0E30\u0E1A\u0E38\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E2A\u0E31\u0E48\u0E07\u0E0B\u0E37\u0E49\u0E2D");
          if (new Set(p.items.map((i) => i.productId)).size !== p.items.length) throw Error("\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E0B\u0E49\u0E33");
          const items = p.items.map((i) => {
            const product = next.settings?.products?.[i.productId];
            if (!product || product.enabled === false) throw Error("\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19");
            const quantity = num(i.quantity, "\u0E08\u0E33\u0E19\u0E27\u0E19", true), unitCost = num(i.unitCost, "\u0E15\u0E49\u0E19\u0E17\u0E38\u0E19");
            if (!quantity) throw Error("\u0E08\u0E33\u0E19\u0E27\u0E19\u0E15\u0E49\u0E2D\u0E07\u0E21\u0E32\u0E01\u0E01\u0E27\u0E48\u0E32 0");
            return { productId: product.id, name: product.name, sku: product.sku, quantity, received: 0, unitCost };
          });
          const total = items.reduce((sum, i) => sum + i.quantity * i.unitCost, 0);
          num(total, "\u0E22\u0E2D\u0E14\u0E2A\u0E31\u0E48\u0E07\u0E0B\u0E37\u0E49\u0E2D");
          const order = { id: "order_" + command.id, orderNo: "PO-" + now.slice(0, 10).replaceAll("-", "") + "-" + command.id.slice(0, 8).toUpperCase(), supplierId: supplier.id, supplierName: supplier.name, items, total, status: "OPEN", revision: 1, notes: clean(p.notes), expectedDate: clean(p.expectedDate), createdAt: now, updatedAt: now, deviceId: "SERVERJJ" };
          next.purchaseOrders.unshift(order);
          message = "\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E43\u0E1A\u0E2A\u0E31\u0E48\u0E07\u0E0B\u0E37\u0E49\u0E2D " + order.orderNo + " \u0E41\u0E25\u0E49\u0E27 (\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E2A\u0E15\u0E4A\u0E2D\u0E01)";
        } else {
          const order = next.purchaseOrders.find((o) => o.id === p.orderId);
          if (!order) throw Error("\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E43\u0E1A\u0E2A\u0E31\u0E48\u0E07\u0E0B\u0E37\u0E49\u0E2D");
          if (order.revision !== Number(p.expectedOrderRevision)) throw Error("\u0E43\u0E1A\u0E2A\u0E31\u0E48\u0E07\u0E0B\u0E37\u0E49\u0E2D\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E41\u0E25\u0E49\u0E27 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E42\u0E2B\u0E25\u0E14\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E25\u0E48\u0E32\u0E2A\u0E38\u0E14");
          if (!["OPEN", "PARTIAL"].includes(order.status)) throw Error("\u0E43\u0E1A\u0E2A\u0E31\u0E48\u0E07\u0E0B\u0E37\u0E49\u0E2D\u0E19\u0E35\u0E49\u0E1B\u0E34\u0E14\u0E41\u0E25\u0E49\u0E27");
          if (action === "order.cancel") {
            if (!clean(p.reason)) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E23\u0E30\u0E1A\u0E38\u0E40\u0E2B\u0E15\u0E38\u0E1C\u0E25\u0E1B\u0E34\u0E14\u0E22\u0E2D\u0E14\u0E04\u0E49\u0E32\u0E07");
            order.status = "CANCELLED";
            order.closeReason = clean(p.reason);
            message = "\u0E1B\u0E34\u0E14\u0E22\u0E2D\u0E14\u0E04\u0E49\u0E32\u0E07\u0E43\u0E1A\u0E2A\u0E31\u0E48\u0E07\u0E0B\u0E37\u0E49\u0E2D\u0E41\u0E25\u0E49\u0E27";
          } else {
            if (!Array.isArray(p.items) || !p.items.length) throw Error("\u0E23\u0E30\u0E1A\u0E38\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E17\u0E35\u0E48\u0E23\u0E31\u0E1A\u0E08\u0E23\u0E34\u0E07");
            const seen = /* @__PURE__ */ new Set();
            for (const i of p.items) {
              if (seen.has(i.productId)) throw Error("\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E0B\u0E49\u0E33");
              seen.add(i.productId);
              const line = order.items.find((l) => l.productId === i.productId);
              const quantity = num(i.quantity, "\u0E08\u0E33\u0E19\u0E27\u0E19\u0E23\u0E31\u0E1A", true);
              if (!line || !quantity || quantity > line.quantity - line.received) throw Error("\u0E08\u0E33\u0E19\u0E27\u0E19\u0E23\u0E31\u0E1A\u0E40\u0E01\u0E34\u0E19\u0E22\u0E2D\u0E14\u0E04\u0E49\u0E32\u0E07\u0E2B\u0E23\u0E37\u0E2D\u0E44\u0E21\u0E48\u0E21\u0E35\u0E43\u0E19\u0E43\u0E1A\u0E2A\u0E31\u0E48\u0E07\u0E0B\u0E37\u0E49\u0E2D");
            }
            const receipt = Core.apply(next, { ...command, payload: { ...p, workflow: void 0, supplierId: order.supplierId } }, now);
            if (receipt.result.status !== "applied") return receipt;
            const updated = receipt.state.purchaseOrders.find((o) => o.id === order.id);
            for (const i of p.items) updated.items.find((l) => l.productId === i.productId).received += Number(i.quantity);
            updated.status = updated.items.every((l) => l.received === l.quantity) ? "RECEIVED" : "PARTIAL";
            updated.revision++;
            updated.updatedAt = now;
            const doc = receipt.state.purchases.find((r) => r.id === "web_purchase_" + command.id);
            doc.orderId = order.id;
            doc.orderNo = order.orderNo;
            doc.receivingType = "ORDER";
            return receipt;
          }
          order.revision++;
          order.updatedAt = now;
        }
        const result = { id: command.id, status: "applied", message, completedAt: now };
        next.meta ||= {};
        next.meta.inventoryBridge ||= {};
        next.meta.inventoryBridge.results ||= {};
        next.meta.inventoryBridge.results[command.id] = result;
        next.auditLogs ||= [];
        next.auditLogs.push({ id: "web_audit_" + command.id, action: action === "report.prepare" ? "WEB_REPORT" : "WEB_PURCHASING", createdAt: now, details: { action, message } });
        return { state: next, result };
      } catch (e) {
        return { state, result: { id: command.id, status: "rejected", message: e.message, completedAt: now } };
      }
    }
    module2.exports = { apply };
  }
});

// migration/pos/renderer/employee-auth.js
var require_employee_auth = __commonJS({
  "migration/pos/renderer/employee-auth.js"(exports2, module2) {
    "use strict";
    (function(host, factory) {
      const api = factory();
      host.EmployeeAuth = api;
      if (typeof module2 === "object" && module2.exports) module2.exports = api;
    })(globalThis, function() {
      const hex = (bytes2) => Array.from(bytes2, (n) => n.toString(16).padStart(2, "0")).join("");
      const bytes = (hex2) => Uint8Array.from(hex2.match(/../g) || [], (n) => parseInt(n, 16));
      const valid = (v) => v?.algorithm === "PBKDF2-SHA256" && v.iterations === 21e4 && /^[a-f0-9]{32}$/.test(v.salt) && /^[a-f0-9]{64}$/.test(v.hash);
      async function derive(password, salt) {
        const key = await globalThis.crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
        return hex(new Uint8Array(await globalThis.crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: bytes(salt), iterations: 21e4 }, key, 256)));
      }
      async function hashPassword(password) {
        if (typeof password !== "string" || password.length < 6 || password.length > 128) throw Error("\u0E23\u0E2B\u0E31\u0E2A\u0E1C\u0E48\u0E32\u0E19\u0E15\u0E49\u0E2D\u0E07\u0E22\u0E32\u0E27 6\u2013128 \u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23");
        const salt = hex(globalThis.crypto.getRandomValues(new Uint8Array(16)));
        return { algorithm: "PBKDF2-SHA256", iterations: 21e4, salt, hash: await derive(password, salt) };
      }
      async function verify(employee, password) {
        if (!employee || employee.active === false || typeof password !== "string") return false;
        if (!employee.passwordVerifier) return !!employee.pin && employee.pin === password;
        if (!valid(employee.passwordVerifier)) return false;
        const actual = await derive(password, employee.passwordVerifier.salt);
        let diff = 0;
        for (let i = 0; i < actual.length; i++) diff |= actual.charCodeAt(i) ^ employee.passwordVerifier.hash.charCodeAt(i);
        return diff === 0;
      }
      return { hashPassword, verify, valid };
    });
  }
});

// migration/pos/server/employee-workflow.cjs
var require_employee_workflow = __commonJS({
  "migration/pos/server/employee-workflow.cjs"(exports2, module2) {
    "use strict";
    var Auth = require_employee_auth();
    module2.exports = function(state, command, now) {
      const p = command.payload, old = state.meta?.inventoryBridge?.results?.[command.id];
      if (old) return { state, result: old, duplicate: true };
      try {
        if (!/^[A-Za-z0-9_-]{1,120}$/.test(p.employeeId || "") || ["constructor", "__proto__", "prototype"].includes(p.employeeId)) throw Error("\u0E23\u0E2B\u0E31\u0E2A\u0E1E\u0E19\u0E31\u0E01\u0E07\u0E32\u0E19\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
        if (!String(p.name || "").trim() || !["manager", "employee"].includes(p.role) || typeof p.active !== "boolean") throw Error("\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E1E\u0E19\u0E31\u0E01\u0E07\u0E32\u0E19\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
        if (p.username && !/^[a-z0-9][a-z0-9._-]{2,31}$/.test(p.username)) throw Error("\u0E0A\u0E37\u0E48\u0E2D\u0E1C\u0E39\u0E49\u0E43\u0E0A\u0E49\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
        if (p.passwordVerifier && !Auth.valid(p.passwordVerifier)) throw Error("\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E23\u0E2B\u0E31\u0E2A\u0E1C\u0E48\u0E32\u0E19\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
        const next = structuredClone(state);
        next.employees ||= [];
        let employee = next.employees.find((e) => e.id === p.employeeId);
        if (p.username && next.employees.some((e) => e.id !== p.employeeId && e.username === p.username)) throw Error("\u0E0A\u0E37\u0E48\u0E2D\u0E1C\u0E39\u0E49\u0E43\u0E0A\u0E49\u0E0B\u0E49\u0E33\u0E01\u0E31\u0E1A\u0E1E\u0E19\u0E31\u0E01\u0E07\u0E32\u0E19\u0E2D\u0E37\u0E48\u0E19");
        if (!employee) {
          employee = { id: p.employeeId, createdAt: now };
          next.employees.push(employee);
        }
        if (!p.sourceUpdatedAt || !employee.staffUpdatedAt || new Date(p.sourceUpdatedAt) > new Date(employee.staffUpdatedAt)) Object.assign(employee, { name: String(p.name).trim().slice(0, 120), username: p.username || employee.username || "", role: p.role, active: p.active, updatedAt: now, ...p.sourceUpdatedAt ? { staffUpdatedAt: p.sourceUpdatedAt } : {}, ...p.passwordVerifier ? { passwordVerifier: p.passwordVerifier, pin: "" } : {} });
        const result = { id: command.id, status: "applied", message: "\u0E2D\u0E31\u0E1B\u0E40\u0E14\u0E15\u0E1E\u0E19\u0E31\u0E01\u0E07\u0E32\u0E19\u0E41\u0E25\u0E30\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C\u0E43\u0E19 POS \u0E41\u0E25\u0E49\u0E27", completedAt: now };
        next.meta ||= {};
        next.meta.inventoryBridge ||= {};
        next.meta.inventoryBridge.results ||= {};
        next.meta.inventoryBridge.results[command.id] = result;
        next.auditLogs ||= [];
        next.auditLogs.push({ id: "staff_" + command.id, createdAt: now, action: "STAFF_UPDATE", entityId: employee.id, details: { name: employee.name, role: employee.role, active: employee.active } });
        return { state: next, result };
      } catch (e) {
        return { state, result: { id: command.id, status: "rejected", message: e.message, completedAt: now } };
      }
    };
  }
});

// migration/pos/server/office-documents.cjs
var require_office_documents = __commonJS({
  "migration/pos/server/office-documents.cjs"(exports2, module2) {
    "use strict";
    var Legacy = require_purchase_workflow();
    var Core = require_inventory_bridge_core();
    var round = (n) => Math.round((n + Number.EPSILON) * 100) / 100;
    function number(v) {
      const n = Number(v ?? 0);
      if (!Number.isFinite(n) || n < 0 || n > 99999999) throw Error("\u0E22\u0E2D\u0E14\u0E40\u0E07\u0E34\u0E19\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
      return n;
    }
    function totals(p) {
      const subtotal = round(p.items.reduce((n, i) => n + number(i.quantity) * number(i.unitCost), 0)), discount = number(p.discount), shipping = number(p.shipping), taxMode = p.taxMode || "none", taxRate = number(p.taxRate);
      if (discount > subtotal || taxRate > 100 || !["none", "inclusive", "exclusive"].includes(taxMode)) throw Error("\u0E2A\u0E48\u0E27\u0E19\u0E25\u0E14\u0E2B\u0E23\u0E37\u0E2D VAT \u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
      const amount = round(subtotal - discount + shipping), taxAmount = taxMode === "inclusive" ? round(amount - amount / (1 + taxRate / 100)) : taxMode === "exclusive" ? round(amount * taxRate / 100) : 0;
      return { subtotal, discount, shipping, taxMode, taxRate: taxMode === "none" ? 0 : taxRate, taxAmount, taxableAmount: taxMode === "inclusive" ? round(amount - taxAmount) : amount, total: taxMode === "exclusive" ? round(amount + taxAmount) : amount };
    }
    function stamp(doc, p, state, t) {
      Object.assign(doc, t, { shopSnapshot: structuredClone(state.officeSettings || { name: "\u0E0A\u0E38\u0E15\u0E34\u0E21\u0E32 FRESH LAUNDRY" }), notes: String(p.notes || "").slice(0, 1e3) });
      const supplier = state.suppliers?.find((s) => s.id === doc.supplierId);
      if (supplier) doc.supplierSnapshot = { code: supplier.code, name: supplier.name, address: supplier.address || "", phone: supplier.phone || "", taxId: supplier.taxId || "" };
      doc.items.forEach((i) => {
        const line = p.items.find((x) => x.productId === i.productId);
        if (line?.packCount && line?.piecesPerPack && Number(line.packCount) * Number(line.piecesPerPack) === i.quantity) Object.assign(i, { packCount: Number(line.packCount), piecesPerPack: Number(line.piecesPerPack), packCost: number(line.packCost) });
      });
    }
    function apply(state, command, now = (/* @__PURE__ */ new Date()).toISOString()) {
      const p = command.payload || {}, action = p.workflow;
      if (action === "employee.save") return require_employee_workflow()(state, command, now);
      if (action?.startsWith("vending.")) return require_vending_core().apply(state, command, now);
      if (!["office.settings", "order.edit", "receipt.edit", "receipt.void", "order.create", "order.receive", void 0].includes(action)) {
        if (p.purchaseId && state.purchases?.find((d) => d.id === p.purchaseId)?.status === "CANCELLED") return { state, result: { id: command.id, status: "rejected", message: "\u0E43\u0E1A\u0E23\u0E31\u0E1A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E41\u0E25\u0E49\u0E27", completedAt: now } };
        return Legacy.apply(state, command, now);
      }
      const old = state.meta?.inventoryBridge?.results?.[command.id];
      if (old) return { state, result: old, duplicate: true };
      let next = structuredClone(state), message;
      try {
        if (action === "office.settings") {
          if (Number(p.expectedRevision) !== Number(state.officeSettings?.revision || 0)) throw Error("\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E23\u0E49\u0E32\u0E19\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E41\u0E25\u0E49\u0E27 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E42\u0E2B\u0E25\u0E14\u0E43\u0E2B\u0E21\u0E48");
          const s = p.settings || {};
          if (!String(s.name || "").trim()) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E01\u0E23\u0E2D\u0E01\u0E0A\u0E37\u0E48\u0E2D\u0E23\u0E49\u0E32\u0E19");
          if (s.logoUrl && !/^https:\/\//.test(s.logoUrl)) throw Error("\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E42\u0E25\u0E42\u0E01\u0E49\u0E15\u0E49\u0E2D\u0E07\u0E40\u0E1B\u0E47\u0E19 HTTPS");
          totals({ items: [], taxMode: s.taxMode, taxRate: s.taxRate });
          next.officeSettings = Object.fromEntries(["name", "address", "phone", "taxId", "branch", "logoUrl", "footer"].map((k) => [k, String(s[k] || "").trim().slice(0, 1e3)]));
          Object.assign(next.officeSettings, { taxMode: s.taxMode || "none", taxRate: number(s.taxRate), revision: Number(state.officeSettings?.revision || 0) + 1 });
          message = "\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E23\u0E49\u0E32\u0E19\u0E41\u0E25\u0E30\u0E01\u0E32\u0E23\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23\u0E41\u0E25\u0E49\u0E27";
        } else if (action === "order.edit") {
          const order = next.purchaseOrders?.find((o) => o.id === p.orderId);
          if (!order || !["OPEN", "PARTIAL"].includes(order.status)) throw Error("\u0E43\u0E1A\u0E2A\u0E31\u0E48\u0E07\u0E0B\u0E37\u0E49\u0E2D\u0E1B\u0E34\u0E14\u0E41\u0E25\u0E49\u0E27\u0E2B\u0E23\u0E37\u0E2D\u0E44\u0E21\u0E48\u0E1E\u0E1A");
          if (order.revision !== Number(p.expectedOrderRevision)) throw Error("\u0E43\u0E1A\u0E2A\u0E31\u0E48\u0E07\u0E0B\u0E37\u0E49\u0E2D\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E41\u0E25\u0E49\u0E27 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E42\u0E2B\u0E25\u0E14\u0E43\u0E2B\u0E21\u0E48");
          const candidate = Legacy.apply(next, { ...command, payload: { ...p, workflow: "order.create" } }, now);
          if (candidate.result.status !== "applied") return candidate;
          const revised = candidate.state.purchaseOrders[0];
          for (const line of order.items.filter((i) => i.received)) {
            const changed = revised.items.find((i) => i.productId === line.productId);
            if (!changed || changed.quantity < line.received || changed.unitCost !== line.unitCost) throw Error("\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E17\u0E35\u0E48\u0E23\u0E31\u0E1A\u0E41\u0E25\u0E49\u0E27\u0E15\u0E49\u0E2D\u0E07\u0E04\u0E07\u0E23\u0E32\u0E04\u0E32\u0E40\u0E14\u0E34\u0E21 \u0E41\u0E25\u0E30\u0E08\u0E33\u0E19\u0E27\u0E19\u0E2A\u0E31\u0E48\u0E07\u0E15\u0E49\u0E2D\u0E07\u0E44\u0E21\u0E48\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32\u0E23\u0E31\u0E1A\u0E2A\u0E30\u0E2A\u0E21");
          }
          if (order.items.some((i) => i.received) && (p.supplierId !== order.supplierId || (p.taxMode || "none") !== (order.taxMode || "none") || number(p.taxRate) !== number(order.taxRate) || number(p.discount) !== number(order.discount) || number(p.shipping) !== number(order.shipping))) throw Error("\u0E43\u0E1A\u0E17\u0E35\u0E48\u0E23\u0E31\u0E1A\u0E1A\u0E32\u0E07\u0E2A\u0E48\u0E27\u0E19\u0E41\u0E25\u0E49\u0E27\u0E43\u0E2B\u0E49\u0E04\u0E07\u0E1C\u0E39\u0E49\u0E08\u0E33\u0E2B\u0E19\u0E48\u0E32\u0E22 VAT \u0E2A\u0E48\u0E27\u0E19\u0E25\u0E14 \u0E41\u0E25\u0E30\u0E04\u0E48\u0E32\u0E2A\u0E48\u0E07\u0E40\u0E14\u0E34\u0E21");
          const before = structuredClone(order);
          revised.items.forEach((i) => i.received = order.items.find((x) => x.productId === i.productId)?.received || 0);
          Object.assign(order, { items: revised.items, total: revised.total, supplierId: revised.supplierId, supplierName: revised.supplierName, expectedDate: revised.expectedDate, revision: order.revision + 1, updatedAt: now });
          stamp(order, p, state, totals(p));
          order.status = order.items.every((i) => i.received === i.quantity) ? "RECEIVED" : order.items.some((i) => i.received) ? "PARTIAL" : "OPEN";
          next.documentHistory ||= [];
          next.documentHistory.push({ id: "history_" + command.id, documentId: order.id, before, createdAt: now, reason: String(p.notes || "\u0E41\u0E01\u0E49\u0E44\u0E02\u0E43\u0E1A\u0E2A\u0E31\u0E48\u0E07\u0E0B\u0E37\u0E49\u0E2D"), deviceId: "SERVERJJ" });
          message = "\u0E41\u0E01\u0E49\u0E44\u0E02\u0E43\u0E1A\u0E2A\u0E31\u0E48\u0E07\u0E0B\u0E37\u0E49\u0E2D\u0E41\u0E25\u0E49\u0E27";
        } else if (action === "receipt.edit" || action === "receipt.void") {
          const doc = next.purchases?.find((d) => d.id === p.purchaseId);
          if (!doc || doc.status === "CANCELLED") throw Error("\u0E43\u0E1A\u0E23\u0E31\u0E1A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E2B\u0E23\u0E37\u0E2D\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E41\u0E25\u0E49\u0E27");
          if (Number(doc.revision || 0) !== Number(p.expectedRevision)) throw Error("\u0E43\u0E1A\u0E23\u0E31\u0E1A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E41\u0E25\u0E49\u0E27 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E42\u0E2B\u0E25\u0E14\u0E43\u0E2B\u0E21\u0E48");
          if (!String(p.reason || p.notes || "").trim()) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E23\u0E30\u0E1A\u0E38\u0E40\u0E2B\u0E15\u0E38\u0E1C\u0E25\u0E41\u0E01\u0E49\u0E44\u0E02\u0E2B\u0E23\u0E37\u0E2D\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01");
          if (next.supplierReturns?.some((r) => r.purchaseId === doc.id)) throw Error("\u0E43\u0E1A\u0E19\u0E35\u0E49\u0E21\u0E35\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E04\u0E37\u0E19\u0E41\u0E25\u0E49\u0E27 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E08\u0E31\u0E14\u0E01\u0E32\u0E23\u0E1C\u0E48\u0E32\u0E19\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E04\u0E37\u0E19\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32");
          const before = structuredClone(doc);
          for (const item of doc.items) {
            const product = next.settings.products[item.productId];
            if (!product || product.trackStock === false || !Number.isFinite(item.previousAverageCost)) throw Error("\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23\u0E40\u0E01\u0E48\u0E32\u0E44\u0E21\u0E48\u0E21\u0E35\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E15\u0E49\u0E19\u0E17\u0E38\u0E19\u0E01\u0E48\u0E2D\u0E19\u0E23\u0E31\u0E1A\u0E04\u0E23\u0E1A \u0E01\u0E23\u0E38\u0E13\u0E32\u0E43\u0E0A\u0E49\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E04\u0E37\u0E19\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32");
            if (product.stockOnHand !== item.stockAfter || Math.abs(product.costPrice - item.newAverageCost) > 1e-6 || next.inventoryMovements?.some((m) => m.productId === item.productId && m.createdAt > doc.createdAt)) throw Error("\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E21\u0E35\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E2B\u0E25\u0E31\u0E07\u0E43\u0E1A\u0E23\u0E31\u0E1A\u0E19\u0E35\u0E49\u0E41\u0E25\u0E49\u0E27 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E43\u0E0A\u0E49\u0E04\u0E37\u0E19\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E41\u0E17\u0E19\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E23\u0E31\u0E01\u0E29\u0E32\u0E15\u0E49\u0E19\u0E17\u0E38\u0E19\u0E22\u0E49\u0E2D\u0E19\u0E2B\u0E25\u0E31\u0E07");
            product.stockOnHand -= item.quantity;
            if (product.stockOnHand < 0) throw Error("\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E04\u0E07\u0E40\u0E2B\u0E25\u0E37\u0E2D\u0E44\u0E21\u0E48\u0E1E\u0E2D\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01");
            product.costPrice = item.previousAverageCost;
            product.updatedAt = now;
            next.inventoryMovements ||= [];
            next.inventoryMovements.push({ id: "receipt_reverse_" + command.id + "_" + item.productId, productId: item.productId, delta: -item.quantity, qtyBefore: item.stockAfter, qtyAfter: product.stockOnHand, type: "RECEIPT_REVERSAL", documentNo: doc.purchaseNo, note: String(p.reason || p.notes), createdAt: now, actor: "\u0E41\u0E01\u0E49\u0E44\u0E02\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23\u0E1C\u0E48\u0E32\u0E19\u0E40\u0E27\u0E47\u0E1A" });
          }
          const order = doc.orderId ? next.purchaseOrders?.find((o) => o.id === doc.orderId) : null;
          if (doc.orderId && !order) throw Error("\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E43\u0E1A\u0E2A\u0E31\u0E48\u0E07\u0E0B\u0E37\u0E49\u0E2D\u0E2D\u0E49\u0E32\u0E07\u0E2D\u0E34\u0E07");
          if (order?.status === "CANCELLED") throw Error("\u0E43\u0E1A\u0E2A\u0E31\u0E48\u0E07\u0E0B\u0E37\u0E49\u0E2D\u0E1B\u0E34\u0E14\u0E41\u0E25\u0E49\u0E27 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E43\u0E0A\u0E49\u0E04\u0E37\u0E19\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32");
          if (order) {
            for (const i of doc.items) order.items.find((x) => x.productId === i.productId).received -= i.quantity;
          }
          if (action === "receipt.void") {
            doc.status = "CANCELLED";
            doc.cancelReason = String(p.reason);
            doc.originalTotal = doc.total;
            doc.total = 0;
            doc.balance = 0;
            doc.refundReceivable = number(doc.paidAmount);
            doc.revision = Number(doc.revision || 0) + 1;
            doc.updatedAt = now;
            message = "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E43\u0E1A\u0E23\u0E31\u0E1A\u0E41\u0E25\u0E30\u0E22\u0E49\u0E2D\u0E19\u0E2A\u0E15\u0E4A\u0E2D\u0E01\u0E41\u0E25\u0E49\u0E27";
          } else {
            if (order && ((p.taxMode || "none") !== (order.taxMode || "none") || number(p.taxRate) !== number(order.taxRate))) throw Error("VAT \u0E15\u0E49\u0E2D\u0E07\u0E15\u0E23\u0E07\u0E43\u0E1A\u0E2A\u0E31\u0E48\u0E07\u0E0B\u0E37\u0E49\u0E2D");
            if (order && p.supplierId !== order.supplierId) throw Error("\u0E1C\u0E39\u0E49\u0E08\u0E33\u0E2B\u0E19\u0E48\u0E32\u0E22\u0E15\u0E49\u0E2D\u0E07\u0E15\u0E23\u0E07\u0E43\u0E1A\u0E2A\u0E31\u0E48\u0E07\u0E0B\u0E37\u0E49\u0E2D");
            if (order) for (const i of p.items || []) {
              const line = order.items.find((x) => x.productId === i.productId);
              if (!line || number(i.quantity) > line.quantity - line.received) throw Error("\u0E08\u0E33\u0E19\u0E27\u0E19\u0E23\u0E31\u0E1A\u0E40\u0E01\u0E34\u0E19\u0E22\u0E2D\u0E14\u0E2A\u0E31\u0E48\u0E07");
            }
            const receipt = apply(next, { ...command, payload: { ...p, workflow: void 0, paidAmount: 0, paymentMethod: "credit" } }, now);
            if (receipt.result.status !== "applied") return { state, result: receipt.result };
            next = receipt.state;
            const replacement = next.purchases.find((d) => d.id === "web_purchase_" + command.id);
            Object.assign(replacement, { id: doc.id, purchaseNo: doc.purchaseNo, orderId: doc.orderId, orderNo: doc.orderNo, revision: Number(doc.revision || 0) + 1, payments: doc.payments, paidAmount: doc.paidAmount, balance: round(Math.max(0, replacement.total - doc.paidAmount)), refundReceivable: round(Math.max(0, doc.paidAmount - replacement.total)), createdAt: now, originalCreatedAt: doc.originalCreatedAt || doc.createdAt, paymentStatus: doc.paidAmount >= replacement.total ? "PAID" : doc.paidAmount > 0 ? "PARTIAL" : "UNPAID" });
            next.purchases = next.purchases.filter((d) => d !== next.purchases.find((x) => x.id === doc.id && x !== replacement));
            if (order) {
              const target = next.purchaseOrders.find((o) => o.id === order.id);
              for (const i of replacement.items) target.items.find((x) => x.productId === i.productId).received += i.quantity;
            }
            message = "\u0E41\u0E01\u0E49\u0E44\u0E02\u0E43\u0E1A\u0E23\u0E31\u0E1A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E41\u0E25\u0E30\u0E15\u0E49\u0E19\u0E17\u0E38\u0E19\u0E41\u0E25\u0E49\u0E27";
          }
          if (order) {
            const target = next.purchaseOrders.find((o) => o.id === order.id);
            target.status = target.items.every((i) => i.received === i.quantity) ? "RECEIVED" : target.items.some((i) => i.received) ? "PARTIAL" : "OPEN";
            target.revision++;
            target.updatedAt = now;
          }
          next.documentHistory ||= [];
          next.documentHistory.push({ id: "history_" + command.id, documentId: doc.id, before, reason: String(p.reason || p.notes), createdAt: now, deviceId: "SERVERJJ" });
        } else {
          const order = action === "order.receive" ? state.purchaseOrders?.find((o) => o.id === p.orderId) : null;
          const payload = { ...p, ...order ? { taxMode: order.taxMode || "none", taxRate: order.taxRate || 0 } : {} };
          if (!Array.isArray(payload.items)) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E23\u0E30\u0E1A\u0E38\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32");
          const t = totals(payload);
          const wrapped = { ...command, payload: { ...payload, shipping: t.shipping + (t.taxMode === "exclusive" ? t.taxAmount : 0) } };
          const result2 = Legacy.apply(state, wrapped, now);
          if (result2.result.status !== "applied") return result2;
          const doc = action === "order.create" ? result2.state.purchaseOrders.find((o) => o.id === "order_" + command.id) : result2.state.purchases.find((d) => d.id === "web_purchase_" + command.id);
          stamp(doc, payload, state, t);
          if (action !== "order.create") doc.purchaseNo = doc.purchaseNo.replace(/^PO-W-/, "GR-");
          return result2;
        }
        const result = { id: command.id, status: "applied", message, completedAt: now };
        next.meta ||= {};
        next.meta.inventoryBridge ||= {};
        next.meta.inventoryBridge.results ||= {};
        next.meta.inventoryBridge.results[command.id] = result;
        next.auditLogs ||= [];
        next.auditLogs.push({ id: "office_audit_" + command.id, action: "WEB_DOCUMENT", createdAt: now, details: { workflow: action, message } });
        return { state: next, result };
      } catch (e) {
        return { state, result: { id: command.id, status: "rejected", message: e.message, completedAt: now } };
      }
    }
    module2.exports = { apply, totals };
  }
});

// migration/pos/server/document-transaction.cjs
var require_document_transaction = __commonJS({
  "migration/pos/server/document-transaction.cjs"(exports2, module2) {
    "use strict";
    var Model = require_model();
    module2.exports = async function({ db, engine, state, next, result, command, digest, primary }) {
      const receipt = state.purchases?.find((d) => d.id === command.payload.purchaseId);
      const ids = [.../* @__PURE__ */ new Set([...(receipt?.items || []).map((i) => i.productId), ...(command.payload.items || []).map((i) => i.productId)])].filter(Boolean).sort();
      const locks = ids.map((productId) => {
        const h = Model.hash({ command: command.id, productId });
        return { productId, id: h.slice(0, 8) + "-" + h.slice(8, 12) + "-" + h.slice(12, 16) + "-" + h.slice(16, 20) + "-" + h.slice(20, 32) };
      });
      if (ids.length > 100) return { id: command.id, status: "rejected", message: "\u0E41\u0E01\u0E49\u0E44\u0E02\u0E44\u0E14\u0E49\u0E44\u0E21\u0E48\u0E40\u0E01\u0E34\u0E19 100 \u0E23\u0E2B\u0E31\u0E2A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E15\u0E48\u0E2D\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23", completedAt: (/* @__PURE__ */ new Date()).toISOString() };
      let waiting = false;
      for (const lock of locks) {
        const exists = (await db.query("SELECT id FROM chutima.web_commands WHERE id=$1", [lock.id])).rows[0];
        if (result.status === "applied" && !exists) await db.query("INSERT INTO chutima.web_commands(id,digest,command,product_id) VALUES($1,$2,$3,$4)", [lock.id, digest, JSON.stringify(command), lock.productId]);
        if (result.status === "applied" && Number((await db.query("SELECT coalesce(sum(available),0) n FROM chutima.allocations WHERE product_id=$1", [lock.productId])).rows[0].n) > 0) waiting = true;
      }
      if (waiting) return { id: command.id, status: "pending", message: "\u0E23\u0E2D POS \u0E2A\u0E48\u0E07\u0E22\u0E2D\u0E14\u0E41\u0E25\u0E30\u0E1E\u0E31\u0E01\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E17\u0E35\u0E48\u0E40\u0E01\u0E35\u0E48\u0E22\u0E27\u0E02\u0E49\u0E2D\u0E07\u0E01\u0E48\u0E2D\u0E19\u0E41\u0E01\u0E49\u0E44\u0E02\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23" };
      if (result.status === "applied") for (const change of Model.changes(state, next)) {
        if (["purchases", "purchaseOrders", "documentHistory"].includes(change.collection) && change.value) change.value.deviceId = "SERVERJJ";
        await engine.write(db, change, "web_" + command.id);
      }
      for (const lock of locks) {
        const exists = (await db.query("SELECT id FROM chutima.web_commands WHERE id=$1", [lock.id])).rows[0];
        if (!exists) continue;
        const product = next.settings.products[lock.productId];
        const current = Number((await db.query("SELECT coalesce(sum(available),0) n FROM chutima.allocations WHERE product_id=$1", [lock.productId])).rows[0].n);
        let reserve = Model.assertCount(Number(product.stockOnHand) - current);
        const released = (await db.query("SELECT r.device_id,r.quantity FROM chutima.web_releases r JOIN chutima.devices d ON d.id=r.device_id WHERE command_id=$1 ORDER BY d.slot", [lock.id])).rows;
        for (const r of released) {
          const amount = Math.min(reserve, Number(r.quantity));
          reserve -= amount;
          await db.query("INSERT INTO chutima.allocations(product_id,device_id,available) VALUES($1,$2,$3) ON CONFLICT(product_id,device_id) DO UPDATE SET available=chutima.allocations.available+excluded.available", [lock.productId, r.device_id, amount]);
        }
        if (reserve) await db.query("INSERT INTO chutima.allocations(product_id,device_id,available) VALUES($1,$2,$3) ON CONFLICT(product_id,device_id) DO UPDATE SET available=chutima.allocations.available+excluded.available", [lock.productId, primary.id, reserve]);
        await engine.write(db, { collection: "products", key: lock.productId, value: product }, "web_" + command.id);
        await db.query("INSERT INTO chutima.web_results(id,digest,result) VALUES($1,$2,$3)", [lock.id, digest, JSON.stringify({ ...result, id: lock.id })]);
      }
      await db.query("INSERT INTO chutima.web_results(id,digest,result) VALUES($1,$2,$3)", [command.id, digest, JSON.stringify(result)]);
      return result;
    };
  }
});

// migration/pos/server/web-commands.cjs
var require_web_commands = __commonJS({
  "migration/pos/server/web-commands.cjs"(exports2, module2) {
    "use strict";
    var Model = require_model();
    var Core = require_inventory_bridge_core();
    var Purchasing = require_office_documents();
    var uuid = (value) => /^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(value || "");
    async function stateFrom(db) {
      const rows = (await db.query("SELECT collection,id,body FROM chutima.entities WHERE body IS NOT NULL ORDER BY revision")).rows;
      return Model.applyRecords({ meta: {} }, rows.map((r) => ({ collection: r.collection, key: r.id, value: r.body })));
    }
    var WebCommands = class {
      constructor(engine) {
        this.engine = engine;
      }
      async apply(command) {
        if (!uuid(command?.id) || !["product.save", "stock.receive", "stock.count", "supplier.save", "purchase.receive"].includes(command.type) || !command.payload || typeof command.payload !== "object" || Array.isArray(command.payload)) throw Error("\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E08\u0E32\u0E01\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
        const digest = Model.hash({ id: command.id, type: command.type, payload: command.payload });
        return this.engine.transaction(async (db) => {
          const old = (await db.query("SELECT digest,result FROM chutima.web_results WHERE id=$1", [command.id])).rows[0];
          if (old) {
            if (old.digest !== digest) throw Error("\u0E40\u0E25\u0E02\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E40\u0E27\u0E47\u0E1A\u0E0B\u0E49\u0E33\u0E01\u0E31\u0E1A\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E2D\u0E37\u0E48\u0E19");
            return old.result;
          }
          const pending = (await db.query("SELECT digest,product_id FROM chutima.web_commands WHERE id=$1", [command.id])).rows[0];
          if (pending && pending.digest !== digest) throw Error("\u0E40\u0E25\u0E02\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E40\u0E27\u0E47\u0E1A\u0E0B\u0E49\u0E33\u0E01\u0E31\u0E1A\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E2D\u0E37\u0E48\u0E19");
          const state = await stateFrom(db);
          const legacy = state.serverjjMigration?.legacyInventoryResults?.[command.id];
          if (legacy && ["applied", "rejected"].includes(legacy.status)) {
            const receipt = { ...legacy, id: command.id };
            await db.query("INSERT INTO chutima.web_results(id,digest,result) VALUES($1,$2,$3)", [command.id, digest, JSON.stringify(receipt)]);
            return receipt;
          }
          const applied = command.type === "purchase.receive" ? Purchasing.apply(state, command) : Core.apply(state, command);
          let result = applied.result, next = applied.state;
          if (result.status === "applied" && Object.values(next.settings.products).some((p) => p.trackStock === false)) {
            result = { id: command.id, status: "rejected", message: "\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E17\u0E38\u0E01\u0E15\u0E31\u0E27\u0E15\u0E49\u0E2D\u0E07\u0E40\u0E1B\u0E34\u0E14\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E15\u0E4A\u0E2D\u0E01\u0E40\u0E21\u0E37\u0E48\u0E2D\u0E43\u0E0A\u0E49 SERVERJJ", completedAt: (/* @__PURE__ */ new Date()).toISOString() };
            next = state;
          }
          const primary = (await db.query("SELECT id FROM chutima.devices WHERE role='primary' AND enabled=true")).rows[0];
          if (!primary) throw Error("\u0E23\u0E2D\u0E08\u0E31\u0E1A\u0E04\u0E39\u0E48 POS \u0E2B\u0E25\u0E31\u0E01\u0E01\u0E48\u0E2D\u0E19\u0E23\u0E31\u0E1A\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E40\u0E27\u0E47\u0E1A");
          if (["receipt.edit", "receipt.void", "vending.refill"].includes(command.payload.workflow)) return require_document_transaction()({ db, engine: this.engine, state, next, result, command, digest, primary });
          const productId = pending?.product_id || (command.type === "stock.count" || command.payload.workflow === "purchase.return" ? command.payload.productId : null);
          const before = state.settings?.products?.[productId], after = next.settings?.products?.[productId];
          if (result.status === "applied" && (command.type === "stock.count" || command.payload.workflow === "purchase.return") && before && after) {
            await db.query("INSERT INTO chutima.web_commands(id,digest,command,product_id) VALUES($1,$2,$3,$4) ON CONFLICT(id) DO NOTHING", [command.id, digest, JSON.stringify(command), productId]);
            const allocated = Number((await db.query("SELECT coalesce(sum(available),0) AS n FROM chutima.allocations WHERE product_id=$1", [productId])).rows[0].n);
            if (allocated > 0) return { id: command.id, status: "pending", message: "\u0E23\u0E2D POS \u0E17\u0E38\u0E01\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E2A\u0E48\u0E07\u0E22\u0E2D\u0E14\u0E41\u0E25\u0E30\u0E1E\u0E31\u0E01\u0E02\u0E32\u0E22\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E19\u0E35\u0E49\u0E01\u0E48\u0E2D\u0E19\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E1C\u0E25\u0E15\u0E23\u0E27\u0E08\u0E19\u0E31\u0E1A" };
          }
          await db.query("INSERT INTO chutima.web_commands(id,digest,command,product_id) VALUES($1,$2,$3,$4) ON CONFLICT(id) DO NOTHING", [command.id, digest, JSON.stringify(command), pending?.product_id || null]);
          const changes = Model.changes(state, next);
          for (const change of changes) {
            if (change.collection === "products") {
              const delta = Number(change.value?.stockOnHand || 0) - Number(change.before?.stockOnHand || 0);
              Model.assertCount(Number(change.value?.stockOnHand || 0));
              if (delta > 0) await db.query("INSERT INTO chutima.allocations(product_id,device_id,available) VALUES($1,$2,$3) ON CONFLICT(product_id,device_id) DO UPDATE SET available=chutima.allocations.available+excluded.available", [change.key, primary.id, delta]);
              if (delta < 0 && !productId) throw Error("\u0E15\u0E49\u0E2D\u0E07\u0E15\u0E23\u0E27\u0E08\u0E19\u0E31\u0E1A\u0E01\u0E48\u0E2D\u0E19\u0E25\u0E14\u0E2A\u0E15\u0E4A\u0E2D\u0E01");
            }
            if (["purchases", "purchaseOrders", "supplierReturns"].includes(change.collection) && change.value) change.value.deviceId = "SERVERJJ";
            await this.engine.write(db, change, "web_" + command.id);
          }
          if (pending?.product_id || result.status === "applied" && (command.type === "stock.count" || command.payload.workflow === "purchase.return") && before && after) {
            const p = next.settings.products[productId];
            const current = Number((await db.query("SELECT coalesce(sum(available),0) AS n FROM chutima.allocations WHERE product_id=$1", [productId])).rows[0].n);
            let reserve = Model.assertCount(Number(p.stockOnHand) - current);
            const released = (await db.query("SELECT r.device_id,r.quantity FROM chutima.web_releases r JOIN chutima.devices d ON d.id=r.device_id WHERE command_id=$1 ORDER BY d.slot", [command.id])).rows;
            for (const r of released) {
              const amount = Math.min(reserve, Number(r.quantity));
              reserve -= amount;
              await db.query("INSERT INTO chutima.allocations(product_id,device_id,available) VALUES($1,$2,$3) ON CONFLICT(product_id,device_id) DO UPDATE SET available=chutima.allocations.available+excluded.available", [productId, r.device_id, amount]);
            }
            if (reserve) await db.query("INSERT INTO chutima.allocations(product_id,device_id,available) VALUES($1,$2,$3) ON CONFLICT(product_id,device_id) DO UPDATE SET available=chutima.allocations.available+excluded.available", [productId, primary.id, reserve]);
            await this.engine.write(db, { collection: "products", key: productId, value: p }, "web_" + command.id);
          }
          await db.query("INSERT INTO chutima.web_results(id,digest,result) VALUES($1,$2,$3)", [command.id, digest, JSON.stringify(result)]);
          return result;
        });
      }
      async snapshot() {
        return this.engine.transaction(async (db) => {
          const initialized = (await db.query("SELECT initialized FROM chutima.coordination WHERE id=1")).rows[0].initialized;
          if (!initialized) return null;
          const state = await stateFrom(db), snapshot = Core.snapshot(state);
          snapshot.revision = Number((await db.query("SELECT coalesce(max(sequence),0) AS n FROM chutima.changefeed")).rows[0].n);
          const allocations = (await db.query("SELECT a.product_id,a.device_id,a.available,d.label FROM chutima.allocations a JOIN chutima.devices d ON d.id=a.device_id")).rows;
          for (const p of snapshot.products) p.allocations = allocations.filter((a) => a.product_id === p.id).map((a) => ({ deviceId: a.device_id, label: a.label, available: Number(a.available) }));
          const today = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Bangkok" }).format(/* @__PURE__ */ new Date()), Reports = require_reports();
          const dashboard = { date: today, cash: Reports.build(state, { kind: "overview", from: today, to: today }).rows[0] || {}, shifts: (state.shifts || []).filter((s) => s.status === "OPEN").map((s) => ({ id: s.id, employeeName: state.employees?.find((e) => e.id === s.employeeId)?.name || s.employeeName || "", openedAt: s.openedAt, ...require_basket_fees().forShift(state, s) })), queues: Object.fromEntries(["WAITING", "WORKING", "READY", "COMPLETED"].map((status) => [status, (state.queues || []).filter((q) => q.status === status && (status !== "COMPLETED" || String(q.completedAt || "").startsWith(today))).length])) };
          const records = [];
          for (const collection of ["products", "suppliers", "purchases", "movements"]) for (const row of snapshot[collection]) records.push({ collection, id: row.id, body: row });
          for (const collection of ["purchaseOrders", "supplierReturns", "vendingMachines", "vendingEvents"]) for (const row of state[collection] || []) records.push({ collection, id: row.id, body: row });
          for (const page of state.reportPages || []) records.push({ collection: "reportPages", id: page.requestId, body: page });
          records.push({ collection: "meta", id: "catalog", body: { officeSettings: state.officeSettings, dashboard, categories: snapshot.categories, productTrashVersion: 1, purchaseWorkflowVersion: 2, employeeWorkflowVersion: 1, vendingWorkflowVersion: 1, reportVersion: 1 } });
          return { revision: snapshot.revision, records, manifest: Object.fromEntries(["products", "suppliers", "purchases", "movements", "meta", "purchaseOrders", "supplierReturns", "reportPages", "vendingMachines", "vendingEvents"].map((c) => [c, records.filter((r) => r.collection === c).length])) };
        });
      }
    };
    module2.exports = { WebCommands, stateFrom };
  }
});

// migration/pos/server/http.cjs
var require_http = __commonJS({
  "migration/pos/server/http.cjs"(exports2, module2) {
    "use strict";
    var http = require("node:http");
    var https = require("node:https");
    var crypto = require("node:crypto");
    var { URL: URL2 } = require("node:url");
    var sha = (value) => crypto.createHash("sha256").update(String(value)).digest("hex");
    function same(a, b) {
      const x = Buffer.from(String(a || "")), y = Buffer.from(String(b || ""));
      return x.length === y.length && crypto.timingSafeEqual(x, y);
    }
    async function body(req, max = 24 * 1024 * 1024) {
      if (!/^application\/json\b/i.test(req.headers["content-type"] || "")) throw Error("\u0E15\u0E49\u0E2D\u0E07\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25 JSON");
      const chunks = [];
      let length = 0;
      for await (const chunk of req) {
        length += chunk.length;
        if (length > max) {
          const e = Error("\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E43\u0E2B\u0E0D\u0E48\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14");
          e.status = 413;
          throw e;
        }
        chunks.push(chunk);
      }
      return JSON.parse(Buffer.concat(chunks).toString("utf8"));
    }
    function createApi2({ engine, tls, pairingKey, cloud, browser, allowTestHttp = false, onStatus = () => {
    } }) {
      const devices = new (require_device_manager()).DeviceManager(engine);
      const office = new (require_web_commands()).WebCommands(engine);
      if (!tls && !allowTestHttp) throw Error("\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\u0E08\u0E23\u0E34\u0E07\u0E15\u0E49\u0E2D\u0E07\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21\u0E15\u0E48\u0E2D\u0E41\u0E1A\u0E1A HTTPS");
      if (typeof pairingKey !== "string" || pairingKey.length < 32) throw Error("\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E08\u0E31\u0E1A\u0E04\u0E39\u0E48\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07");
      const attempts = /* @__PURE__ */ new Map();
      const handler = async (req, res) => {
        const send = (status, value) => {
          res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" });
          res.end(JSON.stringify(value));
        };
        try {
          const browserUrl = new URL2(req.url, "https://localhost");
          if (browser && await browser.handle(req, res, browserUrl, body, send)) return;
          if (req.headers.origin) {
            send(403, { error: "\u0E43\u0E0A\u0E49\u0E42\u0E1B\u0E23\u0E41\u0E01\u0E23\u0E21 POS \u0E17\u0E35\u0E48\u0E08\u0E31\u0E1A\u0E04\u0E39\u0E48\u0E41\u0E25\u0E49\u0E27" });
            return;
          }
          const url = new URL2(req.url, "https://localhost");
          if (req.method === "GET" && url.pathname === "/health") {
            send(200, { service: "chutima-server", protocol: 1, version: "0.21.0", directOffice: true });
            return;
          }
          if (req.method === "POST" && url.pathname === "/pair") {
            const address = req.socket.remoteAddress, now = Date.now();
            const attempt = attempts.get(address) || { start: now, count: 0 };
            if (now - attempt.start > 6e4) {
              attempt.start = now;
              attempt.count = 0;
            }
            attempt.count++;
            attempts.set(address, attempt);
            if (attempt.count > 10) {
              send(429, { error: "\u0E01\u0E23\u0E38\u0E13\u0E32\u0E23\u0E2D\u0E01\u0E48\u0E2D\u0E19\u0E08\u0E31\u0E1A\u0E04\u0E39\u0E48\u0E2D\u0E35\u0E01\u0E04\u0E23\u0E31\u0E49\u0E07" });
              return;
            }
            if (!same(req.headers.authorization, "Bearer " + pairingKey)) {
              send(401, { error: "\u0E23\u0E2B\u0E31\u0E2A\u0E08\u0E31\u0E1A\u0E04\u0E39\u0E48\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07" });
              return;
            }
            const data = await body(req, 16384);
            if (!/^[A-Za-z0-9_-]{43,128}$/.test(data.key || "")) throw Error("\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E08\u0E31\u0E1A\u0E04\u0E39\u0E48\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
            const existing = await engine.device(data.id);
            if (existing && !same(existing.key_hash, sha(data.key))) {
              send(409, { error: "\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49\u0E08\u0E31\u0E1A\u0E04\u0E39\u0E48\u0E44\u0E27\u0E49\u0E41\u0E25\u0E49\u0E27 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E43\u0E0A\u0E49\u0E01\u0E32\u0E23\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21\u0E15\u0E48\u0E2D\u0E40\u0E14\u0E34\u0E21" });
              return;
            }
            const device2 = await engine.register({ id: data.id, label: data.label, keyHash: sha(data.key) });
            const initialized = (await engine.pool.query("SELECT initialized FROM chutima.coordination WHERE id=1")).rows[0].initialized;
            send(200, { ...device2, initialized });
            return;
          }
          const device = await engine.device(req.headers["x-chutima-device"]);
          const bearer = /^Bearer ([A-Za-z0-9_-]{43,128})$/.exec(req.headers.authorization || "");
          if (!device || !bearer || !same(device.key_hash, sha(bearer[1]))) {
            send(401, { error: "\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C" });
            return;
          }
          if (req.method === "POST" && url.pathname === "/queue/confirm") {
            const input = await body(req, 16384);
            const row = (await engine.pool.query("SELECT body,owner_device FROM chutima.entities WHERE collection='queues' AND id=$1", [input.id])).rows[0];
            if (!row || row.owner_device !== device.id || row.body?.qrToken !== input.token || !(new Date(row.body.updatedAt || row.body.createdAt).getTime() >= new Date(input.updatedAt).getTime())) {
              send(409, { error: "\u0E23\u0E2D\u0E2A\u0E48\u0E07\u0E2A\u0E16\u0E32\u0E19\u0E30\u0E04\u0E34\u0E27\u0E40\u0E02\u0E49\u0E32 SERVERJJ" });
              return;
            }
            send(200, { confirmed: true });
            return;
          }
          if (req.method === "POST" && url.pathname === "/office/staff" && browser) {
            if (device.role !== "primary") {
              send(403, { error: "\u0E08\u0E31\u0E14\u0E01\u0E32\u0E23\u0E1E\u0E19\u0E31\u0E01\u0E07\u0E32\u0E19\u0E17\u0E35\u0E48\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E2B\u0E25\u0E31\u0E01\u0E2B\u0E23\u0E37\u0E2D\u0E40\u0E27\u0E47\u0E1A\u0E40\u0E08\u0E49\u0E32\u0E02\u0E2D\u0E07\u0E23\u0E49\u0E32\u0E19" });
              return;
            }
            send(200, await browser.staff({ role: "owner" }, await body(req, 16384)));
            return;
          }
          if (req.method === "GET" && url.pathname === "/device") {
            const pending = url.searchParams.has("pending") ? Number(url.searchParams.get("pending")) : null;
            if (pending !== null && (!Number.isSafeInteger(pending) || pending < 0 || pending > 9999999)) throw Error("\u0E08\u0E33\u0E19\u0E27\u0E19\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E23\u0E2D\u0E2A\u0E48\u0E07\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
            await engine.pool.query("UPDATE chutima.devices SET last_seen=now(),reported_pending=coalesce($1,reported_pending) WHERE id=$2", [pending, device.id]);
            send(200, { id: device.id, label: device.label, slot: device.slot, role: device.role, deviceManagement: true, lastSequence: Number(device.last_sequence), stockReleases: true, ...cloud ? { cloud: cloud.status() } : {} });
            return;
          }
          if (req.method === "GET" && url.pathname === "/device-management") {
            send(200, await devices.status(device.id));
            return;
          }
          if (req.method === "POST" && url.pathname === "/device-management") {
            const key = "manage:" + device.id, now = Date.now(), attempt = attempts.get(key) || { start: now, count: 0 };
            if (now - attempt.start > 6e4) {
              attempt.start = now;
              attempt.count = 0;
            }
            attempt.count++;
            attempts.set(key, attempt);
            if (attempt.count > 10) {
              send(429, { error: "\u0E01\u0E23\u0E38\u0E13\u0E32\u0E23\u0E2D\u0E01\u0E48\u0E2D\u0E19\u0E08\u0E31\u0E14\u0E01\u0E32\u0E23\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E2D\u0E35\u0E01\u0E04\u0E23\u0E31\u0E49\u0E07" });
              return;
            }
            send(200, await devices.manage(device.id, await body(req, 16384)));
            return;
          }
          if (req.method === "POST" && url.pathname === "/stock/adjust") {
            send(200, await devices.adjust(device.id, await body(req, 1024 * 1024)));
            return;
          }
          if (req.method === "POST" && url.pathname === "/device-quiesce") {
            send(200, await devices.quiesce(device.id, await body(req, 16384)));
            return;
          }
          if (req.method === "GET" && url.pathname === "/devices") {
            const devices2 = (await engine.pool.query("SELECT id,label,slot,last_seen FROM chutima.devices WHERE enabled=true ORDER BY slot")).rows;
            send(200, { devices: devices2 });
            return;
          }
          if (req.method === "GET" && url.pathname === "/stock-releases") {
            const releases = (await engine.pool.query('SELECT w.id AS "commandId",w.product_id AS "productId" FROM chutima.web_commands w LEFT JOIN chutima.web_results r ON r.id=w.id WHERE r.id IS NULL AND w.product_id IS NOT NULL ORDER BY w.created_at,w.id LIMIT 100')).rows;
            send(200, { releases });
            return;
          }
          if (req.method === "POST" && url.pathname === "/cloud/register" && cloud) {
            if (device.role !== "primary") {
              send(403, { error: "\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21\u0E1A\u0E31\u0E0D\u0E0A\u0E35\u0E40\u0E27\u0E47\u0E1A\u0E17\u0E35\u0E48 POS \u0E2B\u0E25\u0E31\u0E01\u0E40\u0E17\u0E48\u0E32\u0E19\u0E31\u0E49\u0E19" });
              return;
            }
            const data = await body(req, 2e4);
            send(200, await cloud.register(data.ownerToken));
            return;
          }
          if (req.method === "POST" && url.pathname === "/operations") {
            const operation = await body(req);
            if (operation.deviceId !== device.id) {
              send(403, { error: "\u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E2A\u0E48\u0E07\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E41\u0E17\u0E19\u0E2D\u0E35\u0E01\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07" });
              return;
            }
            const result = await engine.apply(operation);
            onStatus();
            send(200, result);
            return;
          }
          if (device.role === "reserve" && req.method === "POST") {
            send(403, { error: "\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E2A\u0E33\u0E23\u0E2D\u0E07\u0E22\u0E31\u0E07\u0E17\u0E33\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E08\u0E23\u0E34\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49" });
            return;
          }
          if (req.method === "POST" && url.pathname === "/office/commands") {
            send(200, await office.apply(await body(req, 2 * 1024 * 1024)));
            onStatus();
            return;
          }
          if (req.method === "GET" && url.pathname === "/office/snapshot") {
            send(200, await office.snapshot());
            return;
          }
          if (req.method === "GET" && url.pathname === "/changes") {
            send(200, await engine.pull(device.id, Number(url.searchParams.get("after") || 0), Number(url.searchParams.get("limit") || 500)));
            return;
          }
          send(404, { error: "\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E17\u0E35\u0E48\u0E02\u0E2D" });
        } catch (error) {
          const status = error.status || (error.code === "CONFLICT" || /ลำดับรายการ|ข้อมูลตั้งต้นทับ/.test(error.message) ? 409 : 400);
          send(status, { error: /[ก-๙]/.test(error.message) ? error.message : "\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E16\u0E32\u0E19\u0E30\u0E40\u0E0B\u0E34\u0E23\u0E4C\u0E1F\u0E40\u0E27\u0E2D\u0E23\u0E4C" });
        }
      };
      const server = tls ? https.createServer({ ...tls, minVersion: "TLSv1.2" }, handler) : http.createServer(handler);
      server.requestTimeout = 45e3;
      server.headersTimeout = 1e4;
      server.maxRequestsPerSocket = 100;
      return server;
    }
    module2.exports = { createApi: createApi2, sha };
  }
});

// migration/pos/server/backup.cjs
var require_backup = __commonJS({
  "migration/pos/server/backup.cjs"(exports2, module2) {
    "use strict";
    var fs2 = require("node:fs");
    var path2 = require("node:path");
    var crypto = require("node:crypto");
    var { spawn } = require("node:child_process");
    function run(exe, args, env) {
      return new Promise((resolve, reject) => {
        const child = spawn(exe, args, { env: { ...process.env, ...env }, windowsHide: true, stdio: ["ignore", "pipe", "pipe"] });
        let output = "";
        child.stdout.on("data", (chunk) => {
          if (output.length < 1048576) output += chunk;
        });
        child.stderr.resume();
        child.once("error", reject);
        child.once("close", (code) => code === 0 ? resolve(output) : reject(Error("\u0E15\u0E23\u0E27\u0E08\u0E2B\u0E23\u0E37\u0E2D\u0E2A\u0E33\u0E23\u0E2D\u0E07\u0E10\u0E32\u0E19\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E0A\u0E38\u0E15\u0E34\u0E21\u0E32\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08")));
      });
    }
    var ServerBackup2 = class {
      constructor({ pool, config, base }) {
        this.pool = pool;
        this.config = config;
        this.base = base;
        this.running = null;
        this.error = null;
      }
      create() {
        if (this.running) return this.running;
        this.running = this.run().catch((e) => {
          this.error = e.message;
          throw e;
        }).finally(() => {
          this.running = null;
        });
        return this.running;
      }
      async run() {
        const dir = path2.resolve(this.base, this.config.backupDirectory), bin = path2.resolve(this.base, this.config.postgresBin);
        if (!path2.basename(dir).toLowerCase().includes("chutima")) throw Error("\u0E15\u0E49\u0E2D\u0E07\u0E43\u0E0A\u0E49\u0E42\u0E1F\u0E25\u0E40\u0E14\u0E2D\u0E23\u0E4C\u0E2A\u0E33\u0E23\u0E2D\u0E07\u0E17\u0E35\u0E48\u0E41\u0E22\u0E01\u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A\u0E0A\u0E38\u0E15\u0E34\u0E21\u0E32");
        fs2.mkdirSync(dir, { recursive: true });
        const id = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-") + "-" + crypto.randomUUID().slice(0, 8);
        const temp = path2.join(dir, "chutima-" + id + ".partial"), file = path2.join(dir, "chutima-" + id + ".dump");
        const env = { PGHOST: "127.0.0.1", PGPORT: "5433", PGDATABASE: "chutima", PGUSER: this.config.database.user, PGPASSWORD: this.config.database.password, PGCONNECT_TIMEOUT: "10" };
        await run(path2.join(bin, "pg_dump.exe"), ["--format=custom", "--no-password", "--file", temp, "chutima"], env);
        const list = await run(path2.join(bin, "pg_restore.exe"), ["--list", temp], env);
        for (const table of ["entities", "operations", "devices", "allocations", "changefeed"]) if (!list.includes("TABLE DATA chutima " + table + " ")) throw Error("\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E2A\u0E33\u0E23\u0E2D\u0E07\u0E44\u0E21\u0E48\u0E04\u0E23\u0E1A");
        const hasher = crypto.createHash("sha256");
        for await (const chunk of fs2.createReadStream(temp)) hasher.update(chunk);
        const manifest = { id, createdAt: (/* @__PURE__ */ new Date()).toISOString(), bytes: fs2.statSync(temp).size, sha256: hasher.digest("hex"), archiveChecked: true, restored: false };
        fs2.renameSync(temp, file);
        fs2.writeFileSync(file + ".json", JSON.stringify(manifest, null, 2), { flag: "wx" });
        this.error = null;
        this.last = { ...manifest, file };
        return this.last;
      }
      start() {
        this.create().catch(() => {
        });
        this.timer = setInterval(() => this.create().catch(() => {
        }), 36e5);
        this.timer.unref?.();
      }
      stop() {
        clearInterval(this.timer);
      }
    };
    module2.exports = { ServerBackup: ServerBackup2, run };
  }
});

// migration/pos/sync-service.cjs
var require_sync_service = __commonJS({
  "migration/pos/sync-service.cjs"(exports2, module2) {
    "use strict";
    var fs2 = require("node:fs");
    var path2 = require("node:path");
    var crypto = require("node:crypto");
    var TERMINAL_STATUSES = /* @__PURE__ */ new Set(["COMPLETED", "CANCELLED"]);
    var DEFAULT_CUSTOMER_STATUS_BASE_URL = "https://chutimafresh88.github.io/chutima-laundry-status";
    function parseEnv(text) {
      const result = {};
      for (const rawLine of String(text || "").split(/\r?\n/)) {
        const line = rawLine.trim();
        if (!line || line.startsWith("#")) continue;
        const separator = line.indexOf("=");
        if (separator < 1) continue;
        const key = line.slice(0, separator).trim();
        let value = line.slice(separator + 1).trim();
        if (value.startsWith('"') && value.endsWith('"') || value.startsWith("'") && value.endsWith("'")) {
          value = value.slice(1, -1);
        }
        result[key] = value;
      }
      return result;
    }
    function readSyncConfig({ appPath, configPath, env = process.env } = {}) {
      let fileValues = {};
      const envPaths = [
        path2.join(appPath || process.cwd(), ".env"),
        configPath
      ].filter((value, index, values2) => value && values2.indexOf(value) === index);
      for (const envPath of envPaths) {
        try {
          if (fs2.existsSync(envPath)) {
            fileValues = { ...fileValues, ...parseEnv(fs2.readFileSync(envPath, "utf8")) };
          }
        } catch (error) {
          console.warn("Cannot read local Supabase configuration:", error.message);
        }
      }
      const values = { ...fileValues, ...env };
      const supabaseUrl = String(values.SUPABASE_URL || "").trim().replace(/\/+$/, "");
      const publishableKey = String(values.SUPABASE_PUBLISHABLE_KEY || values.SUPABASE_ANON_KEY || "").trim();
      const deviceKey = String(values.QUEUE_SYNC_DEVICE_KEY || "").trim();
      const customerStatusBaseUrl = String(values.CUSTOMER_STATUS_BASE_URL || DEFAULT_CUSTOMER_STATUS_BASE_URL).trim().replace(/\/+$/, "");
      return {
        supabaseUrl,
        publishableKey,
        deviceKey,
        customerStatusBaseUrl,
        configured: Boolean(supabaseUrl && publishableKey && deviceKey),
        publicConfigured: Boolean(supabaseUrl && publishableKey && customerStatusBaseUrl)
      };
    }
    function isoOrNull(value) {
      if (!value) return null;
      const date = new Date(value);
      return Number.isNaN(date.getTime()) ? null : date.toISOString();
    }
    function publicStatus(status) {
      const value = String(status || "WAITING").toUpperCase();
      return ["WAITING", "WORKING", "READY", "COMPLETED", "CANCELLED"].includes(value) ? value : "WAITING";
    }
    function recommendedPickupAt(queue) {
      if (queue.readyAt) return isoOrNull(queue.readyAt);
      const expected = (Array.isArray(queue.baskets) ? queue.baskets : []).map((basket) => isoOrNull(basket.expectedEndAt)).filter(Boolean).map((value) => new Date(value).getTime());
      if (!expected.length) return null;
      return new Date(Math.max(...expected) + 10 * 60 * 1e3).toISOString();
    }
    function terminalExpiry(queue) {
      const status = publicStatus(queue.status);
      if (!TERMINAL_STATUSES.has(status)) return null;
      const terminalAt = isoOrNull(status === "COMPLETED" ? queue.completedAt : queue.cancelledAt) || isoOrNull(queue.updatedAt) || (/* @__PURE__ */ new Date()).toISOString();
      return new Date(new Date(terminalAt).getTime() + 48 * 60 * 60 * 1e3).toISOString();
    }
    function projectPublicQueue(queue) {
      const baskets = (Array.isArray(queue?.baskets) ? queue.baskets : []).map((basket, index) => ({
        basket_id: String(basket.id || `${queue.id}_basket_${index + 1}`),
        basket_number: Number(basket.number || index + 1),
        status: publicStatus(basket.status),
        service_type: ["wash", "dry", "washDry"].includes(basket.serviceType) ? basket.serviceType : null,
        wash_size: basket.serviceType === "wash" || basket.serviceType === "washDry" ? String(basket.wash?.size || "") || null : null,
        wash_program: basket.serviceType === "wash" || basket.serviceType === "washDry" ? String(basket.wash?.program || "") || null : null,
        dry_size: basket.serviceType === "dry" || basket.serviceType === "washDry" ? String(basket.dry?.size || "") || null : null,
        dry_heat: basket.serviceType === "dry" || basket.serviceType === "washDry" ? String(basket.dry?.heat || "") || null : null,
        finish: basket.serviceType === "dry" || basket.serviceType === "washDry" ? String(basket.finish || "") || null : null,
        started_at: isoOrNull(basket.startedAt),
        expected_end_at: isoOrNull(basket.expectedEndAt),
        ready_at: isoOrNull(basket.readyAt),
        updated_at: isoOrNull(basket.updatedAt || queue.updatedAt) || (/* @__PURE__ */ new Date()).toISOString()
      }));
      const updatedAt = isoOrNull(queue.updatedAt) || isoOrNull(queue.createdAt) || (/* @__PURE__ */ new Date()).toISOString();
      return {
        queue_id: String(queue.id),
        public_token: String(queue.qrToken || ""),
        queue_number: String(queue.queueNo ?? ""),
        status: publicStatus(queue.status),
        basket_count: baskets.length,
        created_at: isoOrNull(queue.createdAt) || updatedAt,
        updated_at: updatedAt,
        ready_at: isoOrNull(queue.readyAt),
        completed_at: isoOrNull(queue.completedAt),
        cancelled_at: isoOrNull(queue.cancelledAt),
        recommended_pickup_at: recommendedPickupAt(queue),
        expires_at: terminalExpiry(queue),
        baskets
      };
    }
    function stableStringify(value) {
      if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
      if (value && typeof value === "object") {
        return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`).join(",")}}`;
      }
      return JSON.stringify(value);
    }
    function payloadHash(payload) {
      return crypto.createHash("sha256").update(stableStringify(payload)).digest("hex");
    }
    function initSyncSchema(database) {
      database.exec(`
    CREATE TABLE IF NOT EXISTS sync_outbox (
      event_id TEXT PRIMARY KEY,
      aggregate_key TEXT NOT NULL,
      payload_hash TEXT NOT NULL,
      payload_json TEXT NOT NULL,
      created_at TEXT NOT NULL,
      attempts INTEGER NOT NULL DEFAULT 0,
      next_attempt_at TEXT NOT NULL,
      last_error TEXT,
      processed_at TEXT,
      UNIQUE (aggregate_key, payload_hash)
    ) STRICT;
    CREATE INDEX IF NOT EXISTS sync_outbox_due_idx
      ON sync_outbox (processed_at, next_attempt_at, created_at);
  `);
    }
    function enqueueChangedQueues(database, previousState, nextState, now = /* @__PURE__ */ new Date()) {
      const previous = new Map((previousState?.queues || []).map((queue) => [String(queue.id), payloadHash(projectPublicQueue(queue))]));
      const insert = database.prepare(`
    INSERT OR IGNORE INTO sync_outbox (
      event_id, aggregate_key, payload_hash, payload_json, created_at, next_attempt_at
    ) VALUES (?, ?, ?, ?, ?, ?)
  `);
      let queued = 0;
      for (const queue of nextState?.queues || []) {
        if (!queue?.id || !queue?.qrToken) continue;
        const payload = projectPublicQueue(queue);
        const hash = payloadHash(payload);
        if (previous.get(String(queue.id)) === hash) continue;
        const createdAt = now.toISOString();
        const result = insert.run(crypto.randomUUID(), String(queue.id), hash, JSON.stringify(payload), createdAt, createdAt);
        queued += Number(result.changes || 0);
      }
      return queued;
    }
    function countPending(database) {
      return Number(database.prepare("SELECT count(*) AS count FROM sync_outbox WHERE processed_at IS NULL").get()?.count || 0);
    }
    function safeError(error) {
      const text = error instanceof Error ? error.message : String(error || "Unknown sync error");
      return text.replace(/[\r\n]+/g, " ").slice(0, 500);
    }
    var SyncService = class {
      constructor({ database, config, central, fetchImpl = globalThis.fetch, onStatus = () => {
      }, now = () => /* @__PURE__ */ new Date() }) {
        this.database = database;
        this.central = central;
        this.config = config;
        this.fetchImpl = fetchImpl;
        this.onStatus = onStatus;
        this.now = now;
        this.timer = null;
        this.running = false;
      }
      status(extra = {}) {
        return {
          configured: Boolean(this.config?.configured),
          pending: countPending(this.database),
          ...extra
        };
      }
      start() {
        if (this.timer || !this.config?.configured) {
          this.onStatus(this.status());
          return;
        }
        this.timer = setInterval(() => this.flush().catch(() => void 0), 15e3);
        this.timer.unref?.();
        this.flush().catch(() => void 0);
      }
      stop() {
        if (this.timer) clearInterval(this.timer);
        this.timer = null;
      }
      trigger() {
        if (!this.config?.configured) return;
        setTimeout(() => this.flush().catch(() => void 0), 0);
      }
      async flush(limit = 20) {
        if (this.running || !this.config?.configured) return this.status();
        this.running = true;
        const now = this.now();
        try {
          const rows = this.database.prepare(`
        SELECT event_id, payload_json, attempts
        FROM sync_outbox
        WHERE processed_at IS NULL AND next_attempt_at <= ?
        ORDER BY created_at ASC
        LIMIT ?
      `).all(now.toISOString(), Math.max(1, Number(limit || 20)));
          for (const row of rows) await this.sendOne(row);
          const status = this.status({ lastAttemptAt: this.now().toISOString() });
          this.onStatus(status);
          return status;
        } finally {
          this.running = false;
        }
      }
      async sendOne(row) {
        try {
          if (this.config.mode === "serverjj") {
            const central = typeof this.central === "function" ? this.central() : this.central;
            if (!central?.config || !central.store.enabled()) throw Error("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E08\u0E31\u0E1A\u0E04\u0E39\u0E48 POS \u0E01\u0E31\u0E1A SERVERJJ");
            await central.exchange();
            if (central.error || central.lockReason) throw Error("\u0E23\u0E2D POS \u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E40\u0E02\u0E49\u0E32 SERVERJJ");
            const queue = JSON.parse(row.payload_json);
            await central.transport(central.config, "/queue/confirm", { method: "POST", body: { id: queue.queue_id, token: queue.public_token, updatedAt: queue.updated_at } });
          } else {
            const response = await this.fetchImpl(`${this.config.supabaseUrl}/functions/v1/sync-queue-status`, {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                apikey: this.config.publishableKey,
                "x-device-key": this.config.deviceKey,
                "x-idempotency-key": row.event_id
              },
              body: JSON.stringify({ event_id: row.event_id, queue: JSON.parse(row.payload_json) }),
              signal: AbortSignal.timeout(1e4)
            });
            if (!response.ok) {
              const detail = (await response.text()).slice(0, 300);
              throw new Error(`HTTP ${response.status}${detail ? `: ${detail}` : ""}`);
            }
          }
          this.database.prepare(`
        UPDATE sync_outbox SET processed_at = ?, last_error = NULL WHERE event_id = ?
      `).run(this.now().toISOString(), row.event_id);
        } catch (error) {
          const attempts = Number(row.attempts || 0) + 1;
          const delayMs = Math.min(5 * 60 * 1e3, 2 ** Math.min(attempts, 8) * 1e3);
          const nextAttemptAt = new Date(this.now().getTime() + delayMs).toISOString();
          this.database.prepare(`
        UPDATE sync_outbox
        SET attempts = ?, next_attempt_at = ?, last_error = ?
        WHERE event_id = ?
      `).run(attempts, nextAttemptAt, safeError(error), row.event_id);
        }
      }
    };
    module2.exports = {
      DEFAULT_CUSTOMER_STATUS_BASE_URL,
      SyncService,
      countPending,
      enqueueChangedQueues,
      initSyncSchema,
      parseEnv,
      payloadHash,
      projectPublicQueue,
      readSyncConfig,
      recommendedPickupAt,
      terminalExpiry
    };
  }
});

// migration/pos/server/browser-office.cjs
var require_browser_office = __commonJS({
  "migration/pos/server/browser-office.cjs"(exports2, module2) {
    "use strict";
    var crypto = require("node:crypto");
    var fs2 = require("node:fs");
    var path2 = require("node:path");
    var Auth = require_employee_auth();
    var { WebCommands } = require_web_commands();
    var { projectPublicQueue } = require_sync_service();
    var digest = (v) => crypto.createHash("sha256").update(String(v)).digest("hex");
    var equal = (a, b) => {
      const x = Buffer.from(a), y = Buffer.from(b);
      return x.length === y.length && crypto.timingSafeEqual(x, y);
    };
    var fail = (message, status = 400) => Object.assign(Error(message), { status });
    var publicUser = (u) => ({ user_id: u.id, username: u.username, display_name: u.display_name, role: u.role, active: u.active, created_at: u.created_at, pos_ready: u.role !== "owner" });
    var BrowserOffice2 = class {
      constructor({ engine, root, setupFile, allowedOrigins = [] }) {
        Object.assign(this, { engine, root, setupFile });
        this.office = new WebCommands(engine);
        this.origins = new Set(allowedOrigins);
        this.attempts = /* @__PURE__ */ new Map();
      }
      async init() {
        await (this.engine.pool.exec ? this.engine.pool.exec.bind(this.engine.pool) : this.engine.pool.query.bind(this.engine.pool))(`CREATE TABLE IF NOT EXISTS chutima.office_users(id text PRIMARY KEY,username text UNIQUE NOT NULL,display_name text NOT NULL,role text NOT NULL CHECK(role IN ('owner','manager','employee')),active boolean NOT NULL DEFAULT true,verifier jsonb NOT NULL,created_at timestamptz NOT NULL DEFAULT now()); CREATE TABLE IF NOT EXISTS chutima.office_sessions(token_hash text PRIMARY KEY,user_id text NOT NULL REFERENCES chutima.office_users(id),expires_at timestamptz NOT NULL); CREATE INDEX IF NOT EXISTS office_sessions_expiry ON chutima.office_sessions(expires_at); CREATE INDEX IF NOT EXISTS queue_public_token ON chutima.entities((body->>'qrToken')) WHERE collection='queues';`);
        const exists = (await this.engine.pool.query("SELECT id FROM chutima.office_users WHERE role='owner'")).rows.length;
        if (!exists && this.setupFile) {
          fs2.mkdirSync(path2.dirname(this.setupFile), { recursive: true });
          if (!fs2.existsSync(this.setupFile)) fs2.writeFileSync(this.setupFile, crypto.randomBytes(32).toString("base64url"), { mode: 384, flag: "wx" });
          this.setupHash = digest(fs2.readFileSync(this.setupFile, "utf8").trim());
        }
      }
      stop() {
        clearInterval(this.timer);
      }
      start() {
        this.timer = setInterval(() => this.retryPending().catch(() => {
        }), 1e4);
        this.timer.unref?.();
      }
      async retryPending() {
        if (this.retrying) return;
        this.retrying = true;
        try {
          const rows = (await this.engine.pool.query("SELECT w.command FROM chutima.web_commands w LEFT JOIN chutima.web_results r ON r.id=w.id WHERE r.id IS NULL ORDER BY w.created_at LIMIT 50")).rows;
          for (const r of rows) await this.office.apply(r.command);
        } finally {
          this.retrying = false;
        }
      }
      limit(req, group, max = 15) {
        const now = Date.now(), key = group + ":" + req.socket.remoteAddress;
        for (const [k, v2] of this.attempts) if (v2.until < now) this.attempts.delete(k);
        if (this.attempts.size > 1e4) throw fail("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E23\u0E2D\u0E2A\u0E31\u0E01\u0E04\u0E23\u0E39\u0E48", 429);
        const v = this.attempts.get(key) || { until: now + 6e4, n: 0 };
        v.n++;
        this.attempts.set(key, v);
        if (v.n > max) throw fail("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E23\u0E2D\u0E2A\u0E31\u0E01\u0E04\u0E23\u0E39\u0E48\u0E41\u0E25\u0E49\u0E27\u0E25\u0E2D\u0E07\u0E43\u0E2B\u0E21\u0E48", 429);
      }
      async session(req) {
        const token = /^Bearer ([A-Za-z0-9_-]{43})$/.exec(req.headers.authorization || "")?.[1];
        if (!token) throw fail("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E40\u0E02\u0E49\u0E32\u0E2A\u0E39\u0E48\u0E23\u0E30\u0E1A\u0E1A", 401);
        const u = (await this.engine.pool.query("SELECT u.* FROM chutima.office_sessions s JOIN chutima.office_users u ON u.id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>now() AND u.active=true", [digest(token)])).rows[0];
        if (!u) throw fail("\u0E2B\u0E21\u0E14\u0E40\u0E27\u0E25\u0E32\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19 \u0E01\u0E23\u0E38\u0E13\u0E32\u0E40\u0E02\u0E49\u0E32\u0E2A\u0E39\u0E48\u0E23\u0E30\u0E1A\u0E1A\u0E43\u0E2B\u0E21\u0E48", 401);
        return u;
      }
      async issue(u) {
        const token = crypto.randomBytes(32).toString("base64url"), expires = Date.now() + 8 * 36e5;
        await this.engine.pool.query("DELETE FROM chutima.office_sessions WHERE expires_at<=now()");
        await this.engine.pool.query("INSERT INTO chutima.office_sessions VALUES($1,$2,$3)", [digest(token), u.id, new Date(expires).toISOString()]);
        return { token, expires_at: expires, user: publicUser(u) };
      }
      async setup(input) {
        if (!this.setupHash || !equal(digest(input.code || ""), this.setupHash)) throw fail("\u0E23\u0E2B\u0E31\u0E2A\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E04\u0E23\u0E31\u0E49\u0E07\u0E41\u0E23\u0E01\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07", 403);
        const username = String(input.username || "").trim().toLowerCase();
        if (!/^[a-z0-9][a-z0-9@._+-]{2,119}$/.test(username) || String(input.password || "").length < 12) throw fail("\u0E01\u0E23\u0E2D\u0E01\u0E0A\u0E37\u0E48\u0E2D\u0E1C\u0E39\u0E49\u0E43\u0E0A\u0E49 \u0E41\u0E25\u0E30\u0E23\u0E2B\u0E31\u0E2A\u0E1C\u0E48\u0E32\u0E19\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E19\u0E49\u0E2D\u0E22 12 \u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23");
        const verifier = await Auth.hashPassword(input.password);
        const user = await this.engine.transaction(async (db) => {
          if ((await db.query("SELECT id FROM chutima.office_users WHERE role='owner'")).rows.length) throw fail("\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E40\u0E08\u0E49\u0E32\u0E02\u0E2D\u0E07\u0E23\u0E49\u0E32\u0E19\u0E41\u0E25\u0E49\u0E27", 409);
          return (await db.query("INSERT INTO chutima.office_users(id,username,display_name,role,verifier) VALUES($1,$2,$3,'owner',$4) RETURNING *", [crypto.randomUUID(), username, "\u0E40\u0E08\u0E49\u0E32\u0E02\u0E2D\u0E07\u0E23\u0E49\u0E32\u0E19", JSON.stringify(verifier)])).rows[0];
        });
        this.setupHash = null;
        if (this.setupFile) fs2.rmSync(this.setupFile, { force: true });
        return this.issue(user);
      }
      async login(input) {
        const username = String(input.username || "").trim().toLowerCase();
        const u = (await this.engine.pool.query("SELECT * FROM chutima.office_users WHERE username=$1", [username])).rows[0];
        const dummy = { algorithm: "PBKDF2-SHA256", iterations: 21e4, salt: "0".repeat(32), hash: "0".repeat(64) };
        const ok = await Auth.verify({ active: true, passwordVerifier: u?.verifier || dummy }, String(input.password || "").slice(0, 129));
        if (!ok || !u?.active) throw fail("\u0E0A\u0E37\u0E48\u0E2D\u0E1C\u0E39\u0E49\u0E43\u0E0A\u0E49\u0E2B\u0E23\u0E37\u0E2D\u0E23\u0E2B\u0E31\u0E2A\u0E1C\u0E48\u0E32\u0E19\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07", 401);
        return this.issue(u);
      }
      async staff(u, input) {
        if (u.role !== "owner") throw fail("\u0E40\u0E09\u0E1E\u0E32\u0E30\u0E40\u0E08\u0E49\u0E32\u0E02\u0E2D\u0E07\u0E23\u0E49\u0E32\u0E19\u0E08\u0E31\u0E14\u0E01\u0E32\u0E23\u0E1A\u0E31\u0E0D\u0E0A\u0E35\u0E1E\u0E19\u0E31\u0E01\u0E07\u0E32\u0E19\u0E44\u0E14\u0E49", 403);
        if (input.action === "list") return { users: (await this.engine.pool.query("SELECT id,username,display_name,role,active,created_at FROM chutima.office_users WHERE role<>'owner' ORDER BY created_at")).rows.map(publicUser) };
        if (!["create", "update"].includes(input.action) || !["manager", "employee"].includes(input.role)) throw fail("\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E1E\u0E19\u0E31\u0E01\u0E07\u0E32\u0E19\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
        const username = String(input.username || "").trim().toLowerCase(), displayName = String(input.displayName || "").trim();
        if (!displayName || displayName.length > 120) throw fail("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E01\u0E23\u0E2D\u0E01\u0E0A\u0E37\u0E48\u0E2D\u0E1E\u0E19\u0E31\u0E01\u0E07\u0E32\u0E19");
        if (input.action === "create" && !/^[a-z0-9][a-z0-9._-]{2,31}$/.test(username)) throw fail("\u0E0A\u0E37\u0E48\u0E2D\u0E1C\u0E39\u0E49\u0E43\u0E0A\u0E49\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
        if ((input.action === "create" || input.password) && String(input.password || "").length < 8) throw fail("\u0E23\u0E2B\u0E31\u0E2A\u0E1C\u0E48\u0E32\u0E19\u0E1E\u0E19\u0E31\u0E01\u0E07\u0E32\u0E19\u0E15\u0E49\u0E2D\u0E07\u0E22\u0E32\u0E27\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E19\u0E49\u0E2D\u0E22 8 \u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23");
        const verifier = input.password ? await Auth.hashPassword(input.password) : null;
        return this.engine.transaction(async (db) => {
          let user;
          if (input.action === "create") {
            user = (await db.query("INSERT INTO chutima.office_users(id,username,display_name,role,verifier) VALUES($1,$2,$3,$4,$5) RETURNING *", [crypto.randomUUID(), username, displayName, input.role, JSON.stringify(verifier)])).rows[0];
          } else {
            if (typeof input.active !== "boolean") throw fail("\u0E2A\u0E16\u0E32\u0E19\u0E30\u0E1E\u0E19\u0E31\u0E01\u0E07\u0E32\u0E19\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
            user = (await db.query("UPDATE chutima.office_users SET display_name=$1,role=$2,active=$3,verifier=coalesce($4,verifier) WHERE id=$5 AND role<>'owner' RETURNING *", [displayName, input.role, input.active, verifier ? JSON.stringify(verifier) : null, input.userId])).rows[0];
            if (!user) throw fail("\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E1A\u0E31\u0E0D\u0E0A\u0E35\u0E1E\u0E19\u0E31\u0E01\u0E07\u0E32\u0E19");
            await db.query("DELETE FROM chutima.office_sessions WHERE user_id=$1", [user.id]);
          }
          const old = (await db.query("SELECT body FROM chutima.entities WHERE collection='employees' AND id=$1", [user.id])).rows[0]?.body || {};
          await this.engine.write(db, { collection: "employees", key: user.id, value: { ...old, id: user.id, name: user.display_name, username: user.username, role: user.role, active: user.active, passwordVerifier: user.verifier, pin: "", staffUpdatedAt: (/* @__PURE__ */ new Date()).toISOString(), updatedAt: (/* @__PURE__ */ new Date()).toISOString() } }, "staff_" + crypto.randomUUID());
          return { user: publicUser(user) };
        });
      }
      async load(u, revision) {
        const rev = Number((await this.engine.pool.query("SELECT coalesce(max(sequence),0) AS n FROM chutima.changefeed")).rows[0].n);
        const devices = (await this.engine.pool.query("SELECT id,label,last_seen,reported_pending FROM chutima.devices WHERE enabled=true ORDER BY slot")).rows.map((d) => ({ id: d.id, label: d.label, online: !!d.last_seen && Date.now() - new Date(d.last_seen).getTime() < 9e4, pending: Number(d.reported_pending) }));
        const requests = u.role === "employee" ? [] : (await this.engine.pool.query("SELECT w.id,w.command->>'type' AS type,w.command->'payload' AS payload,coalesce(r.result->>'status','pending') AS status,coalesce(r.result->>'message','\u0E23\u0E2D POS \u0E2A\u0E48\u0E07\u0E22\u0E2D\u0E14') AS message,w.created_at,r.result->>'completedAt' AS completed_at FROM chutima.web_commands w LEFT JOIN chutima.web_results r ON r.id=w.id ORDER BY w.created_at DESC LIMIT 1000")).rows;
        const base = { snapshotAt: (/* @__PURE__ */ new Date()).toISOString(), requests, devices, source: "serverjj", generation: "direct-v1", revision: rev, role: u.role };
        if (Number(revision) === rev) return { ...base, unchanged: true };
        const data = await this.office.snapshot();
        if (!data) return { ...base, snapshot: null };
        const list = (c) => data.records.filter((r) => r.collection === c).map((r) => r.body), meta = list("meta")[0] || {};
        let snapshot = { ...meta, schema: 1, revision: data.revision, products: list("products"), suppliers: list("suppliers"), purchases: list("purchases"), movements: list("movements"), purchaseOrders: list("purchaseOrders"), reportPages: list("reportPages"), vendingMachines: list("vendingMachines"), vendingEvents: list("vendingEvents") };
        if (u.role === "employee") snapshot = { schema: 1, revision: data.revision, categories: meta.categories || [], products: snapshot.products.map((p) => Object.fromEntries(["id", "name", "sku", "barcode", "packBarcode", "packSize", "category", "unit", "price", "stockOnHand", "lowStockAt", "enabled", "trackStock", "image", "trashedAt", "updatedAt"].map((k) => [k, p[k]]))), suppliers: [], purchases: [], movements: [] };
        return { ...base, revision: data.revision, snapshot };
      }
      async handle(req, res, url, readBody, send) {
        if (url.pathname === "/office") {
          res.writeHead(302, { Location: "/office/" });
          res.end();
          return true;
        }
        if (!url.pathname.startsWith("/api/") && !url.pathname.startsWith("/office/") && !url.pathname.startsWith("/q/") && !["/", "/app.js", "/styles.css", "/config.js"].includes(url.pathname) && !url.pathname.startsWith("/assets/")) return false;
        if (["/office/commands", "/office/snapshot", "/office/staff"].includes(url.pathname)) return false;
        const own = (req.socket.encrypted ? "https" : "http") + "://" + req.headers.host, origin = req.headers.origin;
        if (origin && origin !== own && !this.origins.has(origin)) throw fail("\u0E44\u0E21\u0E48\u0E2D\u0E19\u0E38\u0E0D\u0E32\u0E15\u0E43\u0E2B\u0E49\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21\u0E08\u0E32\u0E01\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E0B\u0E15\u0E4C\u0E19\u0E35\u0E49", 403);
        if (origin && this.origins.has(origin)) {
          res.setHeader("Access-Control-Allow-Origin", origin);
          res.setHeader("Vary", "Origin");
        }
        if (req.method === "OPTIONS") {
          res.setHeader("Access-Control-Allow-Headers", "Authorization,Content-Type");
          res.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
          send(204, null);
          return true;
        }
        if (url.pathname === "/api/queue" && req.method === "GET") {
          this.limit(req, "queue", 120);
          const token = url.searchParams.get("token") || "";
          if (!/^[A-Za-z0-9_-]{24,160}$/.test(token)) {
            send(200, null);
            return true;
          }
          const q = (await this.engine.pool.query("SELECT body FROM chutima.entities WHERE collection='queues' AND body->>'qrToken'=$1 LIMIT 1", [token])).rows[0]?.body;
          const data = q ? projectPublicQueue(q) : null;
          if (data) {
            delete data.public_token;
            delete data.queue_id;
          }
          send(200, data && (!data.expires_at || new Date(data.expires_at) > /* @__PURE__ */ new Date()) ? data : null);
          return true;
        }
        if (url.pathname === "/api/auth/setup-status" && req.method === "GET") {
          send(200, { needsSetup: !!this.setupHash });
          return true;
        }
        if (["/api/auth/login", "/api/auth/setup"].includes(url.pathname) && req.method === "POST") {
          this.limit(req, "auth", 10);
          const input = await readBody(req, 16384);
          send(200, await (url.pathname.endsWith("/setup") ? this.setup(input) : this.login(input)));
          return true;
        }
        if (url.pathname.startsWith("/api/")) {
          const u = await this.session(req);
          if (url.pathname === "/api/auth/me" && req.method === "GET") {
            send(200, { user: publicUser(u) });
            return true;
          }
          if (url.pathname === "/api/auth/logout" && req.method === "POST") {
            await this.engine.pool.query("DELETE FROM chutima.office_sessions WHERE token_hash=$1", [digest(req.headers.authorization.slice(7))]);
            send(200, { ok: true });
            return true;
          }
          if (url.pathname === "/api/office" && req.method === "GET") {
            send(200, await this.load(u, url.searchParams.get("revision")));
            return true;
          }
          if (url.pathname === "/api/staff" && req.method === "POST") {
            this.limit(req, "staff", 30);
            send(200, await this.staff(u, await readBody(req, 16384)));
            return true;
          }
          if (url.pathname === "/api/commands" && req.method === "POST") {
            if (!["owner", "manager"].includes(u.role)) throw fail("\u0E44\u0E21\u0E48\u0E21\u0E35\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C\u0E41\u0E01\u0E49\u0E44\u0E02\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25", 403);
            const command = await readBody(req, 2 * 1024 * 1024);
            if (command.payload?.workflow === "employee.save") throw fail("\u0E08\u0E31\u0E14\u0E01\u0E32\u0E23\u0E1E\u0E19\u0E31\u0E01\u0E07\u0E32\u0E19\u0E1C\u0E48\u0E32\u0E19\u0E40\u0E21\u0E19\u0E39\u0E1A\u0E31\u0E0D\u0E0A\u0E35\u0E1E\u0E19\u0E31\u0E01\u0E07\u0E32\u0E19", 403);
            send(200, await this.office.apply(command));
            return true;
          }
          send(404, { error: "\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E17\u0E35\u0E48\u0E02\u0E2D" });
          return true;
        }
        if (req.method !== "GET" && req.method !== "HEAD") {
          send(405, { error: "\u0E44\u0E21\u0E48\u0E23\u0E2D\u0E07\u0E23\u0E31\u0E1A\u0E04\u0E33\u0E2A\u0E31\u0E48\u0E07" });
          return true;
        }
        let relative = url.pathname === "/office/" ? "office/index.html" : url.pathname === "/" || url.pathname.startsWith("/q/") ? "index.html" : decodeURIComponent(url.pathname).replace(/^\//, "");
        if (!/^(office\/(index\.html|app\.(js|css)|logo\.jpg|SETUP\.md)|index\.html|app\.js|styles\.css|config\.js|assets\/[A-Za-z0-9._-]+)$/.test(relative)) {
          send(404, { error: "\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A" });
          return true;
        }
        if (!this.root) {
          send(404, { error: "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E15\u0E34\u0E14\u0E15\u0E31\u0E49\u0E07\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A" });
          return true;
        }
        const file = path2.join(this.root, relative);
        if (!fs2.existsSync(file)) {
          send(404, { error: "\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E44\u0E1F\u0E25\u0E4C\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A" });
          return true;
        }
        const types = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".jpg": "image/jpeg", ".png": "image/png", ".svg": "image/svg+xml", ".md": "text/plain; charset=utf-8" };
        res.writeHead(200, { "Content-Type": types[path2.extname(file)] || "application/octet-stream", "Cache-Control": "no-cache", "X-Content-Type-Options": "nosniff", "Referrer-Policy": "no-referrer", "Content-Security-Policy": "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'" });
        if (req.method === "HEAD") res.end();
        else fs2.createReadStream(file).pipe(res);
        return true;
      }
    };
    module2.exports = { BrowserOffice: BrowserOffice2 };
  }
});

// migration/pos/server/server.cjs
var fs = require("node:fs");
var path = require("node:path");
var { Pool } = require_lib2();
var { Engine } = require_engine();
var { createApi } = require_http();
var { ServerBackup } = require_backup();
var { BrowserOffice } = require_browser_office();
async function start(configFile) {
  const file = path.resolve(configFile), config = JSON.parse(fs.readFileSync(file, "utf8"));
  if (config.database?.host !== "127.0.0.1" || config.database.port !== 5433 || config.database.database !== "chutima" || !["chutima_owner", "chutima_app"].includes(config.database.user)) throw Error("\u0E15\u0E49\u0E2D\u0E07\u0E43\u0E0A\u0E49\u0E10\u0E32\u0E19\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E0A\u0E38\u0E15\u0E34\u0E21\u0E32\u0E17\u0E35\u0E48\u0E41\u0E22\u0E01\u0E44\u0E27\u0E49\u0E1A\u0E19 127.0.0.1:5433 \u0E40\u0E17\u0E48\u0E32\u0E19\u0E31\u0E49\u0E19");
  if (config.port !== 8443) throw Error("\u0E1E\u0E2D\u0E23\u0E4C\u0E15\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E0A\u0E38\u0E15\u0E34\u0E21\u0E32\u0E15\u0E49\u0E2D\u0E07\u0E40\u0E1B\u0E47\u0E19 8443");
  const pool = new Pool({ ...config.database, max: 4, connectionTimeoutMillis: 5e3, statement_timeout: 3e4, application_name: "ChutimaServer" });
  const version = Number((await pool.query("SHOW server_version_num")).rows[0].server_version_num);
  if (version < 18e4 || version >= 19e4) throw Error("\u0E15\u0E49\u0E2D\u0E07\u0E43\u0E0A\u0E49 PostgreSQL 18 \u0E02\u0E2D\u0E07\u0E0A\u0E38\u0E15\u0E34\u0E21\u0E32");
  const engine = new Engine(pool);
  await engine.init();
  await engine.transaction(async (db) => {
    const old = (await db.query("SELECT body FROM chutima.entities WHERE collection='app' AND id='officeCapabilities'")).rows[0];
    if (Number(old?.body?.version || 0) < 4) await engine.write(db, { collection: "app", key: "officeCapabilities", value: { version: 4 } }, "office_upgrade_4");
  });
  const browser = new BrowserOffice({ engine, root: path.join(__dirname, "web"), setupFile: path.resolve(path.dirname(file), "../Admin/office-setup-code.txt"), allowedOrigins: config.officeOrigins || [] });
  await browser.init();
  const cloud = { status: () => ({ configured: true, active: true, mode: "direct", lastSyncAt: (/* @__PURE__ */ new Date()).toISOString(), error: null }) };
  const backup = new ServerBackup({ pool, config, base: path.dirname(file) });
  const server = createApi({ engine, cloud, browser, pairingKey: config.pairingKey, tls: { key: fs.readFileSync(path.resolve(path.dirname(file), config.tls.key)), cert: fs.readFileSync(path.resolve(path.dirname(file), config.tls.cert)) } });
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(config.port, config.host || "0.0.0.0", resolve);
  });
  backup.start();
  browser.start();
  let stopping = false;
  async function stop() {
    if (stopping) return;
    stopping = true;
    backup.stop();
    browser.stop();
    await new Promise((resolve) => server.close(resolve));
    await Promise.allSettled([backup.running]);
    await pool.end();
  }
  process.on("SIGTERM", () => stop().finally(() => process.exit()));
  process.on("SIGINT", () => stop().finally(() => process.exit()));
  console.log("Chutima server ready on port 8443");
  return { server, engine, pool, backup, browser, stop };
}
if (require.main === module) start(process.env.CHUTIMA_SERVER_CONFIG || path.join(__dirname, "config", "server.json")).catch((error) => {
  console.error("Chutima server startup failed:", /[ก-๙]/.test(error.message) ? error.message : "\u0E15\u0E23\u0E27\u0E08\u0E44\u0E1F\u0E25\u0E4C\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E41\u0E25\u0E30\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E10\u0E32\u0E19\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E0A\u0E38\u0E15\u0E34\u0E21\u0E32");
  process.exitCode = 1;
});
module.exports = { start };
